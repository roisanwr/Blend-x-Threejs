#!/usr/bin/env python3
"""
Blender 5.2 - Organic 3D Cartoon Character Generator
Uses Voxel Remesh & Smooth blending to create true 100% seamless, watertight organic geometry.
No hollow gaps, no floating primitives, no robotic joints.
A friendly, handsome early-20s cartoon male in streetwear wearing a baseball cap.
"""
import bpy
import bmesh
from mathutils import Vector, Matrix, Euler
import math

def clear_scene():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    if not bpy.data.collections:
        col = bpy.data.collections.new("Collection")
        bpy.context.scene.collection.children.link(col)

def create_pbr_material(name, base_color, roughness=0.5, metallic=0.0, sss_weight=0.0, sss_radius=(1.0, 0.35, 0.2), sheen_weight=0.0):
    mat = bpy.data.materials.new(name=name)
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()
    
    out = nodes.new("ShaderNodeOutputMaterial")
    out.location = (350, 0)
    
    bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.location = (0, 0)
    links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
    
    bsdf.inputs["Base Color"].default_value = (*base_color, 1.0)
    bsdf.inputs["Roughness"].default_value = roughness
    bsdf.inputs["Metallic"].default_value = metallic
    
    if "Subsurface Weight" in bsdf.inputs and sss_weight > 0:
        bsdf.inputs["Subsurface Weight"].default_value = sss_weight
        bsdf.inputs["Subsurface Radius"].default_value = sss_radius
        bsdf.inputs["Subsurface Scale"].default_value = 0.03
        
    if "Sheen Weight" in bsdf.inputs and sheen_weight > 0:
        bsdf.inputs["Sheen Weight"].default_value = sheen_weight
        
    return mat

def apply_smooth(obj):
    for p in obj.data.polygons:
        p.use_smooth = True
    obj.data.update()

def join_and_remesh(objects, name, voxel_size=0.018, smooth_repeat=2, material=None):
    if not objects:
        return None
    # Deselect all
    bpy.ops.object.select_all(action='DESELECT')
    for o in objects:
        o.select_set(True)
    bpy.context.view_layer.objects.active = objects[0]
    
    # Join into one mesh
    bpy.ops.object.join()
    unified = bpy.context.view_layer.objects.active
    unified.name = name
    
    # Voxel Remesh to fuse all intersections into a watertight organic solid
    unified.data.remesh_voxel_size = voxel_size
    bpy.ops.object.voxel_remesh()
    
    # Smooth modifier to soften blending seams like sculpted digital clay
    if smooth_repeat > 0:
        mod_sm = unified.modifiers.new("Smooth", 'SMOOTH')
        mod_sm.factor = 0.6
        mod_sm.iterations = smooth_repeat
        bpy.ops.object.modifier_apply(modifier="Smooth")
        
    apply_smooth(unified)
    if material:
        unified.data.materials.clear()
        unified.data.materials.append(material)
    return unified

def build_materials():
    mats = {}
    # Warm healthy cartoon human skin with rich SSS
    mats["skin"] = create_pbr_material("M_Skin", (0.90, 0.68, 0.56), roughness=0.45, sss_weight=0.5)
    mats["lips"] = create_pbr_material("M_Lips", (0.82, 0.46, 0.42), roughness=0.35, sss_weight=0.35)
    
    # Eyes & Eyebrows (Vibrant animated style)
    mats["eye_sclera"] = create_pbr_material("M_EyeSclera", (0.96, 0.96, 0.97), roughness=0.08)
    mats["eye_iris"] = create_pbr_material("M_EyeIris", (0.20, 0.11, 0.05), roughness=0.06) # Rich warm espresso/hazel
    mats["eye_pupil"] = create_pbr_material("M_EyePupil", (0.01, 0.01, 0.01), roughness=0.02)
    mats["eye_glint"] = create_pbr_material("M_EyeGlint", (1.0, 1.0, 1.0), roughness=0.01)
    mats["eyeliner"] = create_pbr_material("M_EyeLiner", (0.05, 0.035, 0.03), roughness=0.4)
    mats["eyebrow"] = create_pbr_material("M_Eyebrow", (0.05, 0.035, 0.03), roughness=0.6)
    
    # Hair
    mats["hair"] = create_pbr_material("M_Hair", (0.05, 0.038, 0.03), roughness=0.48, sheen_weight=0.4)
    
    # Cap (Vintage Deep Navy)
    mats["cap_main"] = create_pbr_material("M_Cap_Main", (0.04, 0.06, 0.11), roughness=0.75, sheen_weight=0.6)
    mats["cap_visor"] = create_pbr_material("M_Cap_Visor", (0.03, 0.05, 0.09), roughness=0.70, sheen_weight=0.5)
    mats["cap_button"] = create_pbr_material("M_Cap_Button", (0.08, 0.12, 0.18), roughness=0.65)
    mats["cap_patch"] = create_pbr_material("M_Cap_Patch", (0.90, 0.84, 0.74), roughness=0.55)
    mats["cap_emblem"] = create_pbr_material("M_Cap_Emblem", (0.75, 0.22, 0.18), roughness=0.5)
    mats["metal"] = create_pbr_material("M_Metal", (0.75, 0.75, 0.78), roughness=0.25, metallic=0.95)
    
    # Streetwear Hoodie (Matcha / Sage Green)
    mats["hoodie"] = create_pbr_material("M_Hoodie", (0.17, 0.30, 0.22), roughness=0.80, sheen_weight=0.7)
    mats["hoodie_rib"] = create_pbr_material("M_HoodieRib", (0.13, 0.24, 0.17), roughness=0.88, sheen_weight=0.6)
    mats["cord"] = create_pbr_material("M_Cord", (0.88, 0.86, 0.83), roughness=0.65)
    
    # Cargo Pants (Dark Charcoal Slate)
    mats["pants"] = create_pbr_material("M_Pants", (0.07, 0.08, 0.10), roughness=0.82, sheen_weight=0.35)
    mats["pants_detail"] = create_pbr_material("M_PantsDetail", (0.10, 0.12, 0.15), roughness=0.8)
    
    # Skate Sneakers
    mats["sneaker_white"] = create_pbr_material("M_SneakerWhite", (0.92, 0.92, 0.93), roughness=0.36)
    mats["sneaker_black"] = create_pbr_material("M_SneakerBlack", (0.03, 0.03, 0.04), roughness=0.45)
    mats["sneaker_accent"] = create_pbr_material("M_SneakerAccent", (0.17, 0.30, 0.22), roughness=0.45)
    mats["sneaker_sole"] = create_pbr_material("M_SneakerSole", (0.95, 0.94, 0.93), roughness=0.50)
    mats["sneaker_gum"] = create_pbr_material("M_SneakerGum", (0.48, 0.33, 0.18), roughness=0.6)
    
    # Studio Backdrop
    mats["backdrop"] = create_pbr_material("M_Backdrop", (0.22, 0.24, 0.28), roughness=0.92)
    
    return mats

def create_mesh_primitive(type_name, location=(0,0,0), scale=(1,1,1), rotation=(0,0,0), **kwargs):
    if type_name == 'SPHERE':
        bpy.ops.mesh.primitive_uv_sphere_add(
            segments=kwargs.get('u', 20),
            ring_count=kwargs.get('v', 14),
            radius=kwargs.get('radius', 1.0),
            location=location
        )
    elif type_name == 'CYLINDER':
        bpy.ops.mesh.primitive_cylinder_add(
            vertices=kwargs.get('v', 16),
            radius=kwargs.get('radius', 1.0),
            depth=kwargs.get('depth', 2.0),
            location=location
        )
    elif type_name == 'CONE':
        bpy.ops.mesh.primitive_cone_add(
            vertices=kwargs.get('v', 16),
            radius1=kwargs.get('radius1', 1.0),
            radius2=kwargs.get('radius2', 0.5),
            depth=kwargs.get('depth', 2.0),
            location=location
        )
    elif type_name == 'CUBE':
        bpy.ops.mesh.primitive_cube_add(
            size=kwargs.get('size', 1.0),
            location=location
        )
    obj = bpy.context.view_layer.objects.active
    obj.scale = scale
    obj.rotation_euler = Euler(rotation)
    bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
    return obj

def build_organic_head(mats):
    # Organic Cartoon Head masses: Cranium, Cheeks, Jaw/Chin, Nose, Neck
    head_parts = []
    
    # Cranium (Main skull)
    h_cranium = create_mesh_primitive('SPHERE', location=(0, 0, 1.62), scale=(0.105, 0.112, 0.115), radius=1.0)
    head_parts.append(h_cranium)
    
    # Jaw & Tapered Chin
    h_chin = create_mesh_primitive('SPHERE', location=(0, -0.045, 1.52), scale=(0.062, 0.065, 0.055), radius=1.0)
    head_parts.append(h_chin)
    
    # Left & Right Cheeks (Cute rounded fullness)
    h_cheek_l = create_mesh_primitive('SPHERE', location=(0.048, -0.035, 1.57), scale=(0.055, 0.055, 0.055), radius=1.0)
    h_cheek_r = create_mesh_primitive('SPHERE', location=(-0.048, -0.035, 1.57), scale=(0.055, 0.055, 0.055), radius=1.0)
    head_parts.extend([h_cheek_l, h_cheek_r])
    
    # Neck (Seamlessly connected to skull)
    h_neck = create_mesh_primitive('CYLINDER', location=(0, 0.005, 1.48), scale=(0.058, 0.058, 0.075), radius=1.0, depth=2.0)
    head_parts.append(h_neck)
    
    # Cute Cartoon Nose
    h_nose = create_mesh_primitive('SPHERE', location=(0, -0.112, 1.585), scale=(0.016, 0.022, 0.016), radius=1.0)
    head_parts.append(h_nose)
    
    # Cartoon Ears
    for side in (-1, 1):
        h_ear = create_mesh_primitive(
            'SPHERE',
            location=(side * 0.098, 0.005, 1.60),
            scale=(0.015, 0.030, 0.042),
            rotation=(0, math.radians(8 * side), math.radians(-12 * side)),
            radius=1.0
        )
        head_parts.append(h_ear)
        
    # Fuse into ONE 100% seamless watertight cartoon head!
    head_obj = join_and_remesh(head_parts, "Cartoon_Head", voxel_size=0.012, smooth_repeat=3, material=mats["skin"])
    
    # Add warm cartoon lips
    bm_lips = bmesh.new()
    bmesh.ops.create_uvsphere(bm_lips, u_segments=20, v_segments=12, radius=0.019)
    for v in bm_lips.verts:
        v.co.x *= 1.85
        v.co.y *= 0.40
        v.co.z *= 0.35
        smile = (abs(v.co.x) / 0.035)**2 * 0.004
        v.co.z += smile
        v.co.y -= 0.106
        v.co.z += 1.528
    lips_mesh = bpy.data.meshes.new("Lips")
    bm_lips.to_mesh(lips_mesh)
    bm_lips.free()
    lips_obj = bpy.data.objects.new("Cartoon_Lips", lips_mesh)
    bpy.context.scene.collection.objects.link(lips_obj)
    lips_obj.data.materials.append(mats["lips"])
    apply_smooth(lips_obj)
    
    # Big Expressive Cartoon Eyes
    for side in (-1, 1):
        # Sclera
        bm_eye = bmesh.new()
        bmesh.ops.create_uvsphere(bm_eye, u_segments=20, v_segments=14, radius=0.022)
        for v in bm_eye.verts:
            v.co.x *= 0.95
            v.co.y *= 0.85
            v.co.x += side * 0.040
            v.co.y -= 0.092
            v.co.z += 1.618
        eye_m = bpy.data.meshes.new(f"Eye_{side}")
        bm_eye.to_mesh(eye_m)
        bm_eye.free()
        eye_obj = bpy.data.objects.new(f"EyeBall_{'L' if side > 0 else 'R'}", eye_m)
        bpy.context.scene.collection.objects.link(eye_obj)
        eye_obj.data.materials.append(mats["eye_sclera"])
        apply_smooth(eye_obj)
        
        # Iris
        bm_iris = bmesh.new()
        bmesh.ops.create_uvsphere(bm_iris, u_segments=16, v_segments=12, radius=0.014)
        for v in bm_iris.verts:
            v.co.y *= 0.20
            v.co.x += side * 0.040
            v.co.y -= 0.110
            v.co.z += 1.618
        iris_m = bpy.data.meshes.new(f"Iris_{side}")
        bm_iris.to_mesh(iris_m)
        bm_iris.free()
        iris_obj = bpy.data.objects.new(f"Iris_{'L' if side > 0 else 'R'}", iris_m)
        bpy.context.scene.collection.objects.link(iris_obj)
        iris_obj.data.materials.append(mats["eye_iris"])
        apply_smooth(iris_obj)
        
        # Pupil
        bm_pupil = bmesh.new()
        bmesh.ops.create_uvsphere(bm_pupil, u_segments=12, v_segments=8, radius=0.007)
        for v in bm_pupil.verts:
            v.co.y *= 0.20
            v.co.x += side * 0.040
            v.co.y -= 0.113
            v.co.z += 1.618
        pup_m = bpy.data.meshes.new(f"Pupil_{side}")
        bm_pupil.to_mesh(pup_m)
        bm_pupil.free()
        pup_obj = bpy.data.objects.new(f"Pupil_{'L' if side > 0 else 'R'}", pup_m)
        bpy.context.scene.collection.objects.link(pup_obj)
        pup_obj.data.materials.append(mats["eye_pupil"])
        apply_smooth(pup_obj)
        
        # Specular Highlights
        bm_glint = bmesh.new()
        bmesh.ops.create_uvsphere(bm_glint, u_segments=8, v_segments=6, radius=0.0042)
        for v in bm_glint.verts:
            v.co.x += side * 0.037 - 0.002
            v.co.y -= 0.114
            v.co.z += 1.623
        glint_m = bpy.data.meshes.new(f"Glint_{side}")
        bm_glint.to_mesh(glint_m)
        bm_glint.free()
        glint_obj = bpy.data.objects.new(f"Glint_{'L' if side > 0 else 'R'}", glint_m)
        bpy.context.scene.collection.objects.link(glint_obj)
        glint_obj.data.materials.append(mats["eye_glint"])
        apply_smooth(glint_obj)
        
        # Curved Upper Eyelash Line
        bm_lid = bmesh.new()
        bmesh.ops.create_cube(bm_lid, size=1.0)
        for v in bm_lid.verts:
            v.co.x *= 0.026
            v.co.y *= 0.005
            v.co.z *= 0.0045
            v.co = Euler((0, 0, math.radians(-6 * side))).to_matrix() @ v.co
            v.co.x += side * 0.040
            v.co.y -= 0.110
            v.co.z += 1.634
        lid_m = bpy.data.meshes.new(f"Lid_{side}")
        bm_lid.to_mesh(lid_m)
        bm_lid.free()
        lid_obj = bpy.data.objects.new(f"EyeLid_{'L' if side > 0 else 'R'}", lid_m)
        bpy.context.scene.collection.objects.link(lid_obj)
        lid_obj.data.materials.append(mats["eyeliner"])
        apply_smooth(lid_obj)
        
        # Confident Eyebrow
        bm_brow = bmesh.new()
        bmesh.ops.create_cube(bm_brow, size=1.0)
        for v in bm_brow.verts:
            v.co.x *= 0.032
            v.co.y *= 0.006
            v.co.z *= 0.007
            v.co = Euler((0, 0, math.radians(12 * side))).to_matrix() @ v.co
            v.co.x += side * 0.042
            v.co.y -= 0.118
            v.co.z += 1.650
        brow_m = bpy.data.meshes.new(f"Brow_{side}")
        bm_brow.to_mesh(brow_m)
        bm_brow.free()
        brow_obj = bpy.data.objects.new(f"Eyebrow_{'L' if side > 0 else 'R'}", brow_m)
        bpy.context.scene.collection.objects.link(brow_obj)
        brow_obj.data.materials.append(mats["eyebrow"])
        apply_smooth(brow_obj)

def build_cartoon_hair_and_cap(mats):
    # Cartoon Hair Strands
    hair_parts = []
    strands = [
        (-0.028, -0.110, 1.660, 0.026, 0.016, 0.045, 20, 12, 22),
        (0.014, -0.112, 1.656, 0.028, 0.016, 0.048, 22, -10, -18),
        (-0.058, -0.102, 1.650, 0.024, 0.015, 0.046, 16, 20, 32),
        (0.050, -0.104, 1.648, 0.026, 0.015, 0.045, 18, -18, -26),
        # Sideburns
        (-0.090, -0.035, 1.595, 0.020, 0.026, 0.055, -10, 10, 5),
        (0.090, -0.035, 1.595, 0.020, 0.026, 0.055, -10, -10, -5),
        (-0.084, -0.010, 1.565, 0.018, 0.024, 0.050, -15, 5, 8),
        (0.084, -0.010, 1.565, 0.018, 0.024, 0.050, -15, -5, -8),
        # Back locks
        (-0.040, 0.075, 1.545, 0.030, 0.022, 0.055, -25, 10, 10),
        (0.040, 0.075, 1.545, 0.030, 0.022, 0.055, -25, -10, -10),
    ]
    for sx, sy, sz, scx, scy, scz, rx, ry, rz in strands:
        hp = create_mesh_primitive(
            'CONE',
            location=(sx, sy, sz),
            scale=(scx, scy, scz),
            rotation=(math.radians(rx), math.radians(ry), math.radians(rz)),
            radius1=1.0, radius2=0.2, depth=2.0
        )
        hair_parts.append(hp)
        
    join_and_remesh(hair_parts, "Cartoon_Hair", voxel_size=0.010, smooth_repeat=2, material=mats["hair"])
    
    # Baseball Cap Crown (Solid, natural fit)
    cap_crown = create_mesh_primitive(
        'SPHERE',
        location=(0, 0.015, 1.69),
        scale=(0.118, 0.124, 0.110),
        rotation=(math.radians(-8), 0, 0),
        radius=1.0
    )
    cap_crown.name = "Cap_Crown"
    cap_crown.data.materials.append(mats["cap_main"])
    apply_smooth(cap_crown)
    
    # Cap Top Button
    cap_btn = create_mesh_primitive(
        'SPHERE',
        location=(0, 0.015, 1.805),
        scale=(0.014, 0.014, 0.007),
        radius=1.0
    )
    cap_btn.name = "Cap_Button"
    cap_btn.data.materials.append(mats["cap_button"])
    apply_smooth(cap_btn)
    
    # Curved Visor / Brim (Extending forward naturally over brow)
    bm_visor = bmesh.new()
    bmesh.ops.create_grid(bm_visor, x_segments=16, y_segments=12, size=0.072)
    for v in bm_visor.verts:
        arch = (1.0 - (v.co.x / 0.072)**2) * 0.018
        v.co.z += arch
        dist_forward = (0.072 - v.co.y)
        v.co.z -= dist_forward * 0.18
        y_norm = dist_forward / 0.144
        v.co.x *= (1.0 - 0.22 * (y_norm**2))
        v.co.y -= 0.132
        v.co.z += 1.670
    visor_m = bpy.data.meshes.new("Visor")
    bm_visor.to_mesh(visor_m)
    bm_visor.free()
    visor_obj = bpy.data.objects.new("Cap_Visor", visor_m)
    bpy.context.scene.collection.objects.link(visor_obj)
    mod_v = visor_obj.modifiers.new("Solidify", 'SOLIDIFY')
    mod_v.thickness = 0.006
    visor_obj.data.materials.append(mats["cap_visor"])
    apply_smooth(visor_obj)
    
    # Front Patch & Graphic Emblem
    patch = create_mesh_primitive(
        'CUBE',
        location=(0, -0.118, 1.725),
        scale=(0.028, 0.004, 0.018),
        rotation=(math.radians(10), 0, 0),
        size=1.0
    )
    patch.name = "Cap_Patch"
    patch.data.materials.append(mats["cap_patch"])
    apply_smooth(patch)
    
    emblem = create_mesh_primitive(
        'CUBE',
        location=(0, -0.123, 1.725),
        scale=(0.016, 0.002, 0.010),
        rotation=(math.radians(10), 0, 0),
        size=1.0
    )
    emblem.name = "Cap_Emblem"
    emblem.data.materials.append(mats["cap_emblem"])
    apply_smooth(emblem)

def build_organic_hoodie(mats):
    # The Streetwear Hoodie: Continuous organic torso flowing into dropped shoulders and sleeves!
    hoodie_parts = []
    
    # Main Torso Body
    body = create_mesh_primitive('CYLINDER', location=(0, -0.01, 1.20), scale=(0.22, 0.15, 0.22), radius=1.0, depth=2.0)
    hoodie_parts.append(body)
    
    # Chest fullness
    chest = create_mesh_primitive('SPHERE', location=(0, -0.02, 1.28), scale=(0.23, 0.16, 0.18), radius=1.0)
    hoodie_parts.append(chest)
    
    # Dropped Shoulders (Connecting torso to arms organically)
    sh_l = create_mesh_primitive('SPHERE', location=(0.24, -0.01, 1.32), scale=(0.09, 0.09, 0.09), radius=1.0)
    sh_r = create_mesh_primitive('SPHERE', location=(-0.24, -0.01, 1.32), scale=(0.09, 0.09, 0.09), radius=1.0)
    hoodie_parts.extend([sh_l, sh_r])
    
    # Sleeves: Continuous Upper arm -> Elbow -> Forearm -> Wrist
    for side in (-1, 1):
        # Upper Arm
        u_arm = create_mesh_primitive(
            'CYLINDER',
            location=(side * 0.26, -0.04, 1.22),
            scale=(0.075, 0.075, 0.12),
            rotation=(math.radians(15), math.radians(-22 * side), 0),
            radius=1.0, depth=2.0
        )
        # Elbow joint sphere (solid blend)
        elbow = create_mesh_primitive('SPHERE', location=(side * 0.25, -0.08, 1.14), scale=(0.070, 0.070, 0.070), radius=1.0)
        # Forearm angled inwards towards kangaroo pouch
        f_arm = create_mesh_primitive(
            'CYLINDER',
            location=(side * 0.20, -0.13, 1.10),
            scale=(0.065, 0.065, 0.10),
            rotation=(math.radians(40), math.radians(38 * side), math.radians(15 * side)),
            radius=1.0, depth=2.0
        )
        hoodie_parts.extend([u_arm, elbow, f_arm])
        
    # Kangaroo Pocket on belly
    pock = create_mesh_primitive(
        'CUBE',
        location=(0, -0.165, 1.10),
        scale=(0.18, 0.045, 0.095),
        size=1.0
    )
    hoodie_parts.append(pock)
    
    # Draped Hood around collar/neck
    hood_back = create_mesh_primitive(
        'SPHERE',
        location=(0, 0.08, 1.40),
        scale=(0.16, 0.14, 0.12),
        radius=1.0
    )
    hoodie_parts.append(hood_back)
    
    # Waistband Hem
    hem = create_mesh_primitive(
        'CYLINDER',
        location=(0, -0.01, 0.98),
        scale=(0.21, 0.15, 0.05),
        radius=1.0, depth=2.0
    )
    hoodie_parts.append(hem)
    
    # FUSE the entire hoodie into ONE continuous organic cloth mesh!
    hoodie_obj = join_and_remesh(hoodie_parts, "Streetwear_Hoodie", voxel_size=0.016, smooth_repeat=3, material=mats["hoodie"])
    
    # Collar Rim
    collar = create_mesh_primitive(
        'CYLINDER',
        location=(0, -0.01, 1.44),
        scale=(0.11, 0.09, 0.025),
        radius=1.0, depth=2.0
    )
    collar.name = "Hoodie_Collar"
    collar.data.materials.append(mats["hoodie_rib"])
    apply_smooth(collar)
    
    # Hanging Drawstrings
    for side in (-1, 1):
        cord = create_mesh_primitive(
            'CYLINDER',
            location=(side * 0.038, -0.180, 1.28),
            scale=(0.004, 0.004, 0.12),
            radius=1.0, depth=2.0
        )
        cord.name = f"Cord_{'L' if side > 0 else 'R'}"
        cord.data.materials.append(mats["cord"])
        apply_smooth(cord)
        
        aglet = create_mesh_primitive(
            'CYLINDER',
            location=(side * 0.038, -0.180, 1.15),
            scale=(0.005, 0.005, 0.015),
            radius=1.0, depth=2.0
        )
        aglet.name = f"Aglet_{'L' if side > 0 else 'R'}"
        aglet.data.materials.append(mats["metal"])
        apply_smooth(aglet)
        
        # Ribbed Wrist Cuffs
        cuff = create_mesh_primitive(
            'CYLINDER',
            location=(side * 0.15, -0.170, 1.08),
            scale=(0.055, 0.055, 0.025),
            rotation=(math.radians(35), math.radians(40 * side), 0),
            radius=1.0, depth=2.0
        )
        cuff.name = f"Cuff_{'L' if side > 0 else 'R'}"
        cuff.data.materials.append(mats["hoodie_rib"])
        apply_smooth(cuff)
        
        # Cartoon Hands: Palm + Thumb hooked into pocket
        hand = create_mesh_primitive(
            'SPHERE',
            location=(side * 0.125, -0.190, 1.07),
            scale=(0.032, 0.045, 0.025),
            rotation=(math.radians(25), math.radians(30 * side), 0),
            radius=1.0
        )
        hand.name = f"Hand_{'L' if side > 0 else 'R'}"
        hand.data.materials.append(mats["skin"])
        apply_smooth(hand)

def build_organic_pants(mats):
    # Continuous organic cargo pants: Pelvis connects seamlessly to thighs, knees, calves, and ankles!
    pants_parts = []
    
    # Pelvis & Crotch base
    pelvis = create_mesh_primitive('SPHERE', location=(0, -0.01, 0.92), scale=(0.20, 0.16, 0.14), radius=1.0)
    pants_parts.append(pelvis)
    
    # Left and Right Legs
    for side in (-1, 1):
        # Upper Thigh (Rooting securely inside the pelvis)
        thigh_u = create_mesh_primitive(
            'CYLINDER',
            location=(side * 0.115, -0.01, 0.76),
            scale=(0.098, 0.095, 0.14),
            rotation=(math.radians(-2), math.radians(-3 * side), 0),
            radius=1.0, depth=2.0
        )
        # Knee Sphere (Organic bridge between thigh and calf)
        knee = create_mesh_primitive(
            'SPHERE',
            location=(side * 0.122, -0.015, 0.52),
            scale=(0.092, 0.092, 0.092),
            radius=1.0
        )
        # Calf / Shin
        calf = create_mesh_primitive(
            'CYLINDER',
            location=(side * 0.128, -0.005, 0.36),
            scale=(0.088, 0.086, 0.14),
            radius=1.0, depth=2.0
        )
        # Lower leg stacked over sneakers
        ankle = create_mesh_primitive(
            'CYLINDER',
            location=(side * 0.134, 0.00, 0.18),
            scale=(0.094, 0.092, 0.08),
            radius=1.0, depth=2.0
        )
        # Cargo Pockets on outer thigh
        cargo = create_mesh_primitive(
            'CUBE',
            location=(side * 0.215, -0.01, 0.66),
            scale=(0.028, 0.075, 0.090),
            size=1.0
        )
        cargo_flap = create_mesh_primitive(
            'CUBE',
            location=(side * 0.220, -0.01, 0.73),
            scale=(0.030, 0.078, 0.022),
            size=1.0
        )
        pants_parts.extend([thigh_u, knee, calf, ankle, cargo, cargo_flap])
        
    # FUSE into ONE continuous, seamless, organic pair of pants!
    pants_obj = join_and_remesh(pants_parts, "Cargo_Pants", voxel_size=0.016, smooth_repeat=3, material=mats["pants"])

def build_organic_sneakers(mats):
    # Chunky Cartoon Skate Sneakers (Solid, fully ground-contacting, detailed)
    for side in (-1, 1):
        sneaker_parts = []
        
        # Midsole (Chunky white platform)
        midsole = create_mesh_primitive(
            'CUBE',
            location=(side * 0.138, -0.035, 0.035),
            scale=(0.075, 0.160, 0.032),
            rotation=(0, 0, math.radians(7 * side)),
            size=1.0
        )
        sneaker_parts.append(midsole)
        
        # Toe Cap Bumper
        toe = create_mesh_primitive(
            'SPHERE',
            location=(side * 0.138 - 0.015 * math.sin(math.radians(7 * side)), -0.155, 0.045),
            scale=(0.072, 0.065, 0.040),
            rotation=(0, 0, math.radians(7 * side)),
            radius=1.0
        )
        sneaker_parts.append(toe)
        
        # Shoe Upper Body
        upper = create_mesh_primitive(
            'SPHERE',
            location=(side * 0.138, -0.035, 0.075),
            scale=(0.072, 0.145, 0.055),
            rotation=(0, 0, math.radians(7 * side)),
            radius=1.0
        )
        sneaker_parts.append(upper)
        
        # Ankle Collar Wrapping around leg
        collar = create_mesh_primitive(
            'CYLINDER',
            location=(side * 0.138, -0.005, 0.125),
            scale=(0.065, 0.065, 0.030),
            rotation=(math.radians(-15), 0, math.radians(7 * side)),
            radius=1.0, depth=2.0
        )
        sneaker_parts.append(collar)
        
        # Fuse shoe upper into clean solid shoe
        shoe_obj = join_and_remesh(sneaker_parts, f"Sneaker_{'L' if side > 0 else 'R'}", voxel_size=0.012, smooth_repeat=2, material=mats["sneaker_white"])
        
        # Bottom Gum Rubber Tread Sole
        tread = create_mesh_primitive(
            'CUBE',
            location=(side * 0.138, -0.035, 0.008),
            scale=(0.072, 0.156, 0.008),
            rotation=(0, 0, math.radians(7 * side)),
            size=1.0
        )
        tread.name = f"Sneaker_Tread_{'L' if side > 0 else 'R'}"
        tread.data.materials.append(mats["sneaker_gum"])
        apply_smooth(tread)
        
        # Side Accent Stripe (Sage Green)
        stripe = create_mesh_primitive(
            'CUBE',
            location=(side * (0.138 + 0.052 * side), -0.030, 0.075),
            scale=(0.006, 0.080, 0.020),
            rotation=(math.radians(-12), 0, math.radians(7 * side)),
            size=1.0
        )
        stripe.name = f"Sneaker_Stripe_{'L' if side > 0 else 'R'}"
        stripe.data.materials.append(mats["sneaker_accent"])
        apply_smooth(stripe)
        
        # Laces on top
        for i in range(3):
            lace = create_mesh_primitive(
                'CUBE',
                location=(side * 0.138, -0.045 + i * 0.022, 0.090 + i * 0.015),
                scale=(0.026, 0.006, 0.005),
                rotation=(math.radians(38), 0, math.radians(7 * side)),
                size=1.0
            )
            lace.name = f"Sneaker_Lace_{i}_{'L' if side > 0 else 'R'}"
            lace.data.materials.append(mats["sneaker_white"])
            apply_smooth(lace)

def build_backdrop(mats):
    bm = bmesh.new()
    xs = [-3.5 + i * 0.7 for i in range(11)]
    profile = []
    for y in [-3.2, -2.0, -1.0, 0.5, 1.2]:
        profile.append((y, 0.0))
    for angle_deg in [15, 30, 45, 60, 75, 90]:
        rad = math.radians(angle_deg)
        y = 1.2 + 0.9 * math.sin(rad)
        z = 0.9 * (1.0 - math.cos(rad))
        profile.append((y, z))
    for z in [1.2, 1.8, 2.5, 3.4]:
        profile.append((2.1, z))
        
    grid_verts = []
    for y, z in profile:
        row = []
        for x in xs:
            v = bm.verts.new((x, y, z))
            row.append(v)
        grid_verts.append(row)
    bm.verts.ensure_lookup_table()
    
    for r in range(len(grid_verts) - 1):
        for c in range(len(xs) - 1):
            v1 = grid_verts[r][c]
            v2 = grid_verts[r][c+1]
            v3 = grid_verts[r+1][c+1]
            v4 = grid_verts[r+1][c]
            bm.faces.new([v1, v2, v3, v4])
            
    mesh = bpy.data.meshes.new("Backdrop")
    bm.to_mesh(mesh)
    bm.free()
    cyc = bpy.data.objects.new("Studio_Cyclorama", mesh)
    bpy.context.scene.collection.objects.link(cyc)
    cyc.data.materials.append(mats["backdrop"])
    apply_smooth(cyc)
    mod = cyc.modifiers.new("Subdivision", 'SUBSURF')
    mod.levels = 1
    return cyc

def setup_lighting():
    # 1. Warm Key Light (Front-Right 45 degrees)
    key_data = bpy.data.lights.new(name="Key_Light", type='AREA')
    key_data.energy = 280.0
    key_data.size = 1.4
    key_data.color = (1.0, 0.95, 0.90)
    key_obj = bpy.data.objects.new(name="Key_Light", object_data=key_data)
    key_obj.location = (1.6, -2.2, 2.0)
    dir_k = Vector((0, 0, 1.1)) - key_obj.location
    key_obj.rotation_euler = dir_k.to_track_quat('-Z', 'Y').to_euler()
    bpy.context.scene.collection.objects.link(key_obj)
    
    # 2. Cool Fill Light (Front-Left)
    fill_data = bpy.data.lights.new(name="Fill_Light", type='AREA')
    fill_data.energy = 130.0
    fill_data.size = 2.2
    fill_data.color = (0.86, 0.92, 1.0)
    fill_obj = bpy.data.objects.new(name="Fill_Light", object_data=fill_data)
    fill_obj.location = (-1.8, -2.0, 1.4)
    dir_f = Vector((0, 0, 1.0)) - fill_obj.location
    fill_obj.rotation_euler = dir_f.to_track_quat('-Z', 'Y').to_euler()
    bpy.context.scene.collection.objects.link(fill_obj)
    
    # 3. Rim / Kicker Light (Back-Right, outlines silhouette)
    rim_data = bpy.data.lights.new(name="Rim_Light", type='AREA')
    rim_data.energy = 440.0
    rim_data.size = 1.2
    rim_data.color = (1.0, 0.98, 0.95)
    rim_obj = bpy.data.objects.new(name="Rim_Light", object_data=rim_data)
    rim_obj.location = (-1.2, 1.5, 2.2)
    dir_r = Vector((0, 0, 1.3)) - rim_obj.location
    rim_obj.rotation_euler = dir_r.to_track_quat('-Z', 'Y').to_euler()
    bpy.context.scene.collection.objects.link(rim_obj)
    
    # 4. Top Soft Overhead Light
    top_data = bpy.data.lights.new(name="Top_Light", type='AREA')
    top_data.energy = 80.0
    top_data.size = 2.8
    top_data.color = (0.95, 0.95, 0.98)
    top_obj = bpy.data.objects.new(name="Top_Light", object_data=top_data)
    top_obj.location = (0.0, -0.4, 3.2)
    top_obj.rotation_euler = Euler((0, 0, 0))
    bpy.context.scene.collection.objects.link(top_obj)

def setup_camera():
    cam_data = bpy.data.cameras.new("Main_Camera")
    cam_data.lens = 48.0
    cam_data.sensor_width = 36.0
    
    cam_obj = bpy.data.objects.new("Main_Camera", cam_data)
    cam_obj.location = (0.38, -3.15, 0.98)
    target = Vector((0.0, 0.0, 0.88))
    direction = target - cam_obj.location
    cam_obj.rotation_euler = direction.to_track_quat('-Z', 'Y').to_euler()
    
    bpy.context.scene.collection.objects.link(cam_obj)
    bpy.context.scene.camera = cam_obj
    return cam_obj

def setup_render(output_path, samples=48):
    scene = bpy.context.scene
    scene.render.engine = 'CYCLES'
    scene.cycles.device = 'CPU'
    scene.cycles.samples = samples
    scene.cycles.use_denoising = True
    
    scene.render.resolution_x = 1200
    scene.render.resolution_y = 1600
    scene.render.resolution_percentage = 100
    
    scene.view_settings.view_transform = 'AgX'
    scene.view_settings.look = 'AgX - High Contrast'
    
    scene.render.filepath = output_path
    scene.render.image_settings.file_format = 'PNG'
    scene.render.image_settings.color_mode = 'RGBA'

def main():
    print("[1/6] Initializing scene...")
    clear_scene()
    
    print("[2/6] Building PBR materials...")
    mats = build_materials()
    
    print("[3/6] Generating organic cartoon character geometry...")
    build_organic_head(mats)
    build_cartoon_hair_and_cap(mats)
    build_organic_hoodie(mats)
    build_organic_pants(mats)
    build_organic_sneakers(mats)
    build_backdrop(mats)
    
    print("[4/6] Setting up studio lighting & camera...")
    setup_lighting()
    setup_camera()
    
    out_blend = "/home/rois/jarvis/blender-character/karakter_pria_topi.blend"
    out_png = "/home/rois/jarvis/blender-character/render_preview.png"
    
    print(f"[5/6] Saving .blend file to {out_blend}...")
    bpy.ops.wm.save_as_mainfile(filepath=out_blend)
    
    print(f"[6/6] Rendering preview with Cycles to {out_png}...")
    setup_render(out_png, samples=48)
    bpy.ops.render.render(write_still=True)
    
    total_tris = sum(len(o.data.polygons) * 2 for o in bpy.data.objects if o.type == 'MESH')
    total_objs = len(bpy.data.objects)
    print(f"DONE! Objects: {total_objs}, Approx Tris: {total_tris}")
    print(f"Blend file: {out_blend}")
    print(f"Render image: {out_png}")

if __name__ == "__main__":
    main()
