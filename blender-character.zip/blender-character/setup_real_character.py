#!/usr/bin/env python3
"""
Setup and render the stylized cartoon human character in Blender 5.2.
Archetype: Stylized early-20s male character wearing a hat.
- Clean-shaven youthful face with warm smile (mouthSmile shape key)
- Natural relaxed pose (arms down, relaxed hands, slight head tilt)
- Studio cyclorama backdrop and 3-point portrait lighting
- Rendered with Cycles and saved as .blend and preview PNG
"""
import bpy
import bmesh
from mathutils import Vector, Euler
import math
import os

def build_scene():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    
    # Import the stylized 3D human character
    glb_path = "/home/rois/jarvis/blender-character/readyplayer.me.glb"
    bpy.ops.import_scene.gltf(filepath=glb_path)
    
    # Remove beard for clean-shaven youthful early-20s look
    beard = bpy.data.objects.get("Wolf3D_Beard")
    if beard:
        bpy.data.objects.remove(beard, do_unlink=True)
        
    # Set facial expression to warm friendly smile
    head = bpy.data.objects.get("Wolf3D_Head")
    if head and head.data.shape_keys:
        kb = head.data.shape_keys.key_blocks
        if "mouthSmile" in kb:
            kb["mouthSmile"].value = 0.65
            
    # Natural relaxed posing via Armature
    arm = bpy.data.objects.get("Armature")
    if arm:
        bpy.context.view_layer.objects.active = arm
        bpy.ops.object.mode_set(mode='POSE')
        pb = arm.pose.bones
        
        # Lower arms from stiff A-pose into relaxed casual stance
        if "LeftArm" in pb:
            pb["LeftArm"].rotation_mode = 'XYZ'
            pb["LeftArm"].rotation_euler = (math.radians(-5), math.radians(5), math.radians(-32))
        if "RightArm" in pb:
            pb["RightArm"].rotation_mode = 'XYZ'
            pb["RightArm"].rotation_euler = (math.radians(-5), math.radians(-5), math.radians(32))
            
        # Relax forearms and elbows
        if "LeftForeArm" in pb:
            pb["LeftForeArm"].rotation_mode = 'XYZ'
            pb["LeftForeArm"].rotation_euler = (math.radians(10), math.radians(10), math.radians(-10))
        if "RightForeArm" in pb:
            pb["RightForeArm"].rotation_mode = 'XYZ'
            pb["RightForeArm"].rotation_euler = (math.radians(10), math.radians(-10), math.radians(10))
            
        # Subtle head tilt for charm and personality
        if "Head" in pb:
            pb["Head"].rotation_mode = 'XYZ'
            pb["Head"].rotation_euler = (math.radians(-2), math.radians(4), math.radians(3))
            
        bpy.ops.object.mode_set(mode='OBJECT')
        
    # Build Studio Cyclorama Backdrop
    bm = bmesh.new()
    xs = [-3.5 + i * 0.7 for i in range(11)]
    profile = []
    for y in [-3.2, -2.0, -1.0, 0.5, 1.2]:
        profile.append((y, 0.0))
    for angle_deg in [15, 30, 45, 60, 75, 90]:
        rad = math.radians(angle_deg)
        y = 1.2 + 0.9 * math.sin(rad)
        z = 0.9 * (1.0 - math.cos(rad))
        profile.append((y, z))
    for z in [1.2, 1.8, 2.5, 3.4]:
        profile.append((2.1, z))
        
    grid_verts = []
    for y, z in profile:
        row = []
        for x in xs:
            v = bm.verts.new((x, y, z))
            row.append(v)
        grid_verts.append(row)
    bm.verts.ensure_lookup_table()
    
    for r in range(len(grid_verts) - 1):
        for c in range(len(xs) - 1):
            v1 = grid_verts[r][c]
            v2 = grid_verts[r][c+1]
            v3 = grid_verts[r+1][c+1]
            v4 = grid_verts[r+1][c]
            bm.faces.new([v1, v2, v3, v4])
            
    mesh = bpy.data.meshes.new("Backdrop")
    bm.to_mesh(mesh)
    bm.free()
    cyc = bpy.data.objects.new("Studio_Cyclorama", mesh)
    bpy.context.scene.collection.objects.link(cyc)
    
    # Backdrop Material: Clean warm studio slate grey
    mat_bg = bpy.data.materials.new("M_StudioBackdrop")
    bsdf = mat_bg.node_tree.nodes.get("Principled BSDF")
    if bsdf:
        bsdf.inputs["Base Color"].default_value = (0.28, 0.30, 0.34, 1.0)
        bsdf.inputs["Roughness"].default_value = 0.92
    cyc.data.materials.append(mat_bg)
    for p in cyc.data.polygons:
        p.use_smooth = True
    mod_cyc = cyc.modifiers.new("Subsurf", 'SUBSURF')
    mod_cyc.levels = 1
    
    # Studio Lighting Setup
    # 1. Warm Key Light
    key_data = bpy.data.lights.new(name="Key_Light", type='AREA')
    key_data.energy = 240.0
    key_data.size = 1.5
    key_data.color = (1.0, 0.95, 0.90)
    key_obj = bpy.data.objects.new(name="Key_Light", object_data=key_data)
    key_obj.location = (1.5, -2.2, 2.0)
    dir_k = Vector((0, 0, 1.1)) - key_obj.location
    key_obj.rotation_euler = dir_k.to_track_quat('-Z', 'Y').to_euler()
    bpy.context.scene.collection.objects.link(key_obj)
    
    # 2. Cool Fill Light
    fill_data = bpy.data.lights.new(name="Fill_Light", type='AREA')
    fill_data.energy = 110.0
    fill_data.size = 2.2
    fill_data.color = (0.86, 0.92, 1.0)
    fill_obj = bpy.data.objects.new(name="Fill_Light", object_data=fill_data)
    fill_obj.location = (-1.8, -2.0, 1.4)
    dir_f = Vector((0, 0, 1.0)) - fill_obj.location
    fill_obj.rotation_euler = dir_f.to_track_quat('-Z', 'Y').to_euler()
    bpy.context.scene.collection.objects.link(fill_obj)
    
    # 3. Bright Rim / Kicker Light
    rim_data = bpy.data.lights.new(name="Rim_Light", type='AREA')
    rim_data.energy = 380.0
    rim_data.size = 1.2
    rim_data.color = (1.0, 0.98, 0.95)
    rim_obj = bpy.data.objects.new(name="Rim_Light", object_data=rim_data)
    rim_obj.location = (-1.2, 1.5, 2.2)
    dir_r = Vector((0, 0, 1.3)) - rim_obj.location
    rim_obj.rotation_euler = dir_r.to_track_quat('-Z', 'Y').to_euler()
    bpy.context.scene.collection.objects.link(rim_obj)
    
    # 4. Top Soft Light
    top_data = bpy.data.lights.new(name="Top_Light", type='AREA')
    top_data.energy = 70.0
    top_data.size = 2.8
    top_data.color = (0.95, 0.95, 0.98)
    top_obj = bpy.data.objects.new(name="Top_Light", object_data=top_data)
    top_obj.location = (0.0, -0.4, 3.2)
    bpy.context.scene.collection.objects.link(top_obj)
    
    # Camera: Portrait Hero View (48mm lens, full body framing with head to toe and contact shadow)
    cam_data = bpy.data.cameras.new("Main_Camera")
    cam_data.lens = 48.0
    cam_data.sensor_width = 36.0
    cam_obj = bpy.data.objects.new("Main_Camera", cam_data)
    cam_obj.location = (0.32, -3.10, 0.98)
    target = Vector((0.0, 0.0, 0.88))
    direction = target - cam_obj.location
    cam_obj.rotation_euler = direction.to_track_quat('-Z', 'Y').to_euler()
    bpy.context.scene.collection.objects.link(cam_obj)
    bpy.context.scene.camera = cam_obj
    
    # Cycles Render Configuration
    scene = bpy.context.scene
    scene.render.engine = 'CYCLES'
    scene.cycles.device = 'CPU'
    scene.cycles.samples = 48
    scene.cycles.use_denoising = True
    
    scene.render.resolution_x = 1200
    scene.render.resolution_y = 1600
    scene.render.resolution_percentage = 100
    
    scene.view_settings.view_transform = 'AgX'
    scene.view_settings.look = 'AgX - High Contrast'
    
    out_blend = "/home/rois/jarvis/blender-character/karakter_pria_topi.blend"
    out_png = "/home/rois/jarvis/blender-character/render_preview.png"
    
    scene.render.filepath = out_png
    scene.render.image_settings.file_format = 'PNG'
    scene.render.image_settings.color_mode = 'RGBA'
    
    print(f"Saving .blend file to {out_blend}...")
    bpy.ops.wm.save_as_mainfile(filepath=out_blend)
    
    print(f"Rendering preview with Cycles to {out_png}...")
    bpy.ops.render.render(write_still=True)
    
    print("DONE!")
    print(f"Blend file: {out_blend}")
    print(f"Render image: {out_png}")

if __name__ == "__main__":
    build_scene()
