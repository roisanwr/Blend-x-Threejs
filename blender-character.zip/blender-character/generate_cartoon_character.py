#!/usr/bin/env python3
"""
Generate a high-quality stylized 3D Cartoon Human Character in Blender 5.2.
Archetype: Friendly early-20s male in streetwear wearing a baseball cap.
Style: Pixar / 3D Animated Cartoon aesthetic (organic continuous body, expressive face, cartoon hands, stylish clothes).
"""
import bpy
import bmesh
from mathutils import Vector, Matrix, Euler
import math
import os

def clear_scene():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    if not bpy.data.collections:
        col = bpy.data.collections.new("Collection")
        bpy.context.scene.collection.children.link(col)

def create_pbr_material(name, base_color, roughness=0.5, metallic=0.0, sss_weight=0.0, sss_radius=(1.0, 0.35, 0.2), sheen_weight=0.0):
    mat = bpy.data.materials.new(name=name)
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()
    
    out = nodes.new("ShaderNodeOutputMaterial")
    out.location = (350, 0)
    
    bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.location = (0, 0)
    links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
    
    bsdf.inputs["Base Color"].default_value = (*base_color, 1.0)
    bsdf.inputs["Roughness"].default_value = roughness
    bsdf.inputs["Metallic"].default_value = metallic
    
    if "Subsurface Weight" in bsdf.inputs and sss_weight > 0:
        bsdf.inputs["Subsurface Weight"].default_value = sss_weight
        bsdf.inputs["Subsurface Radius"].default_value = sss_radius
        bsdf.inputs["Subsurface Scale"].default_value = 0.03
        
    if "Sheen Weight" in bsdf.inputs and sheen_weight > 0:
        bsdf.inputs["Sheen Weight"].default_value = sheen_weight
        
    return mat

def apply_smooth_and_subd(obj, levels=2):
    for p in obj.data.polygons:
        p.use_smooth = True
    if levels > 0:
        sub = obj.modifiers.new("Subdivision", 'SUBSURF')
        sub.levels = levels
        sub.render_levels = levels
    obj.data.update()

def make_obj(name, bm, material=None, subd_levels=2):
    mesh = bpy.data.meshes.new(name)
    bm.to_mesh(mesh)
    bm.free()
    obj = bpy.data.objects.new(name, mesh)
    bpy.context.scene.collection.objects.link(obj)
    if material:
        obj.data.materials.append(material)
    apply_smooth_and_subd(obj, subd_levels)
    return obj

def make_torus_bm(bm, major_radius, minor_radius, major_segments=24, minor_segments=8):
    verts = []
    for i in range(major_segments):
        phi = 2.0 * math.pi * i / major_segments
        cos_phi = math.cos(phi)
        sin_phi = math.sin(phi)
        ring = []
        for j in range(minor_segments):
            theta = 2.0 * math.pi * j / minor_segments
            r = major_radius + minor_radius * math.cos(theta)
            z = minor_radius * math.sin(theta)
            x = r * cos_phi
            y = r * sin_phi
            ring.append(bm.verts.new((x, y, z)))
        verts.append(ring)
    bm.verts.ensure_lookup_table()
    for i in range(major_segments):
        next_i = (i + 1) % major_segments
        for j in range(minor_segments):
            next_j = (j + 1) % minor_segments
            v1 = verts[i][j]
            v2 = verts[next_i][j]
            v3 = verts[next_i][next_j]
            v4 = verts[i][next_j]
            bm.faces.new([v1, v2, v3, v4])

def make_tube_along_curve(points, radius=0.005, segments=8):
    bm = bmesh.new()
    rings = []
    for idx, pt in enumerate(points):
        if idx == 0:
            tangent = (points[1] - pt).normalized()
        elif idx == len(points) - 1:
            tangent = (pt - points[-1]).normalized()
        else:
            tangent = (points[idx+1] - points[idx-1]).normalized()
            
        up = Vector((0, 0, 1))
        if abs(tangent.dot(up)) > 0.9:
            up = Vector((1, 0, 0))
        normal = tangent.cross(up).normalized()
        binormal = tangent.cross(normal).normalized()
        
        ring = []
        for s in range(segments):
            angle = 2.0 * math.pi * s / segments
            offset = normal * (radius * math.cos(angle)) + binormal * (radius * math.sin(angle))
            v = bm.verts.new(pt + offset)
            ring.append(v)
        rings.append(ring)
        
    bm.verts.ensure_lookup_table()
    for r in range(len(rings) - 1):
        for s in range(segments):
            next_s = (s + 1) % segments
            v1 = rings[r][s]
            v2 = rings[r][next_s]
            v3 = rings[r+1][next_s]
            v4 = rings[r+1][s]
            bm.faces.new([v1, v2, v3, v4])
            
    bm.faces.new(rings[0])
    bm.faces.new(list(reversed(rings[-1])))
    return bm

def build_materials():
    mats = {}
    # Warm healthy cartoon skin with soft SSS
    mats["skin"] = create_pbr_material("M_Skin", (0.90, 0.70, 0.58), roughness=0.42, sss_weight=0.55)
    mats["lips"] = create_pbr_material("M_Lips", (0.82, 0.46, 0.42), roughness=0.35, sss_weight=0.4)
    mats["teeth"] = create_pbr_material("M_Teeth", (0.96, 0.96, 0.94), roughness=0.2)
    mats["tongue"] = create_pbr_material("M_Tongue", (0.78, 0.32, 0.32), roughness=0.4)
    
    # Eyes & Eyebrows (Vibrant animated style)
    mats["eye_sclera"] = create_pbr_material("M_EyeSclera", (0.97, 0.97, 0.98), roughness=0.06)
    mats["eye_iris"] = create_pbr_material("M_EyeIris", (0.18, 0.10, 0.05), roughness=0.05) # Warm hazel/espresso
    mats["eye_pupil"] = create_pbr_material("M_EyePupil", (0.01, 0.01, 0.01), roughness=0.02)
    mats["eye_glint"] = create_pbr_material("M_EyeGlint", (1.0, 1.0, 1.0), roughness=0.01)
    mats["eyeliner"] = create_pbr_material("M_EyeLiner", (0.05, 0.035, 0.03), roughness=0.3)
    mats["eyebrow"] = create_pbr_material("M_Eyebrow", (0.05, 0.035, 0.03), roughness=0.6)
    
    # Hair
    mats["hair"] = create_pbr_material("M_Hair", (0.05, 0.038, 0.03), roughness=0.45, sheen_weight=0.4)
    
    # Streetwear Cap (Vintage Dark Navy)
    mats["cap_crown"] = create_pbr_material("M_Cap_Crown", (0.04, 0.06, 0.11), roughness=0.75, sheen_weight=0.6)
    mats["cap_visor"] = create_pbr_material("M_Cap_Visor", (0.03, 0.05, 0.09), roughness=0.70, sheen_weight=0.5)
    mats["cap_button"] = create_pbr_material("M_Cap_Button", (0.08, 0.12, 0.18), roughness=0.65)
    mats["cap_patch"] = create_pbr_material("M_Cap_Patch", (0.90, 0.84, 0.74), roughness=0.55) # Canvas patch
    mats["cap_emblem"] = create_pbr_material("M_Cap_Emblem", (0.75, 0.25, 0.20), roughness=0.5) # Red accent emblem
    mats["cap_strap"] = create_pbr_material("M_Cap_Strap", (0.12, 0.08, 0.05), roughness=0.5)
    mats["metal"] = create_pbr_material("M_Metal", (0.75, 0.75, 0.78), roughness=0.25, metallic=0.95)
    
    # Streetwear Hoodie (Matcha / Sage Green)
    mats["hoodie"] = create_pbr_material("M_Hoodie", (0.17, 0.30, 0.22), roughness=0.80, sheen_weight=0.7)
    mats["hoodie_rib"] = create_pbr_material("M_HoodieRib", (0.13, 0.24, 0.17), roughness=0.88, sheen_weight=0.6)
    mats["cord"] = create_pbr_material("M_Cord", (0.88, 0.86, 0.83), roughness=0.65)
    
    # Cargo Pants (Dark Charcoal Slate)
    mats["pants"] = create_pbr_material("M_Pants", (0.07, 0.08, 0.10), roughness=0.82, sheen_weight=0.35)
    mats["pants_detail"] = create_pbr_material("M_PantsDetail", (0.10, 0.12, 0.15), roughness=0.8)
    
    # Skate Sneakers
    mats["sneaker_white"] = create_pbr_material("M_SneakerWhite", (0.92, 0.92, 0.93), roughness=0.36)
    mats["sneaker_black"] = create_pbr_material("M_SneakerBlack", (0.03, 0.03, 0.04), roughness=0.45)
    mats["sneaker_accent"] = create_pbr_material("M_SneakerAccent", (0.17, 0.30, 0.22), roughness=0.45)
    mats["sneaker_sole"] = create_pbr_material("M_SneakerSole", (0.95, 0.94, 0.93), roughness=0.50)
    mats["sneaker_gum"] = create_pbr_material("M_SneakerGum", (0.48, 0.33, 0.18), roughness=0.6)
    
    # Studio Backdrop
    mats["backdrop"] = create_pbr_material("M_Backdrop", (0.22, 0.24, 0.28), roughness=0.92)
    
    return mats

def build_cartoon_head_and_face(mats):
    # Organic Cartoon Head: Rounded cheeks, defined jawline, smooth young male features
    bm = bmesh.new()
    bmesh.ops.create_uvsphere(bm, u_segments=24, v_segments=16, radius=0.105)
    for v in bm.verts:
        x, y, z = v.co.x, v.co.y, v.co.z
        # Cartoon head shaping
        if z < 0:
            factor = (-z) / 0.105
            v.co.x *= (1.0 - 0.22 * factor) # Taper to cute rounded chin
            if y < 0:
                v.co.y -= 0.022 * factor # Chin slightly forward
            else:
                v.co.y *= (1.0 - 0.12 * factor)
        # Cute full cheeks
        if -0.04 < z < 0.04 and y < 0:
            v.co.x *= 1.06
            v.co.y -= 0.012
        v.co.z *= 1.12
        v.co.y *= 1.05
        v.co.z += 1.60
    head = make_obj("Cartoon_Head", bm, mats["skin"], subd_levels=2)
    
    # Neck connecting head to torso
    bm_neck = bmesh.new()
    bmesh.ops.create_cone(bm_neck, cap_ends=True, cap_tris=False, segments=18,
                          radius1=0.060, radius2=0.054, depth=0.14)
    for v in bm_neck.verts:
        v.co.z += 1.48
        v.co.y += 0.005
    make_obj("Neck", bm_neck, mats["skin"], subd_levels=1)
    
    # Cute Cartoon Nose: Soft defined bridge and rounded button tip
    bm_nose = bmesh.new()
    bmesh.ops.create_uvsphere(bm_nose, u_segments=16, v_segments=10, radius=0.018)
    for v in bm_nose.verts:
        v.co.x *= 0.85
        v.co.y *= 1.40
        v.co.z *= 0.90
        v.co.y -= 0.118
        v.co.z += 1.585
    make_obj("Cartoon_Nose", bm_nose, mats["skin"], subd_levels=1)
    
    # Warm Cartoon Smile: Defined lips curving into a gentle confident smile
    bm_lips = bmesh.new()
    bmesh.ops.create_uvsphere(bm_lips, u_segments=20, v_segments=12, radius=0.020)
    for v in bm_lips.verts:
        v.co.x *= 1.80
        v.co.y *= 0.40
        v.co.z *= 0.35
        # Upward smile curvature at mouth corners
        smile_curve = (abs(v.co.x) / 0.036)**2 * 0.004
        v.co.z += smile_curve
        v.co.y -= 0.108
        v.co.z += 1.528
    make_obj("Cartoon_Lips", bm_lips, mats["lips"], subd_levels=2)
    
    # Stylized Cartoon Ears
    for side in (-1, 1):
        bm_ear = bmesh.new()
        bmesh.ops.create_uvsphere(bm_ear, u_segments=14, v_segments=10, radius=0.026)
        for v in bm_ear.verts:
            v.co.x *= 0.35
            v.co.y *= 0.85
            v.co.z *= 1.35
            v.co = Euler((0, math.radians(8 * side), math.radians(-12 * side))).to_matrix() @ v.co
            v.co.x += side * 0.098
            v.co.y += 0.005
            v.co.z += 1.60
        make_obj(f"Ear_{'L' if side > 0 else 'R'}", bm_ear, mats["skin"], subd_levels=1)

    # Big Expressive Cartoon Eyes (Animated Pixar Style)
    for side in (-1, 1):
        # Sclera (Eyeball)
        bm_eye = bmesh.new()
        bmesh.ops.create_uvsphere(bm_eye, u_segments=20, v_segments=14, radius=0.021)
        for v in bm_eye.verts:
            v.co.x *= 0.95
            v.co.y *= 0.85
            v.co.x += side * 0.040
            v.co.y -= 0.094
            v.co.z += 1.618
        make_obj(f"EyeBall_{'L' if side > 0 else 'R'}", bm_eye, mats["eye_sclera"], subd_levels=1)
        
        # Iris (Large espresso/amber iris)
        bm_iris = bmesh.new()
        bmesh.ops.create_uvsphere(bm_iris, u_segments=16, v_segments=12, radius=0.0135)
        for v in bm_iris.verts:
            v.co.y *= 0.20
            v.co.x += side * 0.040
            v.co.y -= 0.111
            v.co.z += 1.618
        make_obj(f"Iris_{'L' if side > 0 else 'R'}", bm_iris, mats["eye_iris"], subd_levels=1)
        
        # Pupil (Deep black)
        bm_pupil = bmesh.new()
        bmesh.ops.create_uvsphere(bm_pupil, u_segments=12, v_segments=8, radius=0.0065)
        for v in bm_pupil.verts:
            v.co.y *= 0.20
            v.co.x += side * 0.040
            v.co.y -= 0.114
            v.co.z += 1.618
        make_obj(f"Pupil_{'L' if side > 0 else 'R'}", bm_pupil, mats["eye_pupil"], subd_levels=1)
        
        # Primary Specular Highlight (Big shiny catchlight)
        bm_glint1 = bmesh.new()
        bmesh.ops.create_uvsphere(bm_glint1, u_segments=8, v_segments=6, radius=0.0042)
        for v in bm_glint1.verts:
            v.co.x += side * 0.037 - 0.002
            v.co.y -= 0.115
            v.co.z += 1.623
        make_obj(f"Glint1_{'L' if side > 0 else 'R'}", bm_glint1, mats["eye_glint"], subd_levels=1)
        
        # Secondary Subtle Highlight (Adds depth)
        bm_glint2 = bmesh.new()
        bmesh.ops.create_uvsphere(bm_glint2, u_segments=6, v_segments=4, radius=0.0022)
        for v in bm_glint2.verts:
            v.co.x += side * 0.043 + 0.001
            v.co.y -= 0.114
            v.co.z += 1.613
        make_obj(f"Glint2_{'L' if side > 0 else 'R'}", bm_glint2, mats["eye_glint"], subd_levels=1)
        
        # Upper Curved Eyelash / Eyelid Line
        bm_lid = bmesh.new()
        bmesh.ops.create_cube(bm_lid, size=1.0)
        for v in bm_lid.verts:
            v.co.x *= 0.026
            v.co.y *= 0.005
            v.co.z *= 0.0045
            # Arch over eyeball
            v.co = Euler((0, 0, math.radians(-6 * side))).to_matrix() @ v.co
            v.co.x += side * 0.040
            v.co.y -= 0.111
            v.co.z += 1.634
        make_obj(f"EyeLid_{'L' if side > 0 else 'R'}", bm_lid, mats["eyeliner"], subd_levels=1)
        
        # Confident Cartoon Eyebrows
        bm_brow = bmesh.new()
        bmesh.ops.create_cube(bm_brow, size=1.0)
        for v in bm_brow.verts:
            v.co.x *= 0.032
            v.co.y *= 0.006
            v.co.z *= 0.007
            v.co = Euler((0, 0, math.radians(12 * side))).to_matrix() @ v.co
            v.co.x += side * 0.042
            v.co.y -= 0.118
            v.co.z += 1.650
        make_obj(f"Eyebrow_{'L' if side > 0 else 'R'}", bm_brow, mats["eyebrow"], subd_levels=1)

def build_cartoon_hair(mats):
    # Voluminous, smooth cartoon hair locks framing face and neck
    strands = [
        # (center_x, center_y, center_z, scale_x, scale_y, scale_z, rot_x, rot_y, rot_z)
        # Sweeping bangs across forehead
        (-0.028, -0.110, 1.660, 0.026, 0.016, 0.045, 20, 12, 22),
        (0.014, -0.112, 1.656, 0.028, 0.016, 0.048, 22, -10, -18),
        (-0.058, -0.102, 1.650, 0.024, 0.015, 0.046, 16, 20, 32),
        (0.050, -0.104, 1.648, 0.026, 0.015, 0.045, 18, -18, -26),
        # Sideburns
        (-0.090, -0.035, 1.595, 0.020, 0.026, 0.055, -10, 10, 5),
        (0.090, -0.035, 1.595, 0.020, 0.026, 0.055, -10, -10, -5),
        (-0.084, -0.010, 1.565, 0.018, 0.024, 0.050, -15, 5, 8),
        (0.084, -0.010, 1.565, 0.018, 0.024, 0.050, -15, -5, -8),
        # Back locks
        (-0.040, 0.075, 1.545, 0.030, 0.022, 0.055, -25, 10, 10),
        (0.040, 0.075, 1.545, 0.030, 0.022, 0.055, -25, -10, -10),
    ]
    
    bm_combined = bmesh.new()
    for sx, sy, sz, scx, scy, scz, rx, ry, rz in strands:
        bm_piece = bmesh.new()
        bmesh.ops.create_cone(bm_piece, cap_ends=True, cap_tris=False, segments=12,
                              radius1=scx, radius2=scx * 0.25, depth=scz * 2)
        for v in bm_piece.verts:
            v.co.y *= (scy / scx)
        rot_m = Euler((math.radians(rx), math.radians(ry), math.radians(rz))).to_matrix()
        for v in bm_piece.verts:
            v.co = rot_m @ v.co
            v.co += Vector((sx, sy, sz))
        
        for v in bm_piece.verts:
            bm_combined.verts.new(v.co)
        bm_combined.verts.ensure_lookup_table()
        vert_offset = len(bm_combined.verts) - len(bm_piece.verts)
        for f in bm_piece.faces:
            bm_combined.faces.new([bm_combined.verts[vert_offset + v.index] for v in f.verts])
        bm_piece.free()
        
    make_obj("Cartoon_Hair", bm_combined, mats["hair"], subd_levels=2)

def build_cartoon_hat(mats):
    # Baseball Cap Crown: Sits naturally on the head, tilted back ~8° for a cool youthful look
    bm_crown = bmesh.new()
    bmesh.ops.create_uvsphere(bm_crown, u_segments=28, v_segments=18, radius=0.116)
    
    verts_to_remove = [v for v in bm_crown.verts if v.co.z < -0.020]
    bmesh.ops.delete(bm_crown, geom=verts_to_remove, context='VERTS')
    
    tilt_m = Euler((math.radians(-8), math.radians(-2), math.radians(2))).to_matrix()
    for v in bm_crown.verts:
        v.co.x *= 0.98
        v.co.y *= 1.05
        v.co.z *= 0.95
        v.co = tilt_m @ v.co
        v.co.x += 0.002
        v.co.y += 0.015
        v.co.z += 1.685
        
    cap_crown = make_obj("Cap_Crown", bm_crown, mats["cap_crown"], subd_levels=1)
    mod_solid = cap_crown.modifiers.new("Solidify", 'SOLIDIFY')
    mod_solid.thickness = 0.006
    mod_solid.offset = 1.0
    
    # Cap Top Button
    bm_button = bmesh.new()
    bmesh.ops.create_uvsphere(bm_button, u_segments=14, v_segments=10, radius=0.012)
    for v in bm_button.verts:
        v.co.z *= 0.45
        v.co.x += 0.002
        v.co.y += 0.015
        v.co.z += 1.808
    make_obj("Cap_Button", bm_button, mats["cap_button"], subd_levels=1)
    
    # Curved Baseball Cap Visor / Brim
    bm_visor = bmesh.new()
    bmesh.ops.create_grid(bm_visor, x_segments=16, y_segments=12, size=0.072)
    for v in bm_visor.verts:
        arch = (1.0 - (v.co.x / 0.072)**2) * 0.018
        v.co.z += arch
        dist_forward = (0.072 - v.co.y)
        v.co.z -= dist_forward * 0.18
        y_norm = dist_forward / 0.144
        v.co.x *= (1.0 - 0.22 * (y_norm**2))
        v.co.y -= 0.132
        v.co.z += 1.670
        
    visor = make_obj("Cap_Visor", bm_visor, mats["cap_visor"], subd_levels=1)
    mod_v_sol = visor.modifiers.new("Solidify", 'SOLIDIFY')
    mod_v_sol.thickness = 0.005
    
    # Front Embroidered Patch / Emblem
    bm_patch = bmesh.new()
    bmesh.ops.create_cube(bm_patch, size=1.0)
    for v in bm_patch.verts:
        v.co.x *= 0.028
        v.co.y *= 0.004
        v.co.z *= 0.018
        v.co.y += (v.co.x / 0.028)**2 * 0.003
        v.co = Euler((math.radians(10), 0, 0)).to_matrix() @ v.co
        v.co.y -= 0.118
        v.co.z += 1.725
    make_obj("Cap_Patch", bm_patch, mats["cap_patch"], subd_levels=1)
    
    # Emblem Logo on Patch
    bm_emb = bmesh.new()
    bmesh.ops.create_cube(bm_emb, size=1.0)
    for v in bm_emb.verts:
        v.co.x *= 0.016
        v.co.y *= 0.002
        v.co.z *= 0.010
        v.co = Euler((math.radians(10), 0, 0)).to_matrix() @ v.co
        v.co.y -= 0.123
        v.co.z += 1.725
    make_obj("Cap_Emblem", bm_emb, mats["cap_emblem"], subd_levels=1)

def build_cartoon_hoodie_and_arms(mats):
    # Continuous organic hoodie body with realistic dropped shoulders
    bm_torso = bmesh.new()
    bmesh.ops.create_uvsphere(bm_torso, u_segments=24, v_segments=16, radius=0.20)
    for v in bm_torso.verts:
        v.co.x *= 1.25 # Shoulders ~ 0.50m
        v.co.y *= 0.85
        v.co.z *= 1.35
        z_rel = (v.co.z) / 0.27
        if z_rel < 0:
            v.co.x *= (1.0 + 0.08 * z_rel)
            v.co.y *= (1.0 + 0.12 * z_rel)
        else:
            v.co.x *= (1.0 + 0.15 * z_rel)
        v.co.y -= 0.01
        v.co.z += 1.24
    make_obj("Hoodie_Body", bm_torso, mats["hoodie"], subd_levels=2)
    
    # Bottom Ribbed Waistband
    bm_rib = bmesh.new()
    bmesh.ops.create_cone(bm_rib, cap_ends=False, segments=24, radius1=0.21, radius2=0.22, depth=0.08)
    for v in bm_rib.verts:
        v.co.y *= 0.82
        v.co.y -= 0.01
        v.co.z += 0.99
    make_obj("Hoodie_HemRib", bm_rib, mats["hoodie_rib"], subd_levels=1)
    
    # Kangaroo Pocket
    bm_pock = bmesh.new()
    bmesh.ops.create_cube(bm_pock, size=1.0)
    for v in bm_pock.verts:
        v.co.x *= 0.18
        v.co.y *= 0.035
        v.co.z *= 0.095
        if v.co.z > 0:
            v.co.x *= 0.70
        v.co.y += (v.co.x / 0.18)**2 * 0.015
        v.co.y -= 0.190
        v.co.z += 1.10
    make_obj("Hoodie_Pocket", bm_pock, mats["hoodie"], subd_levels=1)
    
    # Draped Hood around collar & neck
    bm_hood = bmesh.new()
    bmesh.ops.create_uvsphere(bm_hood, u_segments=22, v_segments=14, radius=0.15)
    verts_del = [v for v in bm_hood.verts if v.co.y < -0.02 and v.co.z > 0]
    bmesh.ops.delete(bm_hood, geom=verts_del, context='VERTS')
    for v in bm_hood.verts:
        v.co.x *= 1.15
        v.co.y *= 0.95
        v.co.z *= 0.85
        v.co.y += 0.06
        v.co.z += 1.42
    hood = make_obj("Hood_Drape", bm_hood, mats["hoodie"], subd_levels=1)
    mod_h_sol = hood.modifiers.new("Solidify", 'SOLIDIFY')
    mod_h_sol.thickness = 0.008
    
    # Thick Collar Rim
    bm_col = bmesh.new()
    make_torus_bm(bm_col, major_radius=0.10, minor_radius=0.022, major_segments=24, minor_segments=8)
    for v in bm_col.verts:
        v.co.x *= 1.05
        v.co.y *= 0.95
        v.co.y -= 0.01
        v.co.z += 1.43
    make_obj("Hoodie_Collar", bm_col, mats["hoodie_rib"], subd_levels=1)
    
    # Drawstring cords hanging down
    for side in (-1, 1):
        pts = [
            Vector((side * 0.038, -0.165, 1.40)),
            Vector((side * 0.036, -0.176, 1.34)),
            Vector((side * 0.034, -0.182, 1.28)),
            Vector((side * 0.032, -0.180, 1.22)),
            Vector((side * 0.030, -0.175, 1.16)),
        ]
        bm_cord = make_tube_along_curve(pts, radius=0.0035, segments=10)
        make_obj(f"Cord_{'L' if side > 0 else 'R'}", bm_cord, mats["cord"], subd_levels=1)
        
        # Aglet
        bm_aglet = bmesh.new()
        bmesh.ops.create_cone(bm_aglet, cap_ends=True, segments=10, radius1=0.0045, radius2=0.0035, depth=0.022)
        for v in bm_aglet.verts:
            v.co.x += side * 0.030
            v.co.y -= 0.175
            v.co.z += 1.15
        make_obj(f"Aglet_{'L' if side > 0 else 'R'}", bm_aglet, mats["metal"])

    # Sleeves & Hands (Relaxed posture: hands entering pocket)
    for side in (-1, 1):
        # Continuous sleeve from shoulder to wrist
        bm_sleeve = bmesh.new()
        # Ring 0 (Shoulder socket): Z=1.32, X=side*0.25, Y=0.0
        # Ring 1 (Elbow): Z=1.18, X=side*0.26, Y=-0.06
        # Ring 2 (Wrist): Z=1.08, X=side*0.17, Y=-0.16
        rings_data = [
            (Vector((side * 0.25, 0.00, 1.32)), 0.080),
            (Vector((side * 0.26, -0.06, 1.20)), 0.072),
            (Vector((side * 0.22, -0.11, 1.12)), 0.064),
            (Vector((side * 0.17, -0.16, 1.08)), 0.052),
        ]
        rings = []
        for center, rad in rings_data:
            ring = []
            for s in range(12):
                ang = 2.0 * math.pi * s / 12
                # plane perpendicular to arm direction
                x = center.x + rad * math.cos(ang)
                y = center.y + rad * math.sin(ang) * 0.8
                z = center.z + rad * math.sin(ang) * 0.6
                ring.append(bm_sleeve.verts.new((x, y, z)))
            rings.append(ring)
        bm_sleeve.verts.ensure_lookup_table()
        for r in range(len(rings) - 1):
            for s in range(12):
                ns = (s + 1) % 12
                bm_sleeve.faces.new([rings[r][s], rings[r][ns], rings[r+1][ns], rings[r+1][s]])
        make_obj(f"Sleeve_{'L' if side > 0 else 'R'}", bm_sleeve, mats["hoodie"], subd_levels=2)
        
        # Ribbed Wrist Cuff
        bm_cuff = bmesh.new()
        make_torus_bm(bm_cuff, major_radius=0.046, minor_radius=0.015, major_segments=16, minor_segments=8)
        for v in bm_cuff.verts:
            v.co = Euler((math.radians(35), math.radians(40 * side), 0)).to_matrix() @ v.co
            v.co.x += side * 0.16
            v.co.y -= 0.168
            v.co.z += 1.08
        make_obj(f"Cuff_{'L' if side > 0 else 'R'}", bm_cuff, mats["hoodie_rib"], subd_levels=1)
        
        # Proper Cartoon Hand: Palm + Thumb hooked over pocket + fingers
        bm_hand = bmesh.new()
        # Palm base
        bmesh.ops.create_uvsphere(bm_hand, u_segments=14, v_segments=10, radius=0.034)
        for v in bm_hand.verts:
            v.co.x *= 0.85
            v.co.y *= 1.30
            v.co.z *= 0.50
            v.co = Euler((math.radians(25), math.radians(30 * side), 0)).to_matrix() @ v.co
            v.co.x += side * 0.125
            v.co.y -= 0.195
            v.co.z += 1.07
        # Thumb visible outside pocket
        bm_thumb = bmesh.new()
        bmesh.ops.create_cone(bm_thumb, cap_ends=True, segments=8, radius1=0.010, radius2=0.007, depth=0.032)
        for v in bm_thumb.verts:
            v.co = Euler((math.radians(-30), math.radians(-15 * side), math.radians(45 * side))).to_matrix() @ v.co
            v.co.x += side * 0.145
            v.co.y -= 0.185
            v.co.z += 1.095
        # Merge thumb into hand
        for v in bm_thumb.verts:
            bm_hand.verts.new(v.co)
        bm_hand.verts.ensure_lookup_table()
        v_offset = len(bm_hand.verts) - len(bm_thumb.verts)
        for f in bm_thumb.faces:
            bm_hand.faces.new([bm_hand.verts[v_offset + v.index] for v in f.verts])
        bm_thumb.free()
        
        make_obj(f"Hand_{'L' if side > 0 else 'R'}", bm_hand, mats["skin"], subd_levels=2)

def build_cartoon_pants(mats):
    # Pelvis
    bm_pelvis = bmesh.new()
    bmesh.ops.create_uvsphere(bm_pelvis, u_segments=24, v_segments=16, radius=0.20)
    for v in bm_pelvis.verts:
        v.co.x *= 1.05
        v.co.y *= 0.85
        v.co.z *= 0.80
        v.co.y -= 0.01
        v.co.z += 0.93
    make_obj("Pants_Pelvis", bm_pelvis, mats["pants"], subd_levels=2)
    
    # Continuous organic pant legs (thighs -> knees -> calves -> cuffs)
    for side in (-1, 1):
        bm_leg = bmesh.new()
        # Continuous leg rings from crotch down to ankle
        leg_rings_data = [
            # (center, radius_x, radius_y)
            (Vector((side * 0.115, -0.005, 0.82)), 0.098, 0.092), # Upper thigh
            (Vector((side * 0.118, -0.008, 0.68)), 0.092, 0.088), # Mid thigh
            (Vector((side * 0.122, -0.012, 0.52)), 0.086, 0.082), # Knee
            (Vector((side * 0.126, -0.005, 0.36)), 0.088, 0.084), # Calf
            (Vector((side * 0.130, 0.000, 0.20)), 0.090, 0.086), # Lower calf
            (Vector((side * 0.134, 0.005, 0.13)), 0.094, 0.090), # Ankle cuff opening
        ]
        rings = []
        for center, rx, ry in leg_rings_data:
            ring = []
            for s in range(16):
                ang = 2.0 * math.pi * s / 16
                x = center.x + rx * math.cos(ang)
                y = center.y + ry * math.sin(ang)
                z = center.z
                ring.append(bm_leg.verts.new((x, y, z)))
            rings.append(ring)
        bm_leg.verts.ensure_lookup_table()
        for r in range(len(rings) - 1):
            for s in range(16):
                ns = (s + 1) % 16
                bm_leg.faces.new([rings[r][s], rings[r][ns], rings[r+1][ns], rings[r+1][s]])
        make_obj(f"Pants_Leg_{'L' if side > 0 else 'R'}", bm_leg, mats["pants"], subd_levels=2)
        
        # Cargo Pockets on outer thighs
        bm_cargo = bmesh.new()
        bmesh.ops.create_cube(bm_cargo, size=1.0)
        for v in bm_cargo.verts:
            v.co.x *= 0.026
            v.co.y *= 0.070
            v.co.z *= 0.085
            v.co.x += side * 0.225
            v.co.y -= 0.010
            v.co.z += 0.66
        make_obj(f"Cargo_Pocket_{'L' if side > 0 else 'R'}", bm_cargo, mats["pants_detail"], subd_levels=1)
        
        bm_flap = bmesh.new()
        bmesh.ops.create_cube(bm_flap, size=1.0)
        for v in bm_flap.verts:
            v.co.x *= 0.028
            v.co.y *= 0.072
            v.co.z *= 0.020
            v.co.x += side * 0.228
            v.co.y -= 0.010
            v.co.z += 0.73
        make_obj(f"Cargo_Flap_{'L' if side > 0 else 'R'}", bm_flap, mats["pants_detail"], subd_levels=1)

def build_cartoon_sneakers(mats):
    # Chunky Cartoon Skate Sneakers
    for side in (-1, 1):
        # Platform Midsole (White)
        bm_sole = bmesh.new()
        bmesh.ops.create_cube(bm_sole, size=1.0)
        for v in bm_sole.verts:
            v.co.x *= 0.072
            v.co.y *= 0.155
            v.co.z *= 0.030
            y_pos = -v.co.y / 0.155
            if -0.2 < y_pos < 0.3:
                v.co.x *= 0.88
            if y_pos > 0.35:
                v.co.z += ((y_pos - 0.35) / 0.65)**2 * 0.020
            v.co = Euler((0, 0, math.radians(7 * side))).to_matrix() @ v.co
            v.co.x += side * 0.138
            v.co.y -= 0.035
            v.co.z += 0.032
        make_obj(f"Sneaker_Sole_{'L' if side > 0 else 'R'}", bm_sole, mats["sneaker_sole"], subd_levels=1)
        
        # Bottom Gum Tread
        bm_tread = bmesh.new()
        bmesh.ops.create_cube(bm_tread, size=1.0)
        for v in bm_tread.verts:
            v.co.x *= 0.070
            v.co.y *= 0.152
            v.co.z *= 0.008
            v.co = Euler((0, 0, math.radians(7 * side))).to_matrix() @ v.co
            v.co.x += side * 0.138
            v.co.y -= 0.035
            v.co.z += 0.008
        make_obj(f"Sneaker_Tread_{'L' if side > 0 else 'R'}", bm_tread, mats["sneaker_gum"])
        
        # Sneaker Upper (White Leather)
        bm_upper = bmesh.new()
        bmesh.ops.create_uvsphere(bm_upper, u_segments=22, v_segments=16, radius=0.080)
        for v in bm_upper.verts:
            v.co.x *= 0.74
            v.co.y *= 1.65
            v.co.z *= 0.65
            if v.co.z < -0.01:
                v.co.z = -0.01
            v.co = Euler((0, 0, math.radians(7 * side))).to_matrix() @ v.co
            v.co.x += side * 0.138
            v.co.y -= 0.035
            v.co.z += 0.075
        make_obj(f"Sneaker_Upper_{'L' if side > 0 else 'R'}", bm_upper, mats["sneaker_white"], subd_levels=1)
        
        # Accent Stripe (Sage Green)
        bm_stripe = bmesh.new()
        bmesh.ops.create_cube(bm_stripe, size=1.0)
        for v in bm_stripe.verts:
            v.co.x *= 0.006
            v.co.y *= 0.080
            v.co.z *= 0.020
            v.co = Euler((math.radians(-12), 0, math.radians(7 * side))).to_matrix() @ v.co
            v.co.x += side * (0.138 + 0.052 * side)
            v.co.y -= 0.030
            v.co.z += 0.075
        make_obj(f"Sneaker_Stripe_{'L' if side > 0 else 'R'}", bm_stripe, mats["sneaker_accent"], subd_levels=1)
        
        # Padded Collar / Ankle Rim (Black)
        bm_rim = bmesh.new()
        make_torus_bm(bm_rim, major_radius=0.048, minor_radius=0.015, major_segments=20, minor_segments=10)
        for v in bm_rim.verts:
            v.co = Euler((math.radians(-15), 0, math.radians(7 * side))).to_matrix() @ v.co
            v.co.x += side * 0.138
            v.co.y -= 0.005
            v.co.z += 0.125
        make_obj(f"Sneaker_Collar_{'L' if side > 0 else 'R'}", bm_rim, mats["sneaker_black"], subd_levels=1)
        
        # Tongue
        bm_tongue = bmesh.new()
        bmesh.ops.create_cube(bm_tongue, size=1.0)
        for v in bm_tongue.verts:
            v.co.x *= 0.030
            v.co.y *= 0.068
            v.co.z *= 0.009
            v.co = Euler((math.radians(38), 0, math.radians(7 * side))).to_matrix() @ v.co
            v.co.x += side * 0.138
            v.co.y -= 0.065
            v.co.z += 0.105
        make_obj(f"Sneaker_Tongue_{'L' if side > 0 else 'R'}", bm_tongue, mats["sneaker_black"], subd_levels=1)
        
        # Laces
        for i in range(3):
            bm_lace = bmesh.new()
            bmesh.ops.create_cube(bm_lace, size=1.0)
            for v in bm_lace.verts:
                v.co.x *= 0.026
                v.co.y *= 0.006
                v.co.z *= 0.005
                v.co = Euler((math.radians(38), 0, math.radians(7 * side))).to_matrix() @ v.co
                v.co.x += side * 0.138
                v.co.y -= 0.045 + i * 0.022
                v.co.z += 0.090 + i * 0.015
            make_obj(f"Sneaker_Lace_{i}_{'L' if side > 0 else 'R'}", bm_lace, mats["sneaker_white"], subd_levels=1)

def build_backdrop(mats):
    bm = bmesh.new()
    xs = [-3.5 + i * 0.7 for i in range(11)]
    profile = []
    for y in [-3.2, -2.0, -1.0, 0.5, 1.2]:
        profile.append((y, 0.0))
    for angle_deg in [15, 30, 45, 60, 75, 90]:
        rad = math.radians(angle_deg)
        y = 1.2 + 0.9 * math.sin(rad)
        z = 0.9 * (1.0 - math.cos(rad))
        profile.append((y, z))
    for z in [1.2, 1.8, 2.5, 3.4]:
        profile.append((2.1, z))
        
    grid_verts = []
    for y, z in profile:
        row = []
        for x in xs:
            v = bm.verts.new((x, y, z))
            row.append(v)
        grid_verts.append(row)
    bm.verts.ensure_lookup_table()
    
    for r in range(len(grid_verts) - 1):
        for c in range(len(xs) - 1):
            v1 = grid_verts[r][c]
            v2 = grid_verts[r][c+1]
            v3 = grid_verts[r+1][c+1]
            v4 = grid_verts[r+1][c]
            bm.faces.new([v1, v2, v3, v4])
            
    cyc = make_obj("Studio_Cyclorama", bm, mats["backdrop"], subd_levels=1)
    return cyc

def setup_lighting():
    # 1. Warm Key Light (Front-Right 45 degrees)
    key_data = bpy.data.lights.new(name="Key_Light", type='AREA')
    key_data.energy = 280.0
    key_data.size = 1.4
    key_data.color = (1.0, 0.95, 0.90)
    key_obj = bpy.data.objects.new(name="Key_Light", object_data=key_data)
    key_obj.location = (1.6, -2.2, 2.0)
    dir_k = Vector((0, 0, 1.1)) - key_obj.location
    key_obj.rotation_euler = dir_k.to_track_quat('-Z', 'Y').to_euler()
    bpy.context.scene.collection.objects.link(key_obj)
    
    # 2. Cool Fill Light (Front-Left)
    fill_data = bpy.data.lights.new(name="Fill_Light", type='AREA')
    fill_data.energy = 130.0
    fill_data.size = 2.2
    fill_data.color = (0.86, 0.92, 1.0)
    fill_obj = bpy.data.objects.new(name="Fill_Light", object_data=fill_data)
    fill_obj.location = (-1.8, -2.0, 1.4)
    dir_f = Vector((0, 0, 1.0)) - fill_obj.location
    fill_obj.rotation_euler = dir_f.to_track_quat('-Z', 'Y').to_euler()
    bpy.context.scene.collection.objects.link(fill_obj)
    
    # 3. Rim / Kicker Light (Back-Right, outlines silhouette)
    rim_data = bpy.data.lights.new(name="Rim_Light", type='AREA')
    rim_data.energy = 440.0
    rim_data.size = 1.2
    rim_data.color = (1.0, 0.98, 0.95)
    rim_obj = bpy.data.objects.new(name="Rim_Light", object_data=rim_data)
    rim_obj.location = (-1.2, 1.5, 2.2)
    dir_r = Vector((0, 0, 1.3)) - rim_obj.location
    rim_obj.rotation_euler = dir_r.to_track_quat('-Z', 'Y').to_euler()
    bpy.context.scene.collection.objects.link(rim_obj)
    
    # 4. Top Soft Overhead Light
    top_data = bpy.data.lights.new(name="Top_Light", type='AREA')
    top_data.energy = 80.0
    top_data.size = 2.8
    top_data.color = (0.95, 0.95, 0.98)
    top_obj = bpy.data.objects.new(name="Top_Light", object_data=top_data)
    top_obj.location = (0.0, -0.4, 3.2)
    top_obj.rotation_euler = Euler((0, 0, 0))
    bpy.context.scene.collection.objects.link(top_obj)

def setup_camera():
    cam_data = bpy.data.cameras.new("Main_Camera")
    cam_data.lens = 48.0
    cam_data.sensor_width = 36.0
    
    cam_obj = bpy.data.objects.new("Main_Camera", cam_data)
    cam_obj.location = (0.38, -3.15, 0.98)
    target = Vector((0.0, 0.0, 0.88))
    direction = target - cam_obj.location
    cam_obj.rotation_euler = direction.to_track_quat('-Z', 'Y').to_euler()
    
    bpy.context.scene.collection.objects.link(cam_obj)
    bpy.context.scene.camera = cam_obj
    return cam_obj

def setup_render(output_path, samples=48):
    scene = bpy.context.scene
    scene.render.engine = 'CYCLES'
    scene.cycles.device = 'CPU'
    scene.cycles.samples = samples
    scene.cycles.use_denoising = True
    
    # 1200x1600 (3:4 portrait)
    scene.render.resolution_x = 1200
    scene.render.resolution_y = 1600
    scene.render.resolution_percentage = 100
    
    scene.view_settings.view_transform = 'AgX'
    scene.view_settings.look = 'AgX - High Contrast'
    
    scene.render.filepath = output_path
    scene.render.image_settings.file_format = 'PNG'
    scene.render.image_settings.color_mode = 'RGBA'

def main():
    print("[1/6] Initializing scene...")
    clear_scene()
    
    print("[2/6] Building PBR materials...")
    mats = build_materials()
    
    print("[3/6] Generating organic cartoon character geometry...")
    build_cartoon_head_and_face(mats)
    build_cartoon_hair(mats)
    build_cartoon_hat(mats)
    build_cartoon_hoodie_and_arms(mats)
    build_cartoon_pants(mats)
    build_cartoon_sneakers(mats)
    build_backdrop(mats)
    
    print("[4/6] Setting up studio lighting & camera...")
    setup_lighting()
    setup_camera()
    
    out_blend = "/home/rois/jarvis/blender-character/karakter_pria_topi.blend"
    out_png = "/home/rois/jarvis/blender-character/render_preview.png"
    
    print(f"[5/6] Saving .blend file to {out_blend}...")
    bpy.ops.wm.save_as_mainfile(filepath=out_blend)
    
    print(f"[6/6] Rendering preview with Cycles to {out_png}...")
    setup_render(out_png, samples=48)
    bpy.ops.render.render(write_still=True)
    
    total_tris = sum(len(o.data.polygons) * 2 for o in bpy.data.objects if o.type == 'MESH')
    total_objs = len(bpy.data.objects)
    print(f"DONE! Objects: {total_objs}, Approx Tris: {total_tris}")
    print(f"Blend file: {out_blend}")
    print(f"Render image: {out_png}")

if __name__ == "__main__":
    main()
