#!/usr/bin/env python3
"""
Blender 5.2 - High-Quality 3D Cartoon Human Character
Style: 3D Pixar / Disney animated cartoon style (Friendly 20s male in streetwear with cap).
Features:
- Continuous organic hoodie (Skin modifier + Subsurf, 0 gaps)
- Continuous organic cargo pants (Skin modifier + Subsurf, 0 gaps)
- Expressive cartoon face: large eyes with shiny catchlights, smile with lips, cute nose, rosy cheeks
- Cartoon hands with thumb and fingers resting naturally on pocket
- Detailed chunky skate sneakers: thick platform sole, gum tread, upper panels, laces
- Baseball cap with curved visor, button, and embroidered emblem
"""
import bpy
import bmesh
from mathutils import Vector, Matrix, Euler
import math

def clear_scene():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    if not bpy.data.collections:
        col = bpy.data.collections.new("Collection")
        bpy.context.scene.collection.children.link(col)

def create_pbr_material(name, base_color, roughness=0.5, metallic=0.0, sss_weight=0.0, sss_radius=(1.0, 0.35, 0.2), sheen_weight=0.0):
    mat = bpy.data.materials.new(name=name)
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()
    
    out = nodes.new("ShaderNodeOutputMaterial")
    out.location = (350, 0)
    
    bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.location = (0, 0)
    links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
    
    bsdf.inputs["Base Color"].default_value = (*base_color, 1.0)
    bsdf.inputs["Roughness"].default_value = roughness
    bsdf.inputs["Metallic"].default_value = metallic
    
    if "Subsurface Weight" in bsdf.inputs and sss_weight > 0:
        bsdf.inputs["Subsurface Weight"].default_value = sss_weight
        bsdf.inputs["Subsurface Radius"].default_value = sss_radius
        bsdf.inputs["Subsurface Scale"].default_value = 0.03
        
    if "Sheen Weight" in bsdf.inputs and sheen_weight > 0:
        bsdf.inputs["Sheen Weight"].default_value = sheen_weight
        
    return mat

def apply_smooth(obj):
    for p in obj.data.polygons:
        p.use_smooth = True
    obj.data.update()

def create_primitive(type_name, location=(0,0,0), scale=(1,1,1), rotation=(0,0,0), **kwargs):
    if type_name == 'SPHERE':
        bpy.ops.mesh.primitive_uv_sphere_add(
            segments=kwargs.get('u', 20),
            ring_count=kwargs.get('v', 14),
            radius=kwargs.get('radius', 1.0),
            location=location
        )
    elif type_name == 'CYLINDER':
        bpy.ops.mesh.primitive_cylinder_add(
            vertices=kwargs.get('v', 16),
            radius=kwargs.get('radius', 1.0),
            depth=kwargs.get('depth', 2.0),
            location=location
        )
    elif type_name == 'CONE':
        bpy.ops.mesh.primitive_cone_add(
            vertices=kwargs.get('v', 16),
            radius1=kwargs.get('radius1', 1.0),
            radius2=kwargs.get('radius2', 0.5),
            depth=kwargs.get('depth', 2.0),
            location=location
        )
    elif type_name == 'CUBE':
        bpy.ops.mesh.primitive_cube_add(
            size=kwargs.get('size', 1.0),
            location=location
        )
    obj = bpy.context.view_layer.objects.active
    obj.scale = scale
    obj.rotation_euler = Euler(rotation)
    bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
    return obj

def build_materials():
    mats = {}
    # Warm youthful cartoon human skin with healthy peach tone and soft SSS
    mats["skin"] = create_pbr_material("M_Skin", (0.92, 0.72, 0.60), roughness=0.42, sss_weight=0.55)
    mats["cheeks"] = create_pbr_material("M_Cheeks", (0.94, 0.54, 0.52), roughness=0.45, sss_weight=0.6) # Rosy blush
    mats["lips"] = create_pbr_material("M_Lips", (0.84, 0.44, 0.42), roughness=0.35, sss_weight=0.4)
    
    # Animated Cartoon Eyes
    mats["eye_sclera"] = create_pbr_material("M_EyeSclera", (0.97, 0.97, 0.98), roughness=0.06)
    mats["eye_iris"] = create_pbr_material("M_EyeIris", (0.24, 0.13, 0.06), roughness=0.04) # Rich hazel-amber
    mats["eye_pupil"] = create_pbr_material("M_EyePupil", (0.01, 0.01, 0.01), roughness=0.02)
    mats["eye_glint"] = create_pbr_material("M_EyeGlint", (1.0, 1.0, 1.0), roughness=0.01)
    mats["eyeliner"] = create_pbr_material("M_EyeLiner", (0.05, 0.035, 0.03), roughness=0.4)
    mats["eyebrow"] = create_pbr_material("M_Eyebrow", (0.05, 0.035, 0.03), roughness=0.6)
    
    # Hair
    mats["hair"] = create_pbr_material("M_Hair", (0.05, 0.038, 0.03), roughness=0.48, sheen_weight=0.4)
    
    # Streetwear Cap (Vintage Dark Navy)
    mats["cap_main"] = create_pbr_material("M_Cap_Main", (0.04, 0.06, 0.11), roughness=0.75, sheen_weight=0.6)
    mats["cap_visor"] = create_pbr_material("M_Cap_Visor", (0.03, 0.05, 0.09), roughness=0.70, sheen_weight=0.5)
    mats["cap_button"] = create_pbr_material("M_Cap_Button", (0.08, 0.12, 0.18), roughness=0.65)
    mats["cap_patch"] = create_pbr_material("M_Cap_Patch", (0.90, 0.84, 0.74), roughness=0.55)
    mats["cap_emblem"] = create_pbr_material("M_Cap_Emblem", (0.78, 0.22, 0.18), roughness=0.5)
    mats["metal"] = create_pbr_material("M_Metal", (0.75, 0.75, 0.78), roughness=0.25, metallic=0.95)
    
    # Streetwear Hoodie (Matcha / Sage Green)
    mats["hoodie"] = create_pbr_material("M_Hoodie", (0.17, 0.30, 0.22), roughness=0.80, sheen_weight=0.7)
    mats["hoodie_rib"] = create_pbr_material("M_HoodieRib", (0.13, 0.24, 0.17), roughness=0.88, sheen_weight=0.6)
    mats["cord"] = create_pbr_material("M_Cord", (0.88, 0.86, 0.83), roughness=0.65)
    
    # Cargo Pants (Dark Charcoal Slate)
    mats["pants"] = create_pbr_material("M_Pants", (0.07, 0.08, 0.10), roughness=0.82, sheen_weight=0.35)
    mats["pants_detail"] = create_pbr_material("M_PantsDetail", (0.10, 0.12, 0.15), roughness=0.8)
    
    # Skate Sneakers
    mats["sneaker_white"] = create_pbr_material("M_SneakerWhite", (0.92, 0.92, 0.93), roughness=0.36)
    mats["sneaker_black"] = create_pbr_material("M_SneakerBlack", (0.03, 0.03, 0.04), roughness=0.45)
    mats["sneaker_accent"] = create_pbr_material("M_SneakerAccent", (0.17, 0.30, 0.22), roughness=0.45)
    mats["sneaker_sole"] = create_pbr_material("M_SneakerSole", (0.95, 0.94, 0.93), roughness=0.50)
    mats["sneaker_gum"] = create_pbr_material("M_SneakerGum", (0.48, 0.33, 0.18), roughness=0.6)
    
    # Studio Backdrop
    mats["backdrop"] = create_pbr_material("M_Backdrop", (0.22, 0.24, 0.28), roughness=0.92)
    
    return mats

def build_continuous_hoodie(mats):
    # Built via Skin modifier on skeleton spine -> 100% seamless cloth flow!
    me = bpy.data.meshes.new("Hoodie_Skel")
    ob = bpy.data.objects.new("Streetwear_Hoodie", me)
    bpy.context.scene.collection.objects.link(ob)
    
    bm = bmesh.new()
    v_hem = bm.verts.new((0, -0.01, 0.98))
    v_belly = bm.verts.new((0, -0.01, 1.10))
    v_chest = bm.verts.new((0, -0.01, 1.25))
    v_collar = bm.verts.new((0, 0.00, 1.42))
    
    bm.edges.new([v_hem, v_belly])
    bm.edges.new([v_belly, v_chest])
    bm.edges.new([v_chest, v_collar])
    
    arm_verts = {}
    for side in (-1, 1):
        v_sh = bm.verts.new((side * 0.20, -0.01, 1.32))
        v_elb = bm.verts.new((side * 0.26, -0.05, 1.18))
        v_wri = bm.verts.new((side * 0.17, -0.14, 1.08))
        
        bm.edges.new([v_chest, v_sh])
        bm.edges.new([v_sh, v_elb])
        bm.edges.new([v_elb, v_wri])
        arm_verts[side] = (v_sh, v_elb, v_wri)
        
    bm.to_mesh(me)
    bm.free()
    
    mod_skin = ob.modifiers.new("Skin", 'SKIN')
    mod_sub = ob.modifiers.new("Subsurf", 'SUBSURF')
    mod_sub.levels = 2
    
    # Set radii on vertices for oversized streetwear silhouette
    layer = me.skin_vertices[0]
    layer.data[0].radius = (0.21, 0.15) # hem
    layer.data[1].radius = (0.22, 0.16) # belly
    layer.data[2].radius = (0.23, 0.17) # chest
    layer.data[3].radius = (0.12, 0.10) # collar
    
    # Left and Right arms
    layer.data[4].radius = (0.088, 0.088) # sh L
    layer.data[5].radius = (0.076, 0.076) # elb L
    layer.data[6].radius = (0.060, 0.060) # wri L
    
    layer.data[7].radius = (0.088, 0.088) # sh R
    layer.data[8].radius = (0.076, 0.076) # elb R
    layer.data[9].radius = (0.060, 0.060) # wri R
    
    ob.data.materials.append(mats["hoodie"])
    apply_smooth(ob)
    
    # Kangaroo Pocket on front of belly
    pock = create_primitive(
        'CUBE',
        location=(0, -0.168, 1.10),
        scale=(0.18, 0.035, 0.095),
        size=1.0
    )
    pock.name = "Hoodie_Pocket"
    pock.data.materials.append(mats["hoodie"])
    mod_p = pock.modifiers.new("Bevel", 'BEVEL')
    mod_p.width = 0.008
    mod_p.segments = 2
    apply_smooth(pock)
    
    # Draped Hood behind neck
    hood_back = create_primitive(
        'SPHERE',
        location=(0, 0.08, 1.40),
        scale=(0.16, 0.14, 0.12),
        radius=1.0
    )
    hood_back.name = "Hood_Drape"
    hood_back.data.materials.append(mats["hoodie"])
    apply_smooth(hood_back)
    
    # Collar Rim
    collar = create_primitive('CYLINDER', location=(0, -0.01, 1.43), scale=(0.11, 0.09, 0.025), radius=1.0, depth=2.0)
    collar.name = "Hoodie_Collar"
    collar.data.materials.append(mats["hoodie_rib"])
    apply_smooth(collar)
    
    # Drawstrings
    for side in (-1, 1):
        cord = create_primitive('CYLINDER', location=(side * 0.038, -0.180, 1.28), scale=(0.004, 0.004, 0.12), radius=1.0, depth=2.0)
        cord.name = f"Cord_{'L' if side > 0 else 'R'}"
        cord.data.materials.append(mats["cord"])
        apply_smooth(cord)
        
        aglet = create_primitive('CYLINDER', location=(side * 0.038, -0.180, 1.15), scale=(0.005, 0.005, 0.015), radius=1.0, depth=2.0)
        aglet.name = f"Aglet_{'L' if side > 0 else 'R'}"
        aglet.data.materials.append(mats["metal"])
        apply_smooth(aglet)
        
        # Ribbed Wrist Cuffs
        cuff = create_primitive('CYLINDER', location=(side * 0.16, -0.155, 1.07), scale=(0.058, 0.058, 0.025), rotation=(math.radians(35), math.radians(40 * side), 0), radius=1.0, depth=2.0)
        cuff.name = f"Cuff_{'L' if side > 0 else 'R'}"
        cuff.data.materials.append(mats["hoodie_rib"])
        apply_smooth(cuff)
        
        # Cartoon Hands: Palm + Thumb + 3 Fingers resting naturally on pocket rim
        hand = create_primitive('SPHERE', location=(side * 0.130, -0.185, 1.06), scale=(0.030, 0.042, 0.025), rotation=(math.radians(25), math.radians(30 * side), 0), radius=1.0)
        hand.name = f"Hand_{'L' if side > 0 else 'R'}"
        hand.data.materials.append(mats["skin"])
        apply_smooth(hand)
        
        # Visible Thumb hooked over pocket
        thumb = create_primitive('CYLINDER', location=(side * 0.148, -0.190, 1.085), scale=(0.009, 0.009, 0.018), rotation=(math.radians(-30), math.radians(-15 * side), math.radians(45 * side)), radius=1.0, depth=2.0)
        thumb.name = f"Thumb_{'L' if side > 0 else 'R'}"
        thumb.data.materials.append(mats["skin"])
        apply_smooth(thumb)

def build_continuous_pants(mats):
    # Built via Skin modifier -> 100% continuous, ZERO knee gaps, smooth cargo pants!
    me = bpy.data.meshes.new("Pants_Skel")
    ob = bpy.data.objects.new("Cargo_Pants", me)
    bpy.context.scene.collection.objects.link(ob)
    
    bm = bmesh.new()
    v_waist = bm.verts.new((0, -0.01, 0.96))
    v_crotch = bm.verts.new((0, -0.01, 0.85))
    bm.edges.new([v_waist, v_crotch])
    
    # Left & Right Legs
    for side in (-1, 1):
        v_hip = bm.verts.new((side * 0.115, -0.01, 0.82))
        v_thigh = bm.verts.new((side * 0.118, -0.01, 0.68))
        v_knee = bm.verts.new((side * 0.122, -0.015, 0.52))
        v_calf = bm.verts.new((side * 0.126, -0.005, 0.34))
        v_ank = bm.verts.new((side * 0.130, 0.000, 0.14))
        
        bm.edges.new([v_crotch, v_hip])
        bm.edges.new([v_hip, v_thigh])
        bm.edges.new([v_thigh, v_knee])
        bm.edges.new([v_knee, v_calf])
        bm.edges.new([v_calf, v_ank])
        
    bm.to_mesh(me)
    bm.free()
    
    mod_skin = ob.modifiers.new("Skin", 'SKIN')
    mod_sub = ob.modifiers.new("Subsurf", 'SUBSURF')
    mod_sub.levels = 2
    
    layer = me.skin_vertices[0]
    layer.data[0].radius = (0.20, 0.15) # waist
    layer.data[1].radius = (0.19, 0.14) # crotch
    
    # Leg L (indices 2..6)
    layer.data[2].radius = (0.098, 0.095) # hip
    layer.data[3].radius = (0.094, 0.090) # thigh
    layer.data[4].radius = (0.088, 0.086) # knee
    layer.data[5].radius = (0.088, 0.086) # calf
    layer.data[6].radius = (0.092, 0.090) # ankle flare
    
    # Leg R (indices 7..11)
    layer.data[7].radius = (0.098, 0.095) # hip
    layer.data[8].radius = (0.094, 0.090) # thigh
    layer.data[9].radius = (0.088, 0.086) # knee
    layer.data[10].radius = (0.088, 0.086) # calf
    layer.data[11].radius = (0.092, 0.090) # ankle flare
    
    ob.data.materials.append(mats["pants"])
    apply_smooth(ob)
    
    # Cargo pockets on outer thighs
    for side in (-1, 1):
        cargo = create_primitive(
            'CUBE',
            location=(side * 0.222, -0.01, 0.66),
            scale=(0.026, 0.075, 0.090),
            size=1.0
        )
        cargo.name = f"Cargo_Pocket_{'L' if side > 0 else 'R'}"
        cargo.data.materials.append(mats["pants_detail"])
        mod_c = cargo.modifiers.new("Bevel", 'BEVEL')
        mod_c.width = 0.005
        apply_smooth(cargo)
        
        flap = create_primitive(
            'CUBE',
            location=(side * 0.226, -0.01, 0.73),
            scale=(0.028, 0.078, 0.022),
            size=1.0
        )
        flap.name = f"Cargo_Flap_{'L' if side > 0 else 'R'}"
        flap.data.materials.append(mats["pants_detail"])
        apply_smooth(flap)

def build_cartoon_sneakers(mats):
    # Chunky Skate Sneakers with realistic layered construction
    for side in (-1, 1):
        # Chunky Midsole (White)
        midsole = create_primitive(
            'CUBE',
            location=(side * 0.138, -0.035, 0.032),
            scale=(0.075, 0.160, 0.028),
            rotation=(0, 0, math.radians(7 * side)),
            size=1.0
        )
        midsole.name = f"Sneaker_Midsole_{'L' if side > 0 else 'R'}"
        midsole.data.materials.append(mats["sneaker_sole"])
        mod_m = midsole.modifiers.new("Bevel", 'BEVEL')
        mod_m.width = 0.010
        mod_m.segments = 2
        apply_smooth(midsole)
        
        # Bottom Gum Rubber Outsole (Touching Z=0.0)
        gum = create_primitive(
            'CUBE',
            location=(side * 0.138, -0.035, 0.006),
            scale=(0.074, 0.158, 0.006),
            rotation=(0, 0, math.radians(7 * side)),
            size=1.0
        )
        gum.name = f"Sneaker_Gum_{'L' if side > 0 else 'R'}"
        gum.data.materials.append(mats["sneaker_gum"])
        apply_smooth(gum)
        
        # Toe Cap Bumper
        toe = create_primitive(
            'SPHERE',
            location=(side * 0.138 - 0.015 * math.sin(math.radians(7 * side)), -0.155, 0.045),
            scale=(0.072, 0.065, 0.040),
            rotation=(0, 0, math.radians(7 * side)),
            radius=1.0
        )
        toe.name = f"Sneaker_Toe_{'L' if side > 0 else 'R'}"
        toe.data.materials.append(mats["sneaker_white"])
        apply_smooth(toe)
        
        # Leather Shoe Upper Body
        upper = create_primitive(
            'SPHERE',
            location=(side * 0.138, -0.035, 0.075),
            scale=(0.072, 0.145, 0.055),
            rotation=(0, 0, math.radians(7 * side)),
            radius=1.0
        )
        upper.name = f"Sneaker_Upper_{'L' if side > 0 else 'R'}"
        upper.data.materials.append(mats["sneaker_white"])
        apply_smooth(upper)
        
        # Padded Ankle Collar
        collar = create_primitive(
            'CYLINDER',
            location=(side * 0.138, -0.005, 0.125),
            scale=(0.062, 0.062, 0.025),
            rotation=(math.radians(-15), 0, math.radians(7 * side)),
            radius=1.0, depth=2.0
        )
        collar.name = f"Sneaker_Collar_{'L' if side > 0 else 'R'}"
        collar.data.materials.append(mats["sneaker_black"])
        apply_smooth(collar)
        
        # Side Accent Stripe (Sage Green)
        stripe = create_primitive(
            'CUBE',
            location=(side * (0.138 + 0.052 * side), -0.030, 0.075),
            scale=(0.006, 0.080, 0.018),
            rotation=(math.radians(-12), 0, math.radians(7 * side)),
            size=1.0
        )
        stripe.name = f"Sneaker_Stripe_{'L' if side > 0 else 'R'}"
        stripe.data.materials.append(mats["sneaker_accent"])
        apply_smooth(stripe)
        
        # Padded Tongue
        tongue = create_primitive(
            'CUBE',
            location=(side * 0.138, -0.065, 0.105),
            scale=(0.030, 0.068, 0.009),
            rotation=(math.radians(38), 0, math.radians(7 * side)),
            size=1.0
        )
        tongue.name = f"Sneaker_Tongue_{'L' if side > 0 else 'R'}"
        tongue.data.materials.append(mats["sneaker_black"])
        apply_smooth(tongue)
        
        # Laces on top
        for i in range(3):
            lace = create_primitive(
                'CUBE',
                location=(side * 0.138, -0.045 + i * 0.022, 0.090 + i * 0.015),
                scale=(0.028, 0.007, 0.006),
                rotation=(math.radians(38), 0, math.radians(7 * side)),
                size=1.0
            )
            lace.name = f"Sneaker_Lace_{i}_{'L' if side > 0 else 'R'}"
            lace.data.materials.append(mats["sneaker_white"])
            apply_smooth(lace)

def build_cartoon_head_and_face(mats):
    # Head Base: Young male cartoon head with cute cheeks and chin
    bm = bmesh.new()
    bmesh.ops.create_uvsphere(bm, u_segments=28, v_segments=18, radius=0.106)
    for v in bm.verts:
        x, y, z = v.co.x, v.co.y, v.co.z
        if z < 0:
            factor = (-z) / 0.106
            v.co.x *= (1.0 - 0.22 * factor)
            if y < 0:
                v.co.y -= 0.022 * factor
            else:
                v.co.y *= (1.0 - 0.12 * factor)
        if -0.04 < z < 0.04 and y < 0:
            v.co.x *= 1.06
            v.co.y -= 0.014
        v.co.z *= 1.12
        v.co.y *= 1.05
        v.co.z += 1.60
    head_m = bpy.data.meshes.new("Head")
    bm.to_mesh(head_m)
    bm.free()
    head = bpy.data.objects.new("Cartoon_Head", head_m)
    bpy.context.scene.collection.objects.link(head)
    head.data.materials.append(mats["skin"])
    apply_smooth(head)
    mod_sub = head.modifiers.new("Subsurf", 'SUBSURF')
    mod_sub.levels = 2
    
    # Neck
    neck = create_primitive('CYLINDER', location=(0, 0.005, 1.48), scale=(0.060, 0.060, 0.08), radius=1.0, depth=2.0)
    neck.name = "Neck"
    neck.data.materials.append(mats["skin"])
    apply_smooth(neck)
    
    # Rosy Cheeks Blush
    for side in (-1, 1):
        blush = create_primitive('SPHERE', location=(side * 0.056, -0.082, 1.570), scale=(0.022, 0.012, 0.016), radius=1.0)
        blush.name = f"Blush_{'L' if side > 0 else 'R'}"
        blush.data.materials.append(mats["cheeks"])
        apply_smooth(blush)
        
    # Cute Cartoon Button Nose
    nose = create_primitive('SPHERE', location=(0, -0.116, 1.585), scale=(0.018, 0.025, 0.018), radius=1.0)
    nose.name = "Cartoon_Nose"
    nose.data.materials.append(mats["skin"])
    apply_smooth(nose)
    
    # Warm Smiling Cartoon Lips
    bm_lips = bmesh.new()
    bmesh.ops.create_uvsphere(bm_lips, u_segments=22, v_segments=12, radius=0.022)
    for v in bm_lips.verts:
        v.co.x *= 1.85
        v.co.y *= 0.40
        v.co.z *= 0.35
        smile = (abs(v.co.x) / 0.038)**2 * 0.005
        v.co.z += smile
        v.co.y -= 0.108
        v.co.z += 1.528
    lips_m = bpy.data.meshes.new("Lips")
    bm_lips.to_mesh(lips_m)
    bm_lips.free()
    lips_obj = bpy.data.objects.new("Cartoon_Lips", lips_m)
    bpy.context.scene.collection.objects.link(lips_obj)
    lips_obj.data.materials.append(mats["lips"])
    apply_smooth(lips_obj)
    mod_l = lips_obj.modifiers.new("Subsurf", 'SUBSURF')
    mod_l.levels = 1
    
    # Big Expressive Cartoon Eyes
    for side in (-1, 1):
        # Sclera
        eye = create_primitive('SPHERE', location=(side * 0.040, -0.090, 1.618), scale=(0.024, 0.020, 0.024), radius=1.0)
        eye.name = f"EyeBall_{'L' if side > 0 else 'R'}"
        eye.data.materials.append(mats["eye_sclera"])
        apply_smooth(eye)
        
        # Iris (Rich warm hazel-amber)
        iris = create_primitive('SPHERE', location=(side * 0.040, -0.108, 1.618), scale=(0.016, 0.004, 0.016), radius=1.0)
        iris.name = f"Iris_{'L' if side > 0 else 'R'}"
        iris.data.materials.append(mats["eye_iris"])
        apply_smooth(iris)
        
        # Pupil
        pupil = create_primitive('SPHERE', location=(side * 0.040, -0.111, 1.618), scale=(0.008, 0.002, 0.008), radius=1.0)
        pupil.name = f"Pupil_{'L' if side > 0 else 'R'}"
        pupil.data.materials.append(mats["eye_pupil"])
        apply_smooth(pupil)
        
        # Primary Specular Highlight (Shiny catchlight)
        glint1 = create_primitive('SPHERE', location=(side * 0.036 - 0.002, -0.113, 1.625), scale=(0.0048, 0.002, 0.0048), radius=1.0)
        glint1.name = f"Glint1_{'L' if side > 0 else 'R'}"
        glint1.data.materials.append(mats["eye_glint"])
        apply_smooth(glint1)
        
        # Secondary Highlight
        glint2 = create_primitive('SPHERE', location=(side * 0.044 + 0.001, -0.113, 1.612), scale=(0.0025, 0.002, 0.0025), radius=1.0)
        glint2.name = f"Glint2_{'L' if side > 0 else 'R'}"
        glint2.data.materials.append(mats["eye_glint"])
        apply_smooth(glint2)
        
        # Upper Curved Eyelash / Eyelid Line
        bm_lid = bmesh.new()
        bmesh.ops.create_cube(bm_lid, size=1.0)
        for v in bm_lid.verts:
            v.co.x *= 0.028
            v.co.y *= 0.006
            v.co.z *= 0.005
            v.co = Euler((0, 0, math.radians(-6 * side))).to_matrix() @ v.co
            v.co.x += side * 0.040
            v.co.y -= 0.110
            v.co.z += 1.636
        lid_m = bpy.data.meshes.new(f"Lid_{side}")
        bm_lid.to_mesh(lid_m)
        bm_lid.free()
        lid_obj = bpy.data.objects.new(f"EyeLid_{'L' if side > 0 else 'R'}", lid_m)
        bpy.context.scene.collection.objects.link(lid_obj)
        lid_obj.data.materials.append(mats["eyeliner"])
        apply_smooth(lid_obj)
        
        # Confident Male Eyebrow
        bm_brow = bmesh.new()
        bmesh.ops.create_cube(bm_brow, size=1.0)
        for v in bm_brow.verts:
            v.co.x *= 0.032
            v.co.y *= 0.006
            v.co.z *= 0.007
            v.co = Euler((0, 0, math.radians(12 * side))).to_matrix() @ v.co
            v.co.x += side * 0.042
            v.co.y -= 0.118
            v.co.z += 1.650
        brow_m = bpy.data.meshes.new(f"Brow_{side}")
        bm_brow.to_mesh(brow_m)
        bm_brow.free()
        brow_obj = bpy.data.objects.new(f"Eyebrow_{'L' if side > 0 else 'R'}", brow_m)
        bpy.context.scene.collection.objects.link(brow_obj)
        brow_obj.data.materials.append(mats["eyebrow"])
        apply_smooth(brow_obj)
        
        # Cartoon Ears
        ear = create_primitive(
            'SPHERE',
            location=(side * 0.098, 0.005, 1.60),
            scale=(0.015, 0.032, 0.044),
            rotation=(0, math.radians(8 * side), math.radians(-12 * side)),
            radius=1.0
        )
        ear.name = f"Ear_{'L' if side > 0 else 'R'}"
        ear.data.materials.append(mats["skin"])
        apply_smooth(ear)

def build_cartoon_hair_and_cap(mats):
    # Hair bangs sweeping across forehead
    strands = [
        (-0.028, -0.110, 1.660, 0.026, 0.016, 0.045, 20, 12, 22),
        (0.014, -0.112, 1.656, 0.028, 0.016, 0.048, 22, -10, -18),
        (-0.058, -0.102, 1.650, 0.024, 0.015, 0.046, 16, 20, 32),
        (0.050, -0.104, 1.648, 0.026, 0.015, 0.045, 18, -18, -26),
        # Sideburns
        (-0.090, -0.035, 1.595, 0.020, 0.026, 0.055, -10, 10, 5),
        (0.090, -0.035, 1.595, 0.020, 0.026, 0.055, -10, -10, -5),
        (-0.084, -0.010, 1.565, 0.018, 0.024, 0.050, -15, 5, 8),
        (0.084, -0.010, 1.565, 0.018, 0.024, 0.050, -15, -5, -8),
        # Back locks
        (-0.040, 0.075, 1.545, 0.030, 0.022, 0.055, -25, 10, 10),
        (0.040, 0.075, 1.545, 0.030, 0.022, 0.055, -25, -10, -10),
    ]
    bm_hair = bmesh.new()
    for sx, sy, sz, scx, scy, scz, rx, ry, rz in strands:
        bm_piece = bmesh.new()
        bmesh.ops.create_cone(bm_piece, cap_ends=True, cap_tris=False, segments=12,
                              radius1=scx, radius2=scx * 0.25, depth=scz * 2)
        for v in bm_piece.verts:
            v.co.y *= (scy / scx)
        rot_m = Euler((math.radians(rx), math.radians(ry), math.radians(rz))).to_matrix()
        for v in bm_piece.verts:
            v.co = rot_m @ v.co
            v.co += Vector((sx, sy, sz))
        for v in bm_piece.verts:
            bm_hair.verts.new(v.co)
        bm_hair.verts.ensure_lookup_table()
        v_offset = len(bm_hair.verts) - len(bm_piece.verts)
        for f in bm_piece.faces:
            bm_hair.faces.new([bm_hair.verts[v_offset + v.index] for v in f.verts])
        bm_piece.free()
        
    hair_m = bpy.data.meshes.new("Hair")
    bm_hair.to_mesh(hair_m)
    bm_hair.free()
    hair = bpy.data.objects.new("Cartoon_Hair", hair_m)
    bpy.context.scene.collection.objects.link(hair)
    hair.data.materials.append(mats["hair"])
    apply_smooth(hair)
    mod_h = hair.modifiers.new("Subsurf", 'SUBSURF')
    mod_h.levels = 1
    
    # Baseball Cap Crown
    cap_crown = create_primitive(
        'SPHERE',
        location=(0, 0.015, 1.69),
        scale=(0.118, 0.124, 0.110),
        rotation=(math.radians(-8), 0, 0),
        radius=1.0
    )
    cap_crown.name = "Cap_Crown"
    cap_crown.data.materials.append(mats["cap_main"])
    apply_smooth(cap_crown)
    
    # Cap Top Button
    cap_btn = create_primitive('SPHERE', location=(0, 0.015, 1.805), scale=(0.014, 0.014, 0.007), radius=1.0)
    cap_btn.name = "Cap_Button"
    cap_btn.data.materials.append(mats["cap_button"])
    apply_smooth(cap_btn)
    
    # Curved Visor / Brim
    bm_visor = bmesh.new()
    bmesh.ops.create_grid(bm_visor, x_segments=16, y_segments=12, size=0.072)
    for v in bm_visor.verts:
        arch = (1.0 - (v.co.x / 0.072)**2) * 0.018
        v.co.z += arch
        dist_forward = (0.072 - v.co.y)
        v.co.z -= dist_forward * 0.18
        y_norm = dist_forward / 0.144
        v.co.x *= (1.0 - 0.22 * (y_norm**2))
        v.co.y -= 0.132
        v.co.z += 1.670
    visor_m = bpy.data.meshes.new("Visor")
    bm_visor.to_mesh(visor_m)
    bm_visor.free()
    visor_obj = bpy.data.objects.new("Cap_Visor", visor_m)
    bpy.context.scene.collection.objects.link(visor_obj)
    mod_v = visor_obj.modifiers.new("Solidify", 'SOLIDIFY')
    mod_v.thickness = 0.006
    visor_obj.data.materials.append(mats["cap_visor"])
    apply_smooth(visor_obj)
    
    # Patch & Emblem
    patch = create_primitive('CUBE', location=(0, -0.118, 1.725), scale=(0.028, 0.004, 0.018), rotation=(math.radians(10), 0, 0), size=1.0)
    patch.name = "Cap_Patch"
    patch.data.materials.append(mats["cap_patch"])
    apply_smooth(patch)
    
    emblem = create_primitive('CUBE', location=(0, -0.123, 1.725), scale=(0.016, 0.002, 0.010), rotation=(math.radians(10), 0, 0), size=1.0)
    emblem.name = "Cap_Emblem"
    emblem.data.materials.append(mats["cap_emblem"])
    apply_smooth(emblem)

def build_backdrop(mats):
    bm = bmesh.new()
    xs = [-3.5 + i * 0.7 for i in range(11)]
    profile = []
    for y in [-3.2, -2.0, -1.0, 0.5, 1.2]:
        profile.append((y, 0.0))
    for angle_deg in [15, 30, 45, 60, 75, 90]:
        rad = math.radians(angle_deg)
        y = 1.2 + 0.9 * math.sin(rad)
        z = 0.9 * (1.0 - math.cos(rad))
        profile.append((y, z))
    for z in [1.2, 1.8, 2.5, 3.4]:
        profile.append((2.1, z))
        
    grid_verts = []
    for y, z in profile:
        row = []
        for x in xs:
            v = bm.verts.new((x, y, z))
            row.append(v)
        grid_verts.append(row)
    bm.verts.ensure_lookup_table()
    
    for r in range(len(grid_verts) - 1):
        for c in range(len(xs) - 1):
            v1 = grid_verts[r][c]
            v2 = grid_verts[r][c+1]
            v3 = grid_verts[r+1][c+1]
            v4 = grid_verts[r+1][c]
            bm.faces.new([v1, v2, v3, v4])
            
    mesh = bpy.data.meshes.new("Backdrop")
    bm.to_mesh(mesh)
    bm.free()
    cyc = bpy.data.objects.new("Studio_Cyclorama", mesh)
    bpy.context.scene.collection.objects.link(cyc)
    cyc.data.materials.append(mats["backdrop"])
    apply_smooth(cyc)
    mod = cyc.modifiers.new("Subdivision", 'SUBSURF')
    mod.levels = 1
    return cyc

def setup_lighting():
    # 1. Warm Key Light (Front-Right 45 degrees, balanced to prevent washing out facial blush)
    key_data = bpy.data.lights.new(name="Key_Light", type='AREA')
    key_data.energy = 240.0
    key_data.size = 1.4
    key_data.color = (1.0, 0.95, 0.90)
    key_obj = bpy.data.objects.new(name="Key_Light", object_data=key_data)
    key_obj.location = (1.6, -2.2, 2.0)
    dir_k = Vector((0, 0, 1.1)) - key_obj.location
    key_obj.rotation_euler = dir_k.to_track_quat('-Z', 'Y').to_euler()
    bpy.context.scene.collection.objects.link(key_obj)
    
    # 2. Cool Fill Light (Front-Left)
    fill_data = bpy.data.lights.new(name="Fill_Light", type='AREA')
    fill_data.energy = 110.0
    fill_data.size = 2.2
    fill_data.color = (0.86, 0.92, 1.0)
    fill_obj = bpy.data.objects.new(name="Fill_Light", object_data=fill_data)
    fill_obj.location = (-1.8, -2.0, 1.4)
    dir_f = Vector((0, 0, 1.0)) - fill_obj.location
    fill_obj.rotation_euler = dir_f.to_track_quat('-Z', 'Y').to_euler()
    bpy.context.scene.collection.objects.link(fill_obj)
    
    # 3. Rim / Kicker Light (Back-Right, outlines silhouette)
    rim_data = bpy.data.lights.new(name="Rim_Light", type='AREA')
    rim_data.energy = 420.0
    rim_data.size = 1.2
    rim_data.color = (1.0, 0.98, 0.95)
    rim_obj = bpy.data.objects.new(name="Rim_Light", object_data=rim_data)
    rim_obj.location = (-1.2, 1.5, 2.2)
    dir_r = Vector((0, 0, 1.3)) - rim_obj.location
    rim_obj.rotation_euler = dir_r.to_track_quat('-Z', 'Y').to_euler()
    bpy.context.scene.collection.objects.link(rim_obj)
    
    # 4. Top Soft Overhead Light
    top_data = bpy.data.lights.new(name="Top_Light", type='AREA')
    top_data.energy = 70.0
    top_data.size = 2.8
    top_data.color = (0.95, 0.95, 0.98)
    top_obj = bpy.data.objects.new(name="Top_Light", object_data=top_data)
    top_obj.location = (0.0, -0.4, 3.2)
    top_obj.rotation_euler = Euler((0, 0, 0))
    bpy.context.scene.collection.objects.link(top_obj)

def setup_camera():
    cam_data = bpy.data.cameras.new("Main_Camera")
    cam_data.lens = 48.0
    cam_data.sensor_width = 36.0
    
    cam_obj = bpy.data.objects.new("Main_Camera", cam_data)
    cam_obj.location = (0.38, -3.15, 0.98)
    target = Vector((0.0, 0.0, 0.88))
    direction = target - cam_obj.location
    cam_obj.rotation_euler = direction.to_track_quat('-Z', 'Y').to_euler()
    
    bpy.context.scene.collection.objects.link(cam_obj)
    bpy.context.scene.camera = cam_obj
    return cam_obj

def setup_render(output_path, samples=48):
    scene = bpy.context.scene
    scene.render.engine = 'CYCLES'
    scene.cycles.device = 'CPU'
    scene.cycles.samples = samples
    scene.cycles.use_denoising = True
    
    scene.render.resolution_x = 1200
    scene.render.resolution_y = 1600
    scene.render.resolution_percentage = 100
    
    scene.view_settings.view_transform = 'AgX'
    scene.view_settings.look = 'AgX - High Contrast'
    
    scene.render.filepath = output_path
    scene.render.image_settings.file_format = 'PNG'
    scene.render.image_settings.color_mode = 'RGBA'

def main():
    print("[1/6] Initializing scene...")
    clear_scene()
    
    print("[2/6] Building PBR materials...")
    mats = build_materials()
    
    print("[3/6] Generating seamless 3D cartoon character...")
    build_cartoon_head_and_face(mats)
    build_cartoon_hair_and_cap(mats)
    build_continuous_hoodie(mats)
    build_continuous_pants(mats)
    build_cartoon_sneakers(mats)
    build_backdrop(mats)
    
    print("[4/6] Setting up studio lighting & camera...")
    setup_lighting()
    setup_camera()
    
    out_blend = "/home/rois/jarvis/blender-character/karakter_pria_topi.blend"
    out_png = "/home/rois/jarvis/blender-character/render_preview.png"
    
    print(f"[5/6] Saving .blend file to {out_blend}...")
    bpy.ops.wm.save_as_mainfile(filepath=out_blend)
    
    print(f"[6/6] Rendering preview with Cycles to {out_png}...")
    setup_render(out_png, samples=48)
    bpy.ops.render.render(write_still=True)
    
    total_tris = sum(len(o.data.polygons) * 2 for o in bpy.data.objects if o.type == 'MESH')
    total_objs = len(bpy.data.objects)
    print(f"DONE! Objects: {total_objs}, Approx Tris: {total_tris}")
    print(f"Blend file: {out_blend}")
    print(f"Render image: {out_png}")

if __name__ == "__main__":
    main()
