#!/usr/bin/env python3
"""
Blender 5.2 script: Generate a stylish early-20s male character wearing a hat.
Streetwear aesthetic: baseball cap, messy fringe, oversized hoodie, cargo pants, chunky sneakers.
Coordinates: -Y is Front, +Y is Back, +Z is Up.
"""
import bpy
import bmesh
from mathutils import Vector, Matrix, Euler, Quaternion
import math
import os
import sys

def clear_scene():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    if not bpy.data.collections:
        col = bpy.data.collections.new("Collection")
        bpy.context.scene.collection.children.link(col)

def make_torus_bm(bm, major_radius, minor_radius, major_segments=24, minor_segments=8):
    verts = []
    for i in range(major_segments):
        phi = 2.0 * math.pi * i / major_segments
        cos_phi = math.cos(phi)
        sin_phi = math.sin(phi)
        ring = []
        for j in range(minor_segments):
            theta = 2.0 * math.pi * j / minor_segments
            r = major_radius + minor_radius * math.cos(theta)
            z = minor_radius * math.sin(theta)
            x = r * cos_phi
            y = r * sin_phi
            ring.append(bm.verts.new((x, y, z)))
        verts.append(ring)
    bm.verts.ensure_lookup_table()
    for i in range(major_segments):
        next_i = (i + 1) % major_segments
        for j in range(minor_segments):
            next_j = (j + 1) % minor_segments
            v1 = verts[i][j]
            v2 = verts[next_i][j]
            v3 = verts[next_i][next_j]
            v4 = verts[i][next_j]
            bm.faces.new([v1, v2, v3, v4])

def create_pbr_material(name, base_color, roughness=0.5, metallic=0.0, sss_weight=0.0, sss_radius=(1.0, 0.35, 0.2), sheen_weight=0.0):
    mat = bpy.data.materials.new(name=name)
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()
    
    out = nodes.new("ShaderNodeOutputMaterial")
    out.location = (350, 0)
    
    bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.location = (0, 0)
    links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
    
    bsdf.inputs["Base Color"].default_value = (*base_color, 1.0)
    bsdf.inputs["Roughness"].default_value = roughness
    bsdf.inputs["Metallic"].default_value = metallic
    
    if "Subsurface Weight" in bsdf.inputs and sss_weight > 0:
        bsdf.inputs["Subsurface Weight"].default_value = sss_weight
        bsdf.inputs["Subsurface Radius"].default_value = sss_radius
        bsdf.inputs["Subsurface Scale"].default_value = 0.02
        
    if "Sheen Weight" in bsdf.inputs and sheen_weight > 0:
        bsdf.inputs["Sheen Weight"].default_value = sheen_weight
        
    return mat

def apply_smooth(obj):
    for p in obj.data.polygons:
        p.use_smooth = True
    obj.data.update()

def build_materials():
    mats = {}
    # Skin (warm, youthful early-20s tone with SSS)
    mats["skin"] = create_pbr_material("M_Skin", (0.86, 0.70, 0.60), roughness=0.48, sss_weight=0.4)
    mats["lips"] = create_pbr_material("M_Lips", (0.80, 0.54, 0.50), roughness=0.38, sss_weight=0.25)
    
    # Face & Eyes
    mats["eye_sclera"] = create_pbr_material("M_EyeSclera", (0.95, 0.95, 0.96), roughness=0.15)
    mats["eye_iris"] = create_pbr_material("M_EyeIris", (0.16, 0.10, 0.06), roughness=0.1) # Warm dark espresso
    mats["eye_pupil"] = create_pbr_material("M_EyePupil", (0.01, 0.01, 0.01), roughness=0.05)
    mats["eye_glint"] = create_pbr_material("M_EyeGlint", (1.0, 1.0, 1.0), roughness=0.05)
    mats["eyebrow"] = create_pbr_material("M_Eyebrow", (0.06, 0.05, 0.04), roughness=0.75)
    
    # Hair
    mats["hair"] = create_pbr_material("M_Hair", (0.05, 0.04, 0.035), roughness=0.55, sheen_weight=0.35)
    
    # Streetwear Cap (Navy / Slate Blue)
    mats["cap_crown"] = create_pbr_material("M_Cap_Crown", (0.05, 0.07, 0.11), roughness=0.75, sheen_weight=0.6)
    mats["cap_visor"] = create_pbr_material("M_Cap_Visor", (0.04, 0.06, 0.09), roughness=0.7, sheen_weight=0.5)
    mats["cap_button"] = create_pbr_material("M_Cap_Button", (0.08, 0.11, 0.16), roughness=0.65)
    mats["cap_patch"] = create_pbr_material("M_Cap_Patch", (0.82, 0.76, 0.68), roughness=0.6)
    mats["cap_strap"] = create_pbr_material("M_Cap_Strap", (0.12, 0.08, 0.06), roughness=0.5)
    mats["metal"] = create_pbr_material("M_Metal", (0.75, 0.75, 0.78), roughness=0.25, metallic=0.95)
    
    # Streetwear Hoodie (Matcha / Sage Green)
    mats["hoodie"] = create_pbr_material("M_Hoodie", (0.18, 0.30, 0.23), roughness=0.82, sheen_weight=0.65)
    mats["hoodie_rib"] = create_pbr_material("M_HoodieRib", (0.14, 0.24, 0.18), roughness=0.88, sheen_weight=0.55)
    mats["cord"] = create_pbr_material("M_Cord", (0.85, 0.83, 0.80), roughness=0.7)
    
    # Relaxed Cargo Pants (Dark Charcoal)
    mats["pants"] = create_pbr_material("M_Pants", (0.08, 0.09, 0.11), roughness=0.82, sheen_weight=0.35)
    mats["pants_detail"] = create_pbr_material("M_PantsDetail", (0.11, 0.12, 0.15), roughness=0.8)
    
    # Sneakers
    mats["sneaker_white"] = create_pbr_material("M_SneakerWhite", (0.92, 0.92, 0.93), roughness=0.42)
    mats["sneaker_black"] = create_pbr_material("M_SneakerBlack", (0.04, 0.04, 0.05), roughness=0.5)
    mats["sneaker_accent"] = create_pbr_material("M_SneakerAccent", (0.18, 0.30, 0.23), roughness=0.48) # Sage accent
    mats["sneaker_sole"] = create_pbr_material("M_SneakerSole", (0.95, 0.94, 0.93), roughness=0.55)
    mats["sneaker_gum"] = create_pbr_material("M_SneakerGum", (0.50, 0.35, 0.20), roughness=0.6)
    
    # Studio Backdrop (Slate Studio Grey)
    mats["backdrop"] = create_pbr_material("M_Backdrop", (0.28, 0.30, 0.34), roughness=0.92)
    
    return mats

def make_obj(name, bm, material=None):
    mesh = bpy.data.meshes.new(name)
    bm.to_mesh(mesh)
    bm.free()
    obj = bpy.data.objects.new(name, mesh)
    bpy.context.scene.collection.objects.link(obj)
    if material:
        obj.data.materials.append(material)
    apply_smooth(obj)
    return obj

def build_head(mats):
    # Head Base: Young adult male skull
    # Coordinates: Center at (0, 0, 1.60), front is -Y!
    bm = bmesh.new()
    bmesh.ops.create_uvsphere(bm, u_segments=24, v_segments=16, radius=0.10)
    for v in bm.verts:
        x, y, z = v.co.x, v.co.y, v.co.z
        # Jaw & Chin tapering: Chin is at -Y and -Z
        if z < 0:
            factor = (-z) / 0.10
            v.co.x *= (1.0 - 0.28 * factor)
            if y < 0:
                v.co.y -= 0.015 * factor # Chin slightly forward (-Y)
            else:
                v.co.y *= (1.0 - 0.15 * factor)
        if z > 0.02:
            v.co.x *= 0.96
            v.co.y *= 1.02
        v.co.z *= 1.15
        v.co.y *= 1.08
        v.co.z += 1.60
    head = make_obj("Head", bm, mats["skin"])
    
    # Neck
    bm_neck = bmesh.new()
    bmesh.ops.create_cone(bm_neck, cap_ends=True, cap_tris=False, segments=20,
                          radius1=0.062, radius2=0.055, depth=0.14)
    for v in bm_neck.verts:
        v.co.z += 1.48
        v.co.y += 0.005
    make_obj("Neck", bm_neck, mats["skin"])
    
    # Nose (Protruding towards -Y)
    bm_nose = bmesh.new()
    bmesh.ops.create_cone(bm_nose, cap_ends=True, cap_tris=False, segments=8,
                          radius1=0.014, radius2=0.006, depth=0.038)
    for v in bm_nose.verts:
        # Orient towards -Y (rotate 75 deg on X)
        v.co = Euler((math.radians(-75), 0, 0)).to_matrix() @ v.co
        v.co.y -= 0.112
        v.co.z += 1.585
    make_obj("Nose", bm_nose, mats["skin"])
    
    # Lips
    bm_lips = bmesh.new()
    bmesh.ops.create_uvsphere(bm_lips, u_segments=16, v_segments=8, radius=0.016)
    for v in bm_lips.verts:
        v.co.x *= 1.6
        v.co.y *= 0.5
        v.co.z *= 0.4
        v.co.y -= 0.102
        v.co.z += 1.530
    make_obj("Lips", bm_lips, mats["lips"])
    
    # Ears (Left +X, Right -X)
    for side in (-1, 1):
        bm_ear = bmesh.new()
        bmesh.ops.create_uvsphere(bm_ear, u_segments=12, v_segments=8, radius=0.025)
        for v in bm_ear.verts:
            v.co.x *= 0.35
            v.co.y *= 0.8
            v.co.z *= 1.4
            v.co = Euler((0, math.radians(10 * side), math.radians(-15 * side))).to_matrix() @ v.co
            v.co.x += side * 0.098
            v.co.y += 0.005
            v.co.z += 1.60
        make_obj(f"Ear_{'L' if side > 0 else 'R'}", bm_ear, mats["skin"])

    # Eyes & Eyebrows (Facing -Y)
    for side in (-1, 1):
        # Sclera
        bm_eye = bmesh.new()
        bmesh.ops.create_uvsphere(bm_eye, u_segments=16, v_segments=12, radius=0.016)
        for v in bm_eye.verts:
            v.co.x += side * 0.038
            v.co.y -= 0.090
            v.co.z += 1.615
        make_obj(f"EyeBall_{'L' if side > 0 else 'R'}", bm_eye, mats["eye_sclera"])
        
        # Iris
        bm_iris = bmesh.new()
        bmesh.ops.create_uvsphere(bm_iris, u_segments=12, v_segments=8, radius=0.009)
        for v in bm_iris.verts:
            v.co.y *= 0.3
            v.co.x += side * 0.038
            v.co.y -= 0.103
            v.co.z += 1.615
        make_obj(f"Iris_{'L' if side > 0 else 'R'}", bm_iris, mats["eye_iris"])
        
        # Pupil
        bm_pupil = bmesh.new()
        bmesh.ops.create_uvsphere(bm_pupil, u_segments=8, v_segments=6, radius=0.004)
        for v in bm_pupil.verts:
            v.co.y *= 0.2
            v.co.x += side * 0.038
            v.co.y -= 0.106
            v.co.z += 1.615
        make_obj(f"Pupil_{'L' if side > 0 else 'R'}", bm_pupil, mats["eye_pupil"])
        
        # Specular Glint
        bm_glint = bmesh.new()
        bmesh.ops.create_uvsphere(bm_glint, u_segments=6, v_segments=4, radius=0.0025)
        for v in bm_glint.verts:
            v.co.x += side * 0.035 - 0.002
            v.co.y -= 0.107
            v.co.z += 1.618
        make_obj(f"Glint_{'L' if side > 0 else 'R'}", bm_glint, mats["eye_glint"])
        
        # Eyebrows
        bm_brow = bmesh.new()
        bmesh.ops.create_cube(bm_brow, size=1.0)
        for v in bm_brow.verts:
            v.co.x *= 0.032
            v.co.y *= 0.005
            v.co.z *= 0.006
            v.co = Euler((0, 0, math.radians(12 * side))).to_matrix() @ v.co
            v.co.x += side * 0.040
            v.co.y -= 0.098
            v.co.z += 1.636
        make_obj(f"Eyebrow_{'L' if side > 0 else 'R'}", bm_brow, mats["eyebrow"])

def build_hair(mats):
    # Messy stylish fringe peeking out from under cap front (-Y) and sideburns
    strands = [
        # (center_x, center_y, center_z, scale_x, scale_y, scale_z, rot_x, rot_y, rot_z)
        # Front fringe / bangs sweeping across forehead
        (-0.025, -0.092, 1.650, 0.024, 0.015, 0.045, 20, 15, 25),
        (0.010, -0.095, 1.645, 0.026, 0.015, 0.050, 22, -10, -15),
        (-0.052, -0.086, 1.640, 0.022, 0.014, 0.046, 15, 25, 35),
        (0.045, -0.088, 1.638, 0.024, 0.014, 0.045, 18, -20, -28),
        # Sideburn locks
        (-0.088, -0.035, 1.595, 0.018, 0.025, 0.055, -10, 10, 5),
        (0.088, -0.035, 1.595, 0.018, 0.025, 0.055, -10, -10, -5),
        (-0.082, -0.010, 1.565, 0.015, 0.022, 0.050, -15, 5, 8),
        (0.082, -0.010, 1.565, 0.015, 0.022, 0.050, -15, -5, -8),
        # Back locks at neck nape (+Y)
        (-0.040, 0.075, 1.545, 0.028, 0.020, 0.055, -25, 10, 10),
        (0.040, 0.075, 1.545, 0.028, 0.020, 0.055, -25, -10, -10),
        (0.000, 0.082, 1.535, 0.032, 0.020, 0.060, -28, 0, 0),
    ]
    
    bm_combined = bmesh.new()
    for sx, sy, sz, scx, scy, scz, rx, ry, rz in strands:
        bm_piece = bmesh.new()
        bmesh.ops.create_cone(bm_piece, cap_ends=True, cap_tris=False, segments=10,
                              radius1=scx, radius2=scx * 0.15, depth=scz * 2)
        for v in bm_piece.verts:
            v.co.y *= (scy / scx)
        rot_m = Euler((math.radians(rx), math.radians(ry), math.radians(rz))).to_matrix()
        for v in bm_piece.verts:
            v.co = rot_m @ v.co
            v.co += Vector((sx, sy, sz))
        
        for v in bm_piece.verts:
            bm_combined.verts.new(v.co)
        bm_combined.verts.ensure_lookup_table()
        vert_offset = len(bm_combined.verts) - len(bm_piece.verts)
        for f in bm_piece.faces:
            bm_combined.faces.new([bm_combined.verts[vert_offset + v.index] for v in f.verts])
        bm_piece.free()
        
    make_obj("Hair", bm_combined, mats["hair"])

def build_hat(mats):
    # Cap Crown: Fitted snugly over the skull down to Z 1.635
    # Head top is at ~Z 1.715. Cap center placed at (0, -0.005, 1.660) with radius 0.114
    bm_crown = bmesh.new()
    bmesh.ops.create_uvsphere(bm_crown, u_segments=28, v_segments=18, radius=0.114)
    
    # Remove bottom section below rim
    verts_to_remove = [v for v in bm_crown.verts if v.co.z < -0.025]
    bmesh.ops.delete(bm_crown, geom=verts_to_remove, context='VERTS')
    
    # Shape crown: slight forward tilt & casual tilt
    tilt_m = Euler((math.radians(4), math.radians(-3), math.radians(2))).to_matrix()
    for v in bm_crown.verts:
        v.co.x *= 0.98
        v.co.y *= 1.05
        v.co.z *= 0.95
        v.co = tilt_m @ v.co
        v.co.x += 0.002
        v.co.y -= 0.006
        v.co.z += 1.670
        
    cap_crown = make_obj("Cap_Crown", bm_crown, mats["cap_crown"])
    mod_solid = cap_crown.modifiers.new("Solidify", 'SOLIDIFY')
    mod_solid.thickness = 0.006
    mod_solid.offset = 1.0
    
    # Cap Button on top
    bm_button = bmesh.new()
    bmesh.ops.create_uvsphere(bm_button, u_segments=12, v_segments=8, radius=0.010)
    for v in bm_button.verts:
        v.co.z *= 0.45
        v.co.x += 0.002
        v.co.y -= 0.006
        v.co.z += 1.775
    make_obj("Cap_Button", bm_button, mats["cap_button"])
    
    # Cap Visor / Brim: Extending forward towards -Y
    bm_visor = bmesh.new()
    bmesh.ops.create_grid(bm_visor, x_segments=16, y_segments=10, size=0.070)
    for v in bm_visor.verts:
        # X: -0.07 to +0.07, Y: -0.07 to +0.07
        # arch the brim downward along X edges
        arch = (1.0 - (v.co.x / 0.070)**2) * 0.016
        v.co.z += arch
        
        # Visor projects forward along -Y:
        # v.co.y: -0.07 is front tip, +0.07 is cap attachment rim
        # Downward tilt towards the front tip
        dist_forward = (0.070 - v.co.y) # 0 at cap base, 0.14 at tip
        v.co.z -= dist_forward * 0.26
        
        # Shape brim outline: slightly narrower and rounded at front
        y_norm = dist_forward / 0.14
        v.co.x *= (1.0 - 0.22 * (y_norm**2))
        
        # Position at front of cap
        v.co.y -= 0.135
        v.co.z += 1.650
        
    visor = make_obj("Cap_Visor", bm_visor, mats["cap_visor"])
    mod_v_sol = visor.modifiers.new("Solidify", 'SOLIDIFY')
    mod_v_sol.thickness = 0.0045
    
    # Front Embroidered Patch / Emblem
    bm_patch = bmesh.new()
    bmesh.ops.create_cube(bm_patch, size=1.0)
    for v in bm_patch.verts:
        v.co.x *= 0.026
        v.co.y *= 0.003
        v.co.z *= 0.016
        v.co.y += (v.co.x / 0.026)**2 * 0.003
        v.co = Euler((math.radians(18), 0, 0)).to_matrix() @ v.co
        v.co.y -= 0.106
        v.co.z += 1.705
    make_obj("Cap_Patch", bm_patch, mats["cap_patch"])
    
    # Back Strap & Metal Buckle at +Y
    bm_strap = bmesh.new()
    bmesh.ops.create_cube(bm_strap, size=1.0)
    for v in bm_strap.verts:
        v.co.x *= 0.035
        v.co.y *= 0.003
        v.co.z *= 0.008
        v.co.y += 0.098
        v.co.z += 1.655
    make_obj("Cap_Strap", bm_strap, mats["cap_strap"])
    
    bm_buckle = bmesh.new()
    bmesh.ops.create_cube(bm_buckle, size=1.0)
    for v in bm_buckle.verts:
        v.co.x *= 0.008
        v.co.y *= 0.004
        v.co.z *= 0.010
        v.co.y += 0.101
        v.co.z += 1.655
    make_obj("Cap_Buckle", bm_buckle, mats["metal"])

def build_hoodie(mats):
    # Oversized Streetwear Hoodie Body
    bm_torso = bmesh.new()
    bmesh.ops.create_uvsphere(bm_torso, u_segments=26, v_segments=18, radius=0.20)
    for v in bm_torso.verts:
        v.co.x *= 1.25 # Shoulders width ~ 0.50m
        v.co.y *= 0.85 # Chest depth
        v.co.z *= 1.35 # Torso height
        
        z_rel = (v.co.z) / 0.27
        if z_rel < 0:
            v.co.x *= (1.0 + 0.08 * z_rel)
            v.co.y *= (1.0 + 0.12 * z_rel)
        else:
            v.co.x *= (1.0 + 0.15 * z_rel)
            
        v.co.y -= 0.01
        v.co.z += 1.24
    make_obj("Hoodie_Torso", bm_torso, mats["hoodie"])
    
    # Bottom Ribbed Waistband
    bm_rib = bmesh.new()
    bmesh.ops.create_cone(bm_rib, cap_ends=False, segments=24, radius1=0.21, radius2=0.22, depth=0.08)
    for v in bm_rib.verts:
        v.co.y *= 0.82
        v.co.y -= 0.01
        v.co.z += 0.99
    make_obj("Hoodie_HemRib", bm_rib, mats["hoodie_rib"])
    
    # Front Kangaroo Pouch Pocket at -Y
    bm_pock = bmesh.new()
    bmesh.ops.create_cube(bm_pock, size=1.0)
    for v in bm_pock.verts:
        v.co.x *= 0.16
        v.co.y *= 0.035
        v.co.z *= 0.10
        if v.co.z > 0:
            v.co.x *= 0.75 # tapered top
        # curve along belly
        v.co.y += (v.co.x / 0.16)**2 * 0.015
        v.co.y -= 0.165
        v.co.z += 1.12
    make_obj("Hoodie_Pocket", bm_pock, mats["hoodie"])
    
    # Draped Hood resting around neck & upper back (+Y)
    bm_hood = bmesh.new()
    bmesh.ops.create_uvsphere(bm_hood, u_segments=22, v_segments=14, radius=0.15)
    # slice front off (-Y is front)
    verts_del = [v for v in bm_hood.verts if v.co.y < -0.02 and v.co.z > 0]
    bmesh.ops.delete(bm_hood, geom=verts_del, context='VERTS')
    for v in bm_hood.verts:
        v.co.x *= 1.15
        v.co.y *= 0.95
        v.co.z *= 0.85
        v.co.y += 0.06 # drape back (+Y)
        v.co.z += 1.42
    hood = make_obj("Hood_Drape", bm_hood, mats["hoodie"])
    mod_h_sol = hood.modifiers.new("Solidify", 'SOLIDIFY')
    mod_h_sol.thickness = 0.008
    
    # Thick Collar Rim
    bm_col = bmesh.new()
    make_torus_bm(bm_col, major_radius=0.10, minor_radius=0.022, major_segments=24, minor_segments=8)
    for v in bm_col.verts:
        v.co.x *= 1.05
        v.co.y *= 0.95
        v.co.y -= 0.01
        v.co.z += 1.43
    make_obj("Hoodie_Collar", bm_col, mats["hoodie_rib"])
    
    # Drawstring cords hanging down in front (-Y)
    for side in (-1, 1):
        bm_cord = bmesh.new()
        bmesh.ops.create_cone(bm_cord, cap_ends=True, segments=8, radius1=0.004, radius2=0.004, depth=0.18)
        for v in bm_cord.verts:
            wave = math.sin((v.co.z + 0.09) * 20) * 0.004
            v.co.x += wave
            v.co.x += side * 0.038
            v.co.y -= 0.170
            v.co.z += 1.30
        make_obj(f"Cord_{'L' if side > 0 else 'R'}", bm_cord, mats["cord"])
        
        # Metal Aglet tip
        bm_aglet = bmesh.new()
        bmesh.ops.create_cone(bm_aglet, cap_ends=True, segments=8, radius1=0.005, radius2=0.004, depth=0.022)
        for v in bm_aglet.verts:
            v.co.x += side * 0.038
            v.co.y -= 0.170
            v.co.z += 1.20
        make_obj(f"Aglet_{'L' if side > 0 else 'R'}", bm_aglet, mats["metal"])
        
        # Grommet ring
        bm_grom = bmesh.new()
        make_torus_bm(bm_grom, major_radius=0.008, minor_radius=0.0025, major_segments=12, minor_segments=6)
        for v in bm_grom.verts:
            v.co = Euler((math.radians(90), 0, 0)).to_matrix() @ v.co
            v.co.x += side * 0.038
            v.co.y -= 0.165
            v.co.z += 1.39
        make_obj(f"Grommet_{'L' if side > 0 else 'R'}", bm_grom, mats["metal"])

def build_arms_and_hands(mats):
    # Casual streetwear posture: Hands tucked into kangaroo pouch
    for side in (-1, 1):
        # Upper Arm
        bm_upper = bmesh.new()
        bmesh.ops.create_cone(bm_upper, cap_ends=True, segments=16, radius1=0.080, radius2=0.065, depth=0.28)
        for v in bm_upper.verts:
            # Angle down and slightly forward (-Y)
            v.co = Euler((math.radians(-10), math.radians(-24 * side), 0)).to_matrix() @ v.co
            v.co.x += side * 0.27
            v.co.y -= 0.015
            v.co.z += 1.28
        make_obj(f"Arm_Upper_{'L' if side > 0 else 'R'}", bm_upper, mats["hoodie"])
        
        # Forearm angled inwards towards front kangaroo pocket
        bm_fore = bmesh.new()
        bmesh.ops.create_cone(bm_fore, cap_ends=True, segments=16, radius1=0.065, radius2=0.052, depth=0.26)
        for v in bm_fore.verts:
            v.co = Euler((math.radians(32), math.radians(35 * side), math.radians(15 * side))).to_matrix() @ v.co
            v.co.x += side * 0.25
            v.co.y -= 0.095
            v.co.z += 1.13
        make_obj(f"Arm_Fore_{'L' if side > 0 else 'R'}", bm_fore, mats["hoodie"])
        
        # Ribbed Wrist Cuff
        bm_cuff = bmesh.new()
        make_torus_bm(bm_cuff, major_radius=0.048, minor_radius=0.014, major_segments=16, minor_segments=8)
        for v in bm_cuff.verts:
            v.co = Euler((math.radians(35), math.radians(40 * side), 0)).to_matrix() @ v.co
            v.co.x += side * 0.17
            v.co.y -= 0.155
            v.co.z += 1.06
        make_obj(f"Cuff_{'L' if side > 0 else 'R'}", bm_cuff, mats["hoodie_rib"])
        
        # Hand resting in pocket entrance
        bm_hand = bmesh.new()
        bmesh.ops.create_uvsphere(bm_hand, u_segments=12, v_segments=8, radius=0.038)
        for v in bm_hand.verts:
            v.co.x *= 0.75
            v.co.y *= 1.2
            v.co.z *= 0.55
            v.co = Euler((math.radians(25), math.radians(30 * side), 0)).to_matrix() @ v.co
            v.co.x += side * 0.13
            v.co.y -= 0.175
            v.co.z += 1.04
        make_obj(f"Hand_{'L' if side > 0 else 'R'}", bm_hand, mats["skin"])

def build_pants(mats):
    # Pelvis
    bm_pelvis = bmesh.new()
    bmesh.ops.create_uvsphere(bm_pelvis, u_segments=22, v_segments=14, radius=0.20)
    for v in bm_pelvis.verts:
        v.co.x *= 1.05
        v.co.y *= 0.85
        v.co.z *= 0.80
        v.co.y -= 0.01
        v.co.z += 0.93
    make_obj("Pants_Pelvis", bm_pelvis, mats["pants"])
    
    # Left and Right Legs
    for side in (-1, 1):
        # Thigh
        bm_thigh = bmesh.new()
        bmesh.ops.create_cone(bm_thigh, cap_ends=True, segments=20, radius1=0.108, radius2=0.092, depth=0.45)
        for v in bm_thigh.verts:
            v.co = Euler((math.radians(-2), math.radians(-3 * side), 0)).to_matrix() @ v.co
            v.co.x += side * 0.115
            v.co.y -= 0.005
            v.co.z += 0.70
        make_obj(f"Pants_Thigh_{'L' if side > 0 else 'R'}", bm_thigh, mats["pants"])
        
        # Lower leg / Calf with cloth stacks over sneakers
        bm_calf = bmesh.new()
        bmesh.ops.create_cone(bm_calf, cap_ends=True, segments=20, radius1=0.092, radius2=0.082, depth=0.42)
        for v in bm_calf.verts:
            z_norm = (v.co.z + 0.21) / 0.42
            if z_norm < 0.25:
                wrinkle = math.sin(z_norm * 40) * 0.008
                v.co.x += wrinkle
                v.co.y += wrinkle
            v.co.x += side * 0.128
            v.co.y += 0.002
            v.co.z += 0.30
        make_obj(f"Pants_Calf_{'L' if side > 0 else 'R'}", bm_calf, mats["pants"])
        
        # Cargo Pocket on outer thigh
        bm_cargo = bmesh.new()
        bmesh.ops.create_cube(bm_cargo, size=1.0)
        for v in bm_cargo.verts:
            v.co.x *= 0.022
            v.co.y *= 0.065
            v.co.z *= 0.080
            v.co.x += side * 0.215
            v.co.y -= 0.010
            v.co.z += 0.66
        make_obj(f"Cargo_Pocket_{'L' if side > 0 else 'R'}", bm_cargo, mats["pants_detail"])
        
        # Cargo Pocket Flap
        bm_flap = bmesh.new()
        bmesh.ops.create_cube(bm_flap, size=1.0)
        for v in bm_flap.verts:
            v.co.x *= 0.025
            v.co.y *= 0.068
            v.co.z *= 0.020
            v.co.x += side * 0.218
            v.co.y -= 0.010
            v.co.z += 0.73
        make_obj(f"Cargo_Flap_{'L' if side > 0 else 'R'}", bm_flap, mats["pants_detail"])

def build_sneakers(mats):
    # Chunky Streetwear Skate Sneakers (Facing -Y)
    for side in (-1, 1):
        # Midsole / Outsole
        bm_sole = bmesh.new()
        bmesh.ops.create_cube(bm_sole, size=1.0)
        for v in bm_sole.verts:
            v.co.x *= 0.062
            v.co.y *= 0.145
            v.co.z *= 0.025
            
            y_pos = -v.co.y / 0.145 # +1 at toe (-Y), -1 at heel (+Y)
            if -0.2 < y_pos < 0.3:
                v.co.x *= 0.88 # arch indent
            if y_pos > 0.4:
                v.co.z += ((y_pos - 0.4) / 0.6)**2 * 0.018 # Toe spring
                
            v.co = Euler((0, 0, math.radians(7 * side))).to_matrix() @ v.co
            v.co.x += side * 0.138
            v.co.y -= 0.035
            v.co.z += 0.025
        make_obj(f"Sneaker_Sole_{'L' if side > 0 else 'R'}", bm_sole, mats["sneaker_sole"])
        
        # Bottom Tread / Gum Sole
        bm_tread = bmesh.new()
        bmesh.ops.create_cube(bm_tread, size=1.0)
        for v in bm_tread.verts:
            v.co.x *= 0.060
            v.co.y *= 0.142
            v.co.z *= 0.005
            v.co = Euler((0, 0, math.radians(7 * side))).to_matrix() @ v.co
            v.co.x += side * 0.138
            v.co.y -= 0.035
            v.co.z += 0.005
        make_obj(f"Sneaker_Tread_{'L' if side > 0 else 'R'}", bm_tread, mats["sneaker_gum"])
        
        # Sneaker Upper (White Leather)
        bm_upper = bmesh.new()
        bmesh.ops.create_uvsphere(bm_upper, u_segments=16, v_segments=10, radius=0.075)
        for v in bm_upper.verts:
            v.co.x *= 0.72
            v.co.y *= 1.70
            v.co.z *= 0.65
            if v.co.z < -0.01:
                v.co.z = -0.01
            v.co = Euler((0, 0, math.radians(7 * side))).to_matrix() @ v.co
            v.co.x += side * 0.138
            v.co.y -= 0.035
            v.co.z += 0.065
        make_obj(f"Sneaker_Upper_{'L' if side > 0 else 'R'}", bm_upper, mats["sneaker_white"])
        
        # Side Accent Stripe (Sage Green)
        bm_stripe = bmesh.new()
        bmesh.ops.create_cube(bm_stripe, size=1.0)
        for v in bm_stripe.verts:
            v.co.x *= 0.005
            v.co.y *= 0.075
            v.co.z *= 0.018
            v.co = Euler((math.radians(-12), 0, math.radians(7 * side))).to_matrix() @ v.co
            v.co.x += side * (0.138 + 0.048 * side)
            v.co.y -= 0.030
            v.co.z += 0.065
        make_obj(f"Sneaker_Stripe_{'L' if side > 0 else 'R'}", bm_stripe, mats["sneaker_accent"])
        
        # Padded Collar Rim (Black)
        bm_rim = bmesh.new()
        make_torus_bm(bm_rim, major_radius=0.048, minor_radius=0.015, major_segments=16, minor_segments=8)
        for v in bm_rim.verts:
            v.co = Euler((math.radians(-15), 0, math.radians(7 * side))).to_matrix() @ v.co
            v.co.x += side * 0.138
            v.co.y -= 0.005
            v.co.z += 0.115
        make_obj(f"Sneaker_Collar_{'L' if side > 0 else 'R'}", bm_rim, mats["sneaker_black"])
        
        # Tongue
        bm_tongue = bmesh.new()
        bmesh.ops.create_cube(bm_tongue, size=1.0)
        for v in bm_tongue.verts:
            v.co.x *= 0.028
            v.co.y *= 0.065
            v.co.z *= 0.008
            v.co = Euler((math.radians(38), 0, math.radians(7 * side))).to_matrix() @ v.co
            v.co.x += side * 0.138
            v.co.y -= 0.065
            v.co.z += 0.095
        make_obj(f"Sneaker_Tongue_{'L' if side > 0 else 'R'}", bm_tongue, mats["sneaker_black"])
        
        # Criss-cross laces
        for i in range(3):
            bm_lace = bmesh.new()
            bmesh.ops.create_cube(bm_lace, size=1.0)
            for v in bm_lace.verts:
                v.co.x *= 0.024
                v.co.y *= 0.006
                v.co.z *= 0.004
                v.co = Euler((math.radians(38), 0, math.radians(7 * side))).to_matrix() @ v.co
                v.co.x += side * 0.138
                v.co.y -= 0.045 + i * 0.022
                v.co.z += 0.080 + i * 0.015
            make_obj(f"Sneaker_Lace_{i}_{'L' if side > 0 else 'R'}", bm_lace, mats["sneaker_white"])

def build_backdrop(mats):
    # Studio Cyclorama: Floor extends towards -Y (camera side), curves up into back wall at +Y
    bm = bmesh.new()
    xs = [-3.0 + i * 0.6 for i in range(11)]
    profile = []
    # Floor in front
    for y in [-2.5, -1.5, -0.5, 0.5, 1.0]:
        profile.append((y, 0.0))
    # Smooth curve
    for angle_deg in [15, 30, 45, 60, 75, 90]:
        rad = math.radians(angle_deg)
        y = 1.0 + 0.8 * math.sin(rad)
        z = 0.8 * (1.0 - math.cos(rad))
        profile.append((y, z))
    # Back wall
    for z in [1.2, 1.8, 2.5, 3.4]:
        profile.append((1.8, z))
        
    grid_verts = []
    for y, z in profile:
        row = []
        for x in xs:
            v = bm.verts.new((x, y, z))
            row.append(v)
        grid_verts.append(row)
    bm.verts.ensure_lookup_table()
    
    for r in range(len(grid_verts) - 1):
        for c in range(len(xs) - 1):
            v1 = grid_verts[r][c]
            v2 = grid_verts[r][c+1]
            v3 = grid_verts[r+1][c+1]
            v4 = grid_verts[r+1][c]
            bm.faces.new([v1, v2, v3, v4])
            
    cyc = make_obj("Studio_Cyclorama", bm, mats["backdrop"])
    return cyc

def setup_lighting():
    # 1. Warm Key Light (Front-Right 45 degrees, flattering angle)
    key_data = bpy.data.lights.new(name="Key_Light", type='AREA')
    key_data.energy = 380.0
    key_data.size = 1.2
    key_data.color = (1.0, 0.94, 0.88)
    key_obj = bpy.data.objects.new(name="Key_Light", object_data=key_data)
    key_obj.location = (1.6, -2.0, 2.1)
    dir_k = Vector((0, 0, 1.2)) - key_obj.location
    key_obj.rotation_euler = dir_k.to_track_quat('-Z', 'Y').to_euler()
    bpy.context.scene.collection.objects.link(key_obj)
    
    # 2. Cool Fill Light (Front-Left, softens contrast)
    fill_data = bpy.data.lights.new(name="Fill_Light", type='AREA')
    fill_data.energy = 160.0
    fill_data.size = 2.0
    fill_data.color = (0.86, 0.92, 1.0)
    fill_obj = bpy.data.objects.new(name="Fill_Light", object_data=fill_data)
    fill_obj.location = (-1.8, -1.8, 1.5)
    dir_f = Vector((0, 0, 1.1)) - fill_obj.location
    fill_obj.rotation_euler = dir_f.to_track_quat('-Z', 'Y').to_euler()
    bpy.context.scene.collection.objects.link(fill_obj)
    
    # 3. Rim / Kicker Light (Back-Right, outlines cap silhouette & shoulders)
    rim_data = bpy.data.lights.new(name="Rim_Light", type='AREA')
    rim_data.energy = 520.0
    rim_data.size = 1.0
    rim_data.color = (1.0, 0.98, 0.95)
    rim_obj = bpy.data.objects.new(name="Rim_Light", object_data=rim_data)
    rim_obj.location = (-1.1, 1.4, 2.3)
    dir_r = Vector((0, 0, 1.4)) - rim_obj.location
    rim_obj.rotation_euler = dir_r.to_track_quat('-Z', 'Y').to_euler()
    bpy.context.scene.collection.objects.link(rim_obj)
    
    # 4. Top Soft Overhead Light
    top_data = bpy.data.lights.new(name="Top_Light", type='AREA')
    top_data.energy = 100.0
    top_data.size = 2.5
    top_data.color = (0.95, 0.95, 0.98)
    top_obj = bpy.data.objects.new(name="Top_Light", object_data=top_data)
    top_obj.location = (0.0, -0.4, 3.2)
    top_obj.rotation_euler = Euler((0, 0, 0))
    bpy.context.scene.collection.objects.link(top_obj)

def setup_camera():
    cam_data = bpy.data.cameras.new("Main_Camera")
    # 52mm portrait lens: full body shot fitting from top of cap (Z 1.80) to sneakers (Z 0.0)
    cam_data.lens = 52.0
    cam_data.sensor_width = 36.0
    
    cam_obj = bpy.data.objects.new("Main_Camera", cam_data)
    # Position: Front 3/4 view (slightly off-center X=0.38, Y=-2.75 in front, Z=1.05 height)
    cam_obj.location = (0.38, -2.75, 1.05)
    target = Vector((0.0, 0.0, 0.95))
    direction = target - cam_obj.location
    cam_obj.rotation_euler = direction.to_track_quat('-Z', 'Y').to_euler()
    
    bpy.context.scene.collection.objects.link(cam_obj)
    bpy.context.scene.camera = cam_obj
    return cam_obj

def setup_render(output_path, samples=48):
    scene = bpy.context.scene
    scene.render.engine = 'CYCLES'
    scene.cycles.device = 'CPU'
    scene.cycles.samples = samples
    scene.cycles.use_denoising = True
    
    # 1200x1600 (3:4 portrait)
    scene.render.resolution_x = 1200
    scene.render.resolution_y = 1600
    scene.render.resolution_percentage = 100
    
    scene.view_settings.view_transform = 'AgX'
    scene.view_settings.look = 'AgX - High Contrast'
    
    scene.render.filepath = output_path
    scene.render.image_settings.file_format = 'PNG'
    scene.render.image_settings.color_mode = 'RGBA'

def main():
    print("[1/6] Initializing scene...")
    clear_scene()
    
    print("[2/6] Building PBR materials...")
    mats = build_materials()
    
    print("[3/6] Generating character geometry...")
    build_head(mats)
    build_hair(mats)
    build_hat(mats)
    build_hoodie(mats)
    build_arms_and_hands(mats)
    build_pants(mats)
    build_sneakers(mats)
    build_backdrop(mats)
    
    print("[4/6] Setting up studio lighting & camera...")
    setup_lighting()
    setup_camera()
    
    out_blend = "/home/rois/jarvis/blender-character/karakter_pria_topi.blend"
    out_png = "/home/rois/jarvis/blender-character/render_preview.png"
    
    print(f"[5/6] Saving .blend file to {out_blend}...")
    bpy.ops.wm.save_as_mainfile(filepath=out_blend)
    
    print(f"[6/6] Rendering preview with Cycles to {out_png}...")
    setup_render(out_png, samples=48)
    bpy.ops.render.render(write_still=True)
    
    total_tris = sum(len(o.data.polygons) * 2 for o in bpy.data.objects if o.type == 'MESH')
    total_objs = len(bpy.data.objects)
    print(f"DONE! Objects: {total_objs}, Approx Tris: {total_tris}")
    print(f"Blend file: {out_blend}")
    print(f"Render image: {out_png}")

if __name__ == "__main__":
    main()
