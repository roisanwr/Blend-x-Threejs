#!/usr/bin/env python3
"""
Generate a stylish early-20s male character wearing a hat in Blender 5.2.
Creates complete geometry, materials, lighting, camera, and renders preview.
"""
import bpy
import bmesh
from mathutils import Vector, Matrix, Euler
import math
import os
import sys

def clear_scene():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    # Ensure a collection exists
    if not bpy.data.collections:
        col = bpy.data.collections.new("Scene_Collection")
        bpy.context.scene.collection.children.link(col)

def make_torus_bm(bm, major_radius, minor_radius, major_segments=20, minor_segments=8):
    verts = []
    for i in range(major_segments):
        phi = 2.0 * math.pi * i / major_segments
        cos_phi = math.cos(phi)
        sin_phi = math.sin(phi)
        ring = []
        for j in range(minor_segments):
            theta = 2.0 * math.pi * j / minor_segments
            r = major_radius + minor_radius * math.cos(theta)
            z = minor_radius * math.sin(theta)
            x = r * cos_phi
            y = r * sin_phi
            ring.append(bm.verts.new((x, y, z)))
        verts.append(ring)
    bm.verts.ensure_lookup_table()
    for i in range(major_segments):
        next_i = (i + 1) % major_segments
        for j in range(minor_segments):
            next_j = (j + 1) % minor_segments
            v1 = verts[i][j]
            v2 = verts[next_i][j]
            v3 = verts[next_i][next_j]
            v4 = verts[i][next_j]
            bm.faces.new([v1, v2, v3, v4])

def create_material(name, base_color, roughness=0.5, metallic=0.0, sss_weight=0.0, sss_radius=(1.0, 0.35, 0.2), sheen_weight=0.0, coat_weight=0.0):
    mat = bpy.data.materials.new(name=name)
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()
    
    out = nodes.new("ShaderNodeOutputMaterial")
    out.location = (400, 0)
    
    bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.location = (0, 0)
    links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
    
    bsdf.inputs["Base Color"].default_value = (*base_color, 1.0)
    bsdf.inputs["Roughness"].default_value = roughness
    bsdf.inputs["Metallic"].default_value = metallic
    
    # Blender 4.0+ / 5.x naming
    if "Subsurface Weight" in bsdf.inputs and sss_weight > 0:
        bsdf.inputs["Subsurface Weight"].default_value = sss_weight
        bsdf.inputs["Subsurface Radius"].default_value = sss_radius
        bsdf.inputs["Subsurface Scale"].default_value = 0.02
    
    if "Sheen Weight" in bsdf.inputs and sheen_weight > 0:
        bsdf.inputs["Sheen Weight"].default_value = sheen_weight
        
    if "Coat Weight" in bsdf.inputs and coat_weight > 0:
        bsdf.inputs["Coat Weight"].default_value = coat_weight
        
    return mat

def apply_smooth(obj, angle=math.radians(40)):
    # In Blender 5.x, smooth mesh and add Smooth by Angle modifier if appropriate
    for p in obj.data.polygons:
        p.use_smooth = True
    obj.data.update()

def build_materials():
    mats = {}
    # Skin: Warm youthful male skin tone with SSS
    mats["skin"] = create_material("M_Skin", (0.88, 0.72, 0.62), roughness=0.48, sss_weight=0.45)
    mats["skin_lips"] = create_material("M_Lips", (0.84, 0.58, 0.54), roughness=0.4, sss_weight=0.3)
    
    # Eyes
    mats["eye_white"] = create_material("M_EyeWhite", (0.95, 0.95, 0.96), roughness=0.15)
    mats["eye_iris"] = create_material("M_Iris", (0.18, 0.12, 0.08), roughness=0.1) # Deep warm espresso
    mats["eye_pupil"] = create_material("M_Pupil", (0.01, 0.01, 0.01), roughness=0.05)
    mats["eye_highlight"] = create_material("M_Highlight", (1.0, 1.0, 1.0), roughness=0.05)
    mats["eyebrow"] = create_material("M_Eyebrow", (0.08, 0.06, 0.05), roughness=0.8)
    
    # Hair
    mats["hair"] = create_material("M_Hair", (0.07, 0.05, 0.04), roughness=0.55, sheen_weight=0.3)
    
    # Streetwear Cap
    mats["cap_main"] = create_material("M_Cap_Main", (0.08, 0.10, 0.14), roughness=0.8, sheen_weight=0.6) # Washed dark navy
    mats["cap_visor"] = create_material("M_Cap_Visor", (0.06, 0.08, 0.11), roughness=0.75, sheen_weight=0.5)
    mats["cap_button"] = create_material("M_Cap_Button", (0.12, 0.15, 0.20), roughness=0.7)
    mats["cap_patch"] = create_material("M_Cap_Patch", (0.85, 0.78, 0.65), roughness=0.6) # Cream embroidered patch
    mats["cap_strap"] = create_material("M_Cap_Strap", (0.15, 0.10, 0.08), roughness=0.5) # Leather brown strap
    mats["metal"] = create_material("M_Metal", (0.75, 0.75, 0.78), roughness=0.25, metallic=0.95)
    
    # Hoodie
    # Trendy Sage / Matcha green streetwear hoodie
    mats["hoodie"] = create_material("M_Hoodie", (0.22, 0.35, 0.28), roughness=0.85, sheen_weight=0.7)
    mats["hoodie_rib"] = create_material("M_HoodieRib", (0.18, 0.29, 0.23), roughness=0.9, sheen_weight=0.6)
    mats["cord"] = create_material("M_Cord", (0.88, 0.86, 0.82), roughness=0.7) # Off-white cord
    
    # Pants
    mats["pants"] = create_material("M_Pants", (0.11, 0.13, 0.16), roughness=0.85, sheen_weight=0.4) # Dark charcoal denim
    mats["pants_detail"] = create_material("M_PantsDetail", (0.15, 0.17, 0.20), roughness=0.8)
    
    # Sneakers
    mats["sneaker_white"] = create_material("M_SneakerWhite", (0.92, 0.92, 0.93), roughness=0.45)
    mats["sneaker_black"] = create_material("M_SneakerBlack", (0.06, 0.06, 0.07), roughness=0.5)
    mats["sneaker_accent"] = create_material("M_SneakerAccent", (0.22, 0.35, 0.28), roughness=0.5) # Matches hoodie
    mats["sneaker_sole"] = create_material("M_SneakerSole", (0.96, 0.95, 0.94), roughness=0.6)
    mats["sneaker_gum"] = create_material("M_SneakerGum", (0.55, 0.38, 0.22), roughness=0.65)
    
    # Studio Backdrop
    mats["backdrop"] = create_material("M_Backdrop", (0.78, 0.80, 0.82), roughness=0.95)
    
    return mats

def make_mesh_obj(name, bm, material=None):
    mesh = bpy.data.meshes.new(name)
    bm.to_mesh(mesh)
    bm.free()
    obj = bpy.data.objects.new(name, mesh)
    bpy.context.scene.collection.objects.link(obj)
    if material:
        obj.data.materials.append(material)
    apply_smooth(obj)
    return obj

def build_head(mats):
    bm = bmesh.new()
    # Create head via subdivided cube for quad topology
    bmesh.ops.create_uvsphere(bm, u_segments=24, v_segments=16, radius=0.10)
    
    # Reshape head: scale into early-20s male skull
    # Center around (0, 0.01, 1.62)
    for v in bm.verts:
        x, y, z = v.co.x, v.co.y, v.co.z
        
        # Jaw & Chin tapering
        if z < 0:
            # Chin tapering forward and down
            factor = (-z) / 0.10
            v.co.x *= (1.0 - 0.28 * factor)
            if y > 0:
                v.co.y += 0.015 * factor # chin slight forward
            else:
                v.co.y *= (1.0 - 0.15 * factor)
        
        # Temples & Forehead
        if z > 0.03:
            v.co.x *= 0.96
            v.co.y *= 1.02
            
        # Overall head proportions
        v.co.z *= 1.15
        v.co.y *= 1.08
        v.co.z += 1.62
        v.co.y += 0.01
        
    head = make_mesh_obj("Head", bm, mats["skin"])
    
    # Neck
    bm_neck = bmesh.new()
    bmesh.ops.create_cone(bm_neck, cap_ends=True, cap_tris=False, segments=20, 
                          radius1=0.062, radius2=0.055, depth=0.14)
    for v in bm_neck.verts:
        v.co.z += 1.50
        v.co.y -= 0.005
    neck = make_mesh_obj("Neck", bm_neck, mats["skin"])
    
    # Nose
    bm_nose = bmesh.new()
    bmesh.ops.create_cone(bm_nose, cap_ends=True, cap_tris=False, segments=8,
                          radius1=0.014, radius2=0.006, depth=0.038)
    for v in bm_nose.verts:
        # Orient forward
        v.co = Euler((math.radians(75), 0, 0)).to_matrix() @ v.co
        v.co.y += 0.112
        v.co.z += 1.60
    nose = make_mesh_obj("Nose", bm_nose, mats["skin"])
    
    # Lips
    bm_lips = bmesh.new()
    bmesh.ops.create_uvsphere(bm_lips, u_segments=16, v_segments=8, radius=0.015)
    for v in bm_lips.verts:
        v.co.x *= 1.6
        v.co.y *= 0.5
        v.co.z *= 0.4
        v.co.y += 0.102
        v.co.z += 1.545
    lips = make_mesh_obj("Lips", bm_lips, mats["skin_lips"])
    
    # Ears
    for side in (-1, 1):
        bm_ear = bmesh.new()
        bmesh.ops.create_uvsphere(bm_ear, u_segments=12, v_segments=8, radius=0.025)
        for v in bm_ear.verts:
            v.co.x *= 0.35
            v.co.y *= 0.8
            v.co.z *= 1.4
            v.co = Euler((0, math.radians(-10 * side), math.radians(15 * side))).to_matrix() @ v.co
            v.co.x += side * 0.098
            v.co.y -= 0.005
            v.co.z += 1.62
        make_mesh_obj(f"Ear_{'L' if side > 0 else 'R'}", bm_ear, mats["skin"])

    # Eyes & Eyebrows
    for side in (-1, 1):
        # Eyeball
        bm_eye = bmesh.new()
        bmesh.ops.create_uvsphere(bm_eye, u_segments=16, v_segments=12, radius=0.016)
        for v in bm_eye.verts:
            v.co.x += side * 0.038
            v.co.y += 0.090
            v.co.z += 1.630
        make_mesh_obj(f"EyeBall_{'L' if side > 0 else 'R'}", bm_eye, mats["eye_white"])
        
        # Iris
        bm_iris = bmesh.new()
        bmesh.ops.create_uvsphere(bm_iris, u_segments=12, v_segments=8, radius=0.009)
        for v in bm_iris.verts:
            v.co.y *= 0.3
            v.co.x += side * 0.038
            v.co.y += 0.103
            v.co.z += 1.630
        make_mesh_obj(f"Iris_{'L' if side > 0 else 'R'}", bm_iris, mats["eye_iris"])
        
        # Pupil & Specular glint
        bm_pupil = bmesh.new()
        bmesh.ops.create_uvsphere(bm_pupil, u_segments=8, v_segments=6, radius=0.004)
        for v in bm_pupil.verts:
            v.co.y *= 0.2
            v.co.x += side * 0.038
            v.co.y += 0.106
            v.co.z += 1.630
        make_mesh_obj(f"Pupil_{'L' if side > 0 else 'R'}", bm_pupil, mats["eye_pupil"])
        
        bm_glint = bmesh.new()
        bmesh.ops.create_uvsphere(bm_glint, u_segments=6, v_segments=4, radius=0.0025)
        for v in bm_glint.verts:
            v.co.x += side * 0.035 + 0.002
            v.co.y += 0.107
            v.co.z += 1.633
        make_mesh_obj(f"Glint_{'L' if side > 0 else 'R'}", bm_glint, mats["eye_highlight"])
        
        # Eyebrows (angled masculine youthful shape)
        bm_brow = bmesh.new()
        bmesh.ops.create_cube(bm_brow, size=1.0)
        for v in bm_brow.verts:
            v.co.x *= 0.032
            v.co.y *= 0.005
            v.co.z *= 0.006
            # arch eyebrow
            v.co = Euler((0, 0, math.radians(-12 * side))).to_matrix() @ v.co
            v.co.x += side * 0.040
            v.co.y += 0.098
            v.co.z += 1.650
        make_mesh_obj(f"Eyebrow_{'L' if side > 0 else 'R'}", bm_brow, mats["eyebrow"])

def build_hair(mats):
    # Stylized hair peeking from under cap: bangs sweeping across forehead and side locks
    strands = [
        # (center_x, center_y, center_z, scale_x, scale_y, scale_z, rot_x, rot_y, rot_z)
        # Bangs sweeping across front
        (-0.025, 0.092, 1.670, 0.025, 0.015, 0.045, -20, 15, -25),
        (0.010, 0.095, 1.665, 0.028, 0.015, 0.050, -22, -10, 15),
        (-0.050, 0.085, 1.660, 0.022, 0.014, 0.048, -15, 25, -35),
        (0.045, 0.087, 1.658, 0.024, 0.014, 0.046, -18, -20, 28),
        # Sideburn locks framing face
        (-0.088, 0.040, 1.615, 0.018, 0.025, 0.055, 10, 10, -5),
        (0.088, 0.040, 1.615, 0.018, 0.025, 0.055, 10, -10, 5),
        (-0.082, 0.015, 1.585, 0.015, 0.022, 0.050, 15, 5, -8),
        (0.082, 0.015, 1.585, 0.015, 0.022, 0.050, 15, -5, 8),
        # Back locks below cap
        (-0.040, -0.075, 1.565, 0.028, 0.020, 0.055, 25, 10, -10),
        (0.040, -0.075, 1.565, 0.028, 0.020, 0.055, 25, -10, 10),
        (0.000, -0.082, 1.555, 0.032, 0.020, 0.060, 28, 0, 0),
    ]
    
    # Better approach: create each hair strand in its own transform
    bm_combined = bmesh.new()
    for sx, sy, sz, scx, scy, scz, rx, ry, rz in strands:
        bm_piece = bmesh.new()
        bmesh.ops.create_cone(bm_piece, cap_ends=True, cap_tris=False, segments=10,
                              radius1=scx, radius2=scx * 0.15, depth=scz * 2)
        # flatten slightly
        for v in bm_piece.verts:
            v.co.y *= (scy / scx)
        # rotate & translate
        rot_m = Euler((math.radians(rx), math.radians(ry), math.radians(rz))).to_matrix()
        for v in bm_piece.verts:
            v.co = rot_m @ v.co
            v.co += Vector((sx, sy, sz))
        
        # Merge into combined
        for v in bm_piece.verts:
            bm_combined.verts.new(v.co)
        bm_combined.verts.ensure_lookup_table()
        vert_offset = len(bm_combined.verts) - len(bm_piece.verts)
        for f in bm_piece.faces:
            bm_combined.faces.new([bm_combined.verts[vert_offset + v.index] for v in f.verts])
        bm_piece.free()
        
    hair_obj = make_mesh_obj("Hair", bm_combined, mats["hair"])

def build_hat(mats):
    # Cap Crown: Hemisphere dome fitted on head
    bm_crown = bmesh.new()
    bmesh.ops.create_uvsphere(bm_crown, u_segments=24, v_segments=16, radius=0.108)
    
    # Slice lower hemisphere to form cap crown
    verts_to_remove = [v for v in bm_crown.verts if v.co.z < -0.015]
    bmesh.ops.delete(bm_crown, geom=verts_to_remove, context='VERTS')
    
    # Shape crown: slightly curved streetwear profile, tilted slightly back & left for stylish attitude
    tilt_m = Euler((math.radians(-4), math.radians(3), math.radians(-2))).to_matrix()
    for v in bm_crown.verts:
        v.co.x *= 0.98
        v.co.y *= 1.05
        v.co.z *= 0.92
        v.co = tilt_m @ v.co
        v.co.x -= 0.002
        v.co.y += 0.008
        v.co.z += 1.705
        
    cap_crown = make_mesh_obj("Cap_Crown", bm_crown, mats["cap_main"])
    
    # Add solidify modifier for realistic fabric thickness
    mod_solid = cap_crown.modifiers.new("Solidify", 'SOLIDIFY')
    mod_solid.thickness = 0.005
    mod_solid.offset = 1.0
    
    # Cap Button on top
    bm_button = bmesh.new()
    bmesh.ops.create_uvsphere(bm_button, u_segments=12, v_segments=8, radius=0.010)
    for v in bm_button.verts:
        v.co.z *= 0.4
        v.co.x -= 0.002
        v.co.y += 0.010
        v.co.z += 1.795
    make_mesh_obj("Cap_Button", bm_button, mats["cap_button"])
    
    # Cap Visor / Brim: Curved bill extending forward
    bm_visor = bmesh.new()
    # Create curved plane grid for visor
    bmesh.ops.create_grid(bm_visor, x_segments=12, y_segments=8, size=0.065)
    for v in bm_visor.verts:
        # X range ~ -0.065 to +0.065, Y range ~ -0.065 to +0.065
        # Transform into curved brim
        # arch the brim: edges curve downwards
        arch = (1.0 - (v.co.x / 0.065)**2) * 0.015
        v.co.z += arch
        
        # Tilt downwards forward
        v.co.z -= (v.co.y + 0.065) * 0.28
        
        # Shape the contour of the brim (wider at base, rounded at front tip)
        y_norm = (v.co.y + 0.065) / 0.13 # 0 at back, 1 at front
        v.co.x *= (1.0 - 0.25 * (y_norm**2))
        
        # Position at front of cap
        v.co.y += 0.145
        v.co.z += 1.685
        
    visor = make_mesh_obj("Cap_Visor", bm_visor, mats["cap_visor"])
    mod_v_solid = visor.modifiers.new("Solidify", 'SOLIDIFY')
    mod_v_solid.thickness = 0.004
    
    # Front Patch / Logo Emblem on cap
    bm_patch = bmesh.new()
    bmesh.ops.create_cube(bm_patch, size=1.0)
    for v in bm_patch.verts:
        v.co.x *= 0.026
        v.co.y *= 0.003
        v.co.z *= 0.016
        # curve slightly with crown
        v.co.y -= (v.co.x / 0.026)**2 * 0.003
        # tilt with forehead
        v.co = Euler((math.radians(-18), 0, 0)).to_matrix() @ v.co
        v.co.y += 0.108
        v.co.z += 1.732
    make_mesh_obj("Cap_Patch", bm_patch, mats["cap_patch"])
    
    # Back Strap & Buckle
    bm_strap = bmesh.new()
    bmesh.ops.create_cube(bm_strap, size=1.0)
    for v in bm_strap.verts:
        v.co.x *= 0.035
        v.co.y *= 0.003
        v.co.z *= 0.008
        v.co.y -= 0.095
        v.co.z += 1.688
    make_mesh_obj("Cap_Strap", bm_strap, mats["cap_strap"])
    
    bm_buckle = bmesh.new()
    bmesh.ops.create_cube(bm_buckle, size=1.0)
    for v in bm_buckle.verts:
        v.co.x *= 0.008
        v.co.y *= 0.004
        v.co.z *= 0.010
        v.co.y -= 0.098
        v.co.z += 1.688
    make_mesh_obj("Cap_Buckle", bm_buckle, mats["metal"])

def build_hoodie(mats):
    # Oversized Streetwear Hoodie Torso
    bm_torso = bmesh.new()
    bmesh.ops.create_uvsphere(bm_torso, u_segments=24, v_segments=16, radius=0.20)
    for v in bm_torso.verts:
        # Scale to fit upper body torso
        v.co.x *= 1.25 # shoulder width ~ 0.50m
        v.co.y *= 0.85 # chest depth
        v.co.z *= 1.35 # torso length
        
        # Silhouette: wider at chest/shoulders, slightly tapered at waist
        z_rel = (v.co.z) / 0.27 # roughly -1 to 1
        if z_rel < 0:
            # lower torso / hem
            v.co.x *= (1.0 + 0.08 * z_rel)
            v.co.y *= (1.0 + 0.12 * z_rel)
        else:
            # chest & shoulders
            v.co.x *= (1.0 + 0.15 * z_rel)
            
        v.co.y += 0.01
        v.co.z += 1.26
        
    torso = make_mesh_obj("Hoodie_Torso", bm_torso, mats["hoodie"])
    
    # Bottom Ribbed Waistband
    bm_rib = bmesh.new()
    bmesh.ops.create_cone(bm_rib, cap_ends=False, segments=24, radius1=0.21, radius2=0.22, depth=0.08)
    for v in bm_rib.verts:
        v.co.y *= 0.82
        v.co.y += 0.01
        v.co.z += 1.01
    make_mesh_obj("Hoodie_HemRib", bm_rib, mats["hoodie_rib"])
    
    # Kangaroo Pocket in front
    bm_pock = bmesh.new()
    bmesh.ops.create_cube(bm_pock, size=1.0)
    for v in bm_pock.verts:
        v.co.x *= 0.16
        v.co.y *= 0.035
        v.co.z *= 0.10
        # taper top of pocket
        if v.co.z > 0:
            v.co.x *= 0.75
        # curve with belly
        v.co.y -= (v.co.x / 0.16)**2 * 0.015
        v.co.y += 0.165
        v.co.z += 1.14
    make_mesh_obj("Hoodie_Pocket", bm_pock, mats["hoodie"])
    
    # Draped Hood around neck & back
    bm_hood = bmesh.new()
    bmesh.ops.create_uvsphere(bm_hood, u_segments=20, v_segments=12, radius=0.15)
    # slice front off
    verts_del = [v for v in bm_hood.verts if v.co.y > 0.02 and v.co.z > 0]
    bmesh.ops.delete(bm_hood, geom=verts_del, context='VERTS')
    for v in bm_hood.verts:
        v.co.x *= 1.15
        v.co.y *= 0.95
        v.co.z *= 0.85
        # drape down back
        v.co.y -= 0.06
        v.co.z += 1.44
    hood = make_mesh_obj("Hood_Drape", bm_hood, mats["hoodie"])
    mod_h_sol = hood.modifiers.new("Solidify", 'SOLIDIFY')
    mod_h_sol.thickness = 0.008
    
    # Thick Collar Rim
    bm_col = bmesh.new()
    make_torus_bm(bm_col, major_radius=0.10, minor_radius=0.022, major_segments=24, minor_segments=8)
    for v in bm_col.verts:
        v.co.x *= 1.05
        v.co.y *= 0.95
        v.co.y += 0.01
        v.co.z += 1.45
    make_mesh_obj("Hoodie_Collar", bm_col, mats["hoodie_rib"])
    
    # Drawstring cords hanging down
    for side in (-1, 1):
        bm_cord = bmesh.new()
        bmesh.ops.create_cone(bm_cord, cap_ends=True, segments=8, radius1=0.004, radius2=0.004, depth=0.18)
        for v in bm_cord.verts:
            # gentle wave
            wave = math.sin((v.co.z + 0.09) * 20) * 0.004
            v.co.x += wave
            v.co.x += side * 0.038
            v.co.y += 0.170
            v.co.z += 1.32
        make_mesh_obj(f"Cord_{'L' if side > 0 else 'R'}", bm_cord, mats["cord"])
        
        # Metal Aglet tip
        bm_aglet = bmesh.new()
        bmesh.ops.create_cone(bm_aglet, cap_ends=True, segments=8, radius1=0.005, radius2=0.004, depth=0.022)
        for v in bm_aglet.verts:
            v.co.x += side * 0.038
            v.co.y += 0.170
            v.co.z += 1.22
        make_mesh_obj(f"Aglet_{'L' if side > 0 else 'R'}", bm_aglet, mats["metal"])
        
        # Grommet ring
        bm_grom = bmesh.new()
        make_torus_bm(bm_grom, major_radius=0.008, minor_radius=0.0025, major_segments=12, minor_segments=6)
        for v in bm_grom.verts:
            v.co = Euler((math.radians(90), 0, 0)).to_matrix() @ v.co
            v.co.x += side * 0.038
            v.co.y += 0.165
            v.co.z += 1.41
        make_mesh_obj(f"Grommet_{'L' if side > 0 else 'R'}", bm_grom, mats["metal"])

def build_arms_and_hands(mats):
    # Relaxed streetwear pose: Arms angled downwards, hands resting casually in kangaroo pocket
    for side in (-1, 1):
        # Upper Arm / Shoulder
        bm_upper = bmesh.new()
        bmesh.ops.create_cone(bm_upper, cap_ends=True, segments=16, radius1=0.080, radius2=0.065, depth=0.28)
        for v in bm_upper.verts:
            # angle outward and slightly forward
            v.co = Euler((math.radians(10), math.radians(-24 * side), 0)).to_matrix() @ v.co
            v.co.x += side * 0.27
            v.co.y += 0.015
            v.co.z += 1.30
        make_mesh_obj(f"Arm_Upper_{'L' if side > 0 else 'R'}", bm_upper, mats["hoodie"])
        
        # Forearm angled inwards towards front pocket
        bm_fore = bmesh.new()
        bmesh.ops.create_cone(bm_fore, cap_ends=True, segments=16, radius1=0.065, radius2=0.052, depth=0.26)
        for v in bm_fore.verts:
            # angle forward-inward
            v.co = Euler((math.radians(-32), math.radians(35 * side), math.radians(-15 * side))).to_matrix() @ v.co
            v.co.x += side * 0.25
            v.co.y += 0.095
            v.co.z += 1.15
        make_mesh_obj(f"Arm_Fore_{'L' if side > 0 else 'R'}", bm_fore, mats["hoodie"])
        
        # Ribbed Wrist Cuff
        bm_cuff = bmesh.new()
        make_torus_bm(bm_cuff, major_radius=0.048, minor_radius=0.014, major_segments=16, minor_segments=8)
        for v in bm_cuff.verts:
            v.co = Euler((math.radians(-35), math.radians(40 * side), 0)).to_matrix() @ v.co
            v.co.x += side * 0.17
            v.co.y += 0.155
            v.co.z += 1.08
        make_mesh_obj(f"Cuff_{'L' if side > 0 else 'R'}", bm_cuff, mats["hoodie_rib"])
        
        # Hand (resting at pocket entrance)
        bm_hand = bmesh.new()
        bmesh.ops.create_uvsphere(bm_hand, u_segments=12, v_segments=8, radius=0.038)
        for v in bm_hand.verts:
            v.co.x *= 0.75
            v.co.y *= 1.2
            v.co.z *= 0.55
            v.co = Euler((math.radians(-25), math.radians(30 * side), 0)).to_matrix() @ v.co
            v.co.x += side * 0.13
            v.co.y += 0.175
            v.co.z += 1.06
        make_mesh_obj(f"Hand_{'L' if side > 0 else 'R'}", bm_hand, mats["skin"])

def build_pants(mats):
    # Streetwear Relaxed Cargo / Straight Jeans
    # Pelvis / Crotch connection
    bm_pelvis = bmesh.new()
    bmesh.ops.create_uvsphere(bm_pelvis, u_segments=20, v_segments=12, radius=0.20)
    for v in bm_pelvis.verts:
        v.co.x *= 1.05
        v.co.y *= 0.85
        v.co.z *= 0.80
        v.co.y += 0.01
        v.co.z += 0.95
    make_mesh_obj("Pants_Pelvis", bm_pelvis, mats["pants"])
    
    # Left and Right Legs
    for side in (-1, 1):
        # Thigh section
        bm_thigh = bmesh.new()
        bmesh.ops.create_cone(bm_thigh, cap_ends=True, segments=20, radius1=0.108, radius2=0.092, depth=0.45)
        for v in bm_thigh.verts:
            # subtle stance angle (feet slightly apart, relaxed stance)
            v.co = Euler((math.radians(2), math.radians(-3 * side), 0)).to_matrix() @ v.co
            v.co.x += side * 0.115
            v.co.y += 0.005
            v.co.z += 0.72
        make_mesh_obj(f"Pants_Thigh_{'L' if side > 0 else 'R'}", bm_thigh, mats["pants"])
        
        # Lower leg / Calf with cloth stacks over sneakers
        bm_calf = bmesh.new()
        bmesh.ops.create_cone(bm_calf, cap_ends=True, segments=20, radius1=0.092, radius2=0.082, depth=0.42)
        for v in bm_calf.verts:
            # folds near ankle
            z_norm = (v.co.z + 0.21) / 0.42 # 0 at bottom, 1 at top
            if z_norm < 0.25:
                # wrinkle expansion
                wrinkle = math.sin(z_norm * 40) * 0.008
                v.co.x += wrinkle
                v.co.y += wrinkle
            v.co.x += side * 0.128
            v.co.y -= 0.002
            v.co.z += 0.32
        make_mesh_obj(f"Pants_Calf_{'L' if side > 0 else 'R'}", bm_calf, mats["pants"])
        
        # Cargo Pocket on outer thigh
        bm_cargo = bmesh.new()
        bmesh.ops.create_cube(bm_cargo, size=1.0)
        for v in bm_cargo.verts:
            v.co.x *= 0.022
            v.co.y *= 0.065
            v.co.z *= 0.080
            v.co.x += side * (0.215)
            v.co.y += 0.010
            v.co.z += 0.68
        make_mesh_obj(f"Cargo_Pocket_{'L' if side > 0 else 'R'}", bm_cargo, mats["pants_detail"])
        
        # Cargo Pocket Flap
        bm_flap = bmesh.new()
        bmesh.ops.create_cube(bm_flap, size=1.0)
        for v in bm_flap.verts:
            v.co.x *= 0.025
            v.co.y *= 0.068
            v.co.z *= 0.020
            v.co.x += side * (0.218)
            v.co.y += 0.010
            v.co.z += 0.75
        make_mesh_obj(f"Cargo_Flap_{'L' if side > 0 else 'R'}", bm_flap, mats["pants_detail"])

def build_sneakers(mats):
    # Chunky Streetwear Skate Sneakers (Retro Basketball / Skate silhouette)
    for side in (-1, 1):
        # Chunky Midsole / Outsole
        bm_sole = bmesh.new()
        bmesh.ops.create_cube(bm_sole, size=1.0)
        for v in bm_sole.verts:
            v.co.x *= 0.062
            v.co.y *= 0.145
            v.co.z *= 0.025
            
            # Sole contour: narrower at arch, wider at ball of foot and heel
            y_pos = v.co.y / 0.145 # -1 (heel) to +1 (toe)
            if -0.2 < y_pos < 0.3:
                v.co.x *= 0.88 # arch indent
                
            # Toe spring (upward curve at toe)
            if y_pos > 0.4:
                v.co.z += ((y_pos - 0.4) / 0.6)**2 * 0.018
                
            # slight outward foot splay (natural human stance ~7 degrees)
            v.co = Euler((0, 0, math.radians(-7 * side))).to_matrix() @ v.co
            v.co.x += side * 0.138
            v.co.y += 0.035
            v.co.z += 0.025
        make_mesh_obj(f"Sneaker_Sole_{'L' if side > 0 else 'R'}", bm_sole, mats["sneaker_sole"])
        
        # Bottom Tread / Gum Sole layer
        bm_tread = bmesh.new()
        bmesh.ops.create_cube(bm_tread, size=1.0)
        for v in bm_tread.verts:
            v.co.x *= 0.060
            v.co.y *= 0.142
            v.co.z *= 0.005
            v.co = Euler((0, 0, math.radians(-7 * side))).to_matrix() @ v.co
            v.co.x += side * 0.138
            v.co.y += 0.035
            v.co.z += 0.005
        make_mesh_obj(f"Sneaker_Tread_{'L' if side > 0 else 'R'}", bm_tread, mats["sneaker_gum"])
        
        # Sneaker Upper (Main White Leather)
        bm_upper = bmesh.new()
        bmesh.ops.create_uvsphere(bm_upper, u_segments=16, v_segments=10, radius=0.075)
        for v in bm_upper.verts:
            v.co.x *= 0.72
            v.co.y *= 1.70
            v.co.z *= 0.65
            
            # flatten bottom
            if v.co.z < -0.01:
                v.co.z = -0.01
                
            v.co = Euler((0, 0, math.radians(-7 * side))).to_matrix() @ v.co
            v.co.x += side * 0.138
            v.co.y += 0.035
            v.co.z += 0.065
        make_mesh_obj(f"Sneaker_Upper_{'L' if side > 0 else 'R'}", bm_upper, mats["sneaker_white"])
        
        # Accent Stripe / Side Panel (Matches hoodie color)
        bm_stripe = bmesh.new()
        bmesh.ops.create_cube(bm_stripe, size=1.0)
        for v in bm_stripe.verts:
            v.co.x *= 0.005
            v.co.y *= 0.075
            v.co.z *= 0.018
            # angle down along side of shoe
            v.co = Euler((math.radians(12), 0, math.radians(-7 * side))).to_matrix() @ v.co
            v.co.x += side * (0.138 + 0.048 * side)
            v.co.y += 0.030
            v.co.z += 0.065
        make_mesh_obj(f"Sneaker_Stripe_{'L' if side > 0 else 'R'}", bm_stripe, mats["sneaker_accent"])
        
        # Padded Collar / Ankle Rim (Black accent)
        bm_rim = bmesh.new()
        make_torus_bm(bm_rim, major_radius=0.048, minor_radius=0.015, major_segments=16, minor_segments=8)
        for v in bm_rim.verts:
            v.co = Euler((math.radians(15), 0, math.radians(-7 * side))).to_matrix() @ v.co
            v.co.x += side * 0.138
            v.co.y += 0.005
            v.co.z += 0.115
        make_mesh_obj(f"Sneaker_Collar_{'L' if side > 0 else 'R'}", bm_rim, mats["sneaker_black"])
        
        # Tongue & Laces
        bm_tongue = bmesh.new()
        bmesh.ops.create_cube(bm_tongue, size=1.0)
        for v in bm_tongue.verts:
            v.co.x *= 0.028
            v.co.y *= 0.065
            v.co.z *= 0.008
            v.co = Euler((math.radians(-38), 0, math.radians(-7 * side))).to_matrix() @ v.co
            v.co.x += side * 0.138
            v.co.y += 0.065
            v.co.z += 0.095
        make_mesh_obj(f"Sneaker_Tongue_{'L' if side > 0 else 'R'}", bm_tongue, mats["sneaker_black"])
        
        # Criss-cross laces
        for i in range(3):
            bm_lace = bmesh.new()
            bmesh.ops.create_cube(bm_lace, size=1.0)
            for v in bm_lace.verts:
                v.co.x *= 0.024
                v.co.y *= 0.006
                v.co.z *= 0.004
                v.co = Euler((math.radians(-38), 0, math.radians(-7 * side))).to_matrix() @ v.co
                v.co.x += side * 0.138
                v.co.y += 0.045 + i * 0.022
                v.co.z += 0.080 + i * 0.015
            make_mesh_obj(f"Sneaker_Lace_{i}_{'L' if side > 0 else 'R'}", bm_lace, mats["sneaker_white"])

def build_backdrop(mats):
    # Studio Cyclorama (Smooth curved floor-to-wall)
    bm = bmesh.new()
    # Create smooth floor curving up into back wall
    verts = []
    # Grid of points along X (-2.5 to +2.5) and Y (-1.5 to +3.5)
    xs = [-2.5 + i * 0.5 for i in range(11)]
    # profile along Y/Z
    profile = []
    # floor
    for y in [-1.5, -0.8, 0.0, 0.8, 1.2]:
        profile.append((y, 0.0))
    # curve
    for angle_deg in [15, 30, 45, 60, 75, 90]:
        rad = math.radians(angle_deg)
        y = 1.2 + 0.8 * math.sin(rad)
        z = 0.8 * (1.0 - math.cos(rad))
        profile.append((y, z))
    # wall
    for z in [1.2, 1.8, 2.6, 3.5]:
        profile.append((2.0, z))
        
    grid_verts = []
    for y, z in profile:
        row = []
        for x in xs:
            v = bm.verts.new((x, y, z))
            row.append(v)
        grid_verts.append(row)
    bm.verts.ensure_lookup_table()
    
    for r in range(len(grid_verts) - 1):
        for c in range(len(xs) - 1):
            v1 = grid_verts[r][c]
            v2 = grid_verts[r][c+1]
            v3 = grid_verts[r+1][c+1]
            v4 = grid_verts[r+1][c]
            bm.faces.new([v1, v2, v3, v4])
            
    cyc = make_mesh_obj("Studio_Cyclorama", bm, mats["backdrop"])
    return cyc

def setup_lighting():
    # 1. Warm Key Light (Front-Right 45 degrees, flattering angle)
    key_data = bpy.data.lights.new(name="Key_Light", type='AREA')
    key_data.energy = 380.0
    key_data.size = 1.2
    key_data.color = (1.0, 0.94, 0.88) # Warm studio key
    key_obj = bpy.data.objects.new(name="Key_Light", object_data=key_data)
    key_obj.location = (1.6, -1.8, 2.3)
    # Aim at character chest/face (0, 0, 1.4)
    key_obj.rotation_euler = Euler((math.radians(60), math.radians(10), math.radians(40)))
    bpy.context.scene.collection.objects.link(key_obj)
    
    # 2. Cool Fill Light (Front-Left, softer, lowers contrast ratio)
    fill_data = bpy.data.lights.new(name="Fill_Light", type='AREA')
    fill_data.energy = 140.0
    fill_data.size = 2.0
    fill_data.color = (0.86, 0.92, 1.0) # Soft cool blue fill
    fill_obj = bpy.data.objects.new(name="Fill_Light", object_data=fill_data)
    fill_obj.location = (-1.8, -1.6, 1.7)
    fill_obj.rotation_euler = Euler((math.radians(65), math.radians(-10), math.radians(-45)))
    bpy.context.scene.collection.objects.link(fill_obj)
    
    # 3. Bright Rim / Kicker Light (High Back-Left, separates character silhouette)
    rim_data = bpy.data.lights.new(name="Rim_Light", type='AREA')
    rim_data.energy = 480.0
    rim_data.size = 1.0
    rim_data.color = (1.0, 0.98, 0.95)
    rim_obj = bpy.data.objects.new(name="Rim_Light", object_data=rim_data)
    rim_obj.location = (-1.2, 1.5, 2.5)
    rim_obj.rotation_euler = Euler((math.radians(-50), math.radians(20), math.radians(-145)))
    bpy.context.scene.collection.objects.link(rim_obj)
    
    # 4. Top Soft Overhead Light
    top_data = bpy.data.lights.new(name="Top_Light", type='AREA')
    top_data.energy = 120.0
    top_data.size = 2.5
    top_data.color = (0.95, 0.95, 0.98)
    top_obj = bpy.data.objects.new(name="Top_Light", object_data=top_data)
    top_obj.location = (0.0, -0.2, 3.2)
    top_obj.rotation_euler = Euler((0, 0, 0))
    bpy.context.scene.collection.objects.link(top_obj)

def setup_camera():
    cam_data = bpy.data.cameras.new("Main_Camera")
    cam_data.lens = 75.0 # Flattering portrait focal length
    cam_data.sensor_width = 36.0
    
    cam_obj = bpy.data.objects.new("Main_Camera", cam_data)
    # Position camera for full-body / 3/4 hero view
    cam_obj.location = (0.35, -3.2, 1.25)
    # Look slightly up at character chest-face (0, 0, 1.2)
    cam_obj.rotation_euler = Euler((math.radians(88), 0, math.radians(6)))
    bpy.context.scene.collection.objects.link(cam_obj)
    bpy.context.scene.camera = cam_obj
    return cam_obj

def setup_render(output_path, samples=48):
    scene = bpy.context.scene
    scene.render.engine = 'CYCLES'
    scene.cycles.device = 'CPU'
    scene.cycles.samples = samples
    scene.cycles.use_denoising = True
    
    # High resolution: 1440x1920 (stylish portrait aspect ratio 3:4)
    scene.render.resolution_x = 1200
    scene.render.resolution_y = 1600
    scene.render.resolution_percentage = 100
    
    # Color management: AgX High Contrast
    scene.view_settings.view_transform = 'AgX'
    scene.view_settings.look = 'AgX - High Contrast'
    
    scene.render.filepath = output_path
    scene.render.image_settings.file_format = 'PNG'
    scene.render.image_settings.color_mode = 'RGBA'

def main():
    print("[1/6] Initializing scene...")
    clear_scene()
    
    print("[2/6] Building PBR materials...")
    mats = build_materials()
    
    print("[3/6] Generating character geometry...")
    build_head(mats)
    build_hair(mats)
    build_hat(mats)
    build_hoodie(mats)
    build_arms_and_hands(mats)
    build_pants(mats)
    build_sneakers(mats)
    build_backdrop(mats)
    
    print("[4/6] Setting up studio lighting & camera...")
    setup_lighting()
    setup_camera()
    
    # Output paths
    out_blend = "/home/rois/jarvis/blender-character/karakter_pria_topi.blend"
    out_png = "/home/rois/jarvis/blender-character/render_preview.png"
    
    print(f"[5/6] Saving .blend file to {out_blend}...")
    bpy.ops.wm.save_as_mainfile(filepath=out_blend)
    
    print(f"[6/6] Rendering preview with Cycles to {out_png}...")
    setup_render(out_png, samples=48)
    bpy.ops.render.render(write_still=True)
    
    total_tris = sum(len(o.data.polygons) * 2 for o in bpy.data.objects if o.type == 'MESH')
    total_objs = len(bpy.data.objects)
    print(f"DONE! Objects: {total_objs}, Approx Tris: {total_tris}")
    print(f"Blend file: {out_blend}")
    print(f"Render image: {out_png}")

if __name__ == "__main__":
    main()
