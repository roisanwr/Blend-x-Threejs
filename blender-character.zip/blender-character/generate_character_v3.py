#!/usr/bin/env python3
"""
Blender 5.2 Character Generator - Version 3
Polished Stylized Young Adult Male Character in Streetwear with Hat.
- Natural relaxed posture (hands in kangaroo pocket, slight hip shift)
- Detailed expressive face with defined eyes, eyelids, nose, lips, and brows
- Stylish curved hair fringe under cap brim
- Baseball cap with crown, curved visor, button, patch emblem, and strap
- Streetwear oversized hoodie with soft beveled kangaroo pocket, natural drooping drawstrings, metal aglets
- Relaxed straight cargo pants with soft folds and cargo flap pockets
- Chunky two-tone skate sneakers fully visible with contact shadows on studio cyclorama
"""
import bpy
import bmesh
from mathutils import Vector, Matrix, Euler
import math

def clear_scene():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    if not bpy.data.collections:
        col = bpy.data.collections.new("Collection")
        bpy.context.scene.collection.children.link(col)

def create_pbr_material(name, base_color, roughness=0.5, metallic=0.0, sss_weight=0.0, sss_radius=(1.0, 0.35, 0.2), sheen_weight=0.0):
    mat = bpy.data.materials.new(name=name)
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()
    
    out = nodes.new("ShaderNodeOutputMaterial")
    out.location = (350, 0)
    
    bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.location = (0, 0)
    links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
    
    bsdf.inputs["Base Color"].default_value = (*base_color, 1.0)
    bsdf.inputs["Roughness"].default_value = roughness
    bsdf.inputs["Metallic"].default_value = metallic
    
    if "Subsurface Weight" in bsdf.inputs and sss_weight > 0:
        bsdf.inputs["Subsurface Weight"].default_value = sss_weight
        bsdf.inputs["Subsurface Radius"].default_value = sss_radius
        bsdf.inputs["Subsurface Scale"].default_value = 0.025
        
    if "Sheen Weight" in bsdf.inputs and sheen_weight > 0:
        bsdf.inputs["Sheen Weight"].default_value = sheen_weight
        
    return mat

def apply_smooth_and_subd(obj, levels=1):
    for p in obj.data.polygons:
        p.use_smooth = True
    if levels > 0:
        sub = obj.modifiers.new("Subdivision", 'SUBSURF')
        sub.levels = levels
        sub.render_levels = levels
    obj.data.update()

def make_obj(name, bm, material=None, subd_levels=0):
    mesh = bpy.data.meshes.new(name)
    bm.to_mesh(mesh)
    bm.free()
    obj = bpy.data.objects.new(name, mesh)
    bpy.context.scene.collection.objects.link(obj)
    if material:
        obj.data.materials.append(material)
    apply_smooth_and_subd(obj, subd_levels)
    return obj

def make_torus_bm(bm, major_radius, minor_radius, major_segments=24, minor_segments=8):
    verts = []
    for i in range(major_segments):
        phi = 2.0 * math.pi * i / major_segments
        cos_phi = math.cos(phi)
        sin_phi = math.sin(phi)
        ring = []
        for j in range(minor_segments):
            theta = 2.0 * math.pi * j / minor_segments
            r = major_radius + minor_radius * math.cos(theta)
            z = minor_radius * math.sin(theta)
            x = r * cos_phi
            y = r * sin_phi
            ring.append(bm.verts.new((x, y, z)))
        verts.append(ring)
    bm.verts.ensure_lookup_table()
    for i in range(major_segments):
        next_i = (i + 1) % major_segments
        for j in range(minor_segments):
            next_j = (j + 1) % minor_segments
            v1 = verts[i][j]
            v2 = verts[next_i][j]
            v3 = verts[next_i][next_j]
            v4 = verts[i][next_j]
            bm.faces.new([v1, v2, v3, v4])

def make_tube_along_curve(points, radius=0.005, segments=8):
    bm = bmesh.new()
    rings = []
    for idx, pt in enumerate(points):
        # Calculate tangent
        if idx == 0:
            tangent = (points[1] - pt).normalized()
        elif idx == len(points) - 1:
            tangent = (pt - points[-1]).normalized()
        else:
            tangent = (points[idx+1] - points[idx-1]).normalized()
            
        up = Vector((0, 0, 1))
        if abs(tangent.dot(up)) > 0.9:
            up = Vector((1, 0, 0))
        normal = tangent.cross(up).normalized()
        binormal = tangent.cross(normal).normalized()
        
        ring = []
        for s in range(segments):
            angle = 2.0 * math.pi * s / segments
            offset = normal * (radius * math.cos(angle)) + binormal * (radius * math.sin(angle))
            v = bm.verts.new(pt + offset)
            ring.append(v)
        rings.append(ring)
        
    bm.verts.ensure_lookup_table()
    for r in range(len(rings) - 1):
        for s in range(segments):
            next_s = (s + 1) % segments
            v1 = rings[r][s]
            v2 = rings[r][next_s]
            v3 = rings[r+1][next_s]
            v4 = rings[r+1][s]
            bm.faces.new([v1, v2, v3, v4])
            
    # Caps
    bm.faces.new(rings[0])
    bm.faces.new(list(reversed(rings[-1])))
    return bm

def build_materials():
    mats = {}
    # Skin: Rich warm healthy young adult tone with SSS
    mats["skin"] = create_pbr_material("M_Skin", (0.84, 0.65, 0.54), roughness=0.45, sss_weight=0.5)
    mats["lips"] = create_pbr_material("M_Lips", (0.76, 0.45, 0.42), roughness=0.35, sss_weight=0.35)
    
    # Eyes & Eyebrows
    mats["eye_sclera"] = create_pbr_material("M_EyeSclera", (0.94, 0.94, 0.95), roughness=0.10)
    mats["eye_iris"] = create_pbr_material("M_EyeIris", (0.16, 0.09, 0.05), roughness=0.08)
    mats["eye_pupil"] = create_pbr_material("M_EyePupil", (0.01, 0.01, 0.01), roughness=0.02)
    mats["eye_glint"] = create_pbr_material("M_EyeGlint", (1.0, 1.0, 1.0), roughness=0.02)
    mats["eyeliner"] = create_pbr_material("M_EyeLiner", (0.06, 0.04, 0.03), roughness=0.5)
    mats["eyebrow"] = create_pbr_material("M_Eyebrow", (0.06, 0.04, 0.03), roughness=0.7)
    
    # Hair
    mats["hair"] = create_pbr_material("M_Hair", (0.05, 0.038, 0.03), roughness=0.52, sheen_weight=0.4)
    
    # Cap (Washed Dark Navy)
    mats["cap_crown"] = create_pbr_material("M_Cap_Crown", (0.04, 0.06, 0.10), roughness=0.75, sheen_weight=0.55)
    mats["cap_visor"] = create_pbr_material("M_Cap_Visor", (0.03, 0.05, 0.08), roughness=0.70, sheen_weight=0.45)
    mats["cap_button"] = create_pbr_material("M_Cap_Button", (0.07, 0.10, 0.15), roughness=0.65)
    mats["cap_patch"] = create_pbr_material("M_Cap_Patch", (0.85, 0.80, 0.72), roughness=0.6)
    mats["cap_strap"] = create_pbr_material("M_Cap_Strap", (0.12, 0.08, 0.05), roughness=0.5)
    mats["metal"] = create_pbr_material("M_Metal", (0.75, 0.75, 0.78), roughness=0.25, metallic=0.95)
    
    # Streetwear Hoodie (Matcha / Sage Green)
    mats["hoodie"] = create_pbr_material("M_Hoodie", (0.16, 0.28, 0.21), roughness=0.82, sheen_weight=0.65)
    mats["hoodie_rib"] = create_pbr_material("M_HoodieRib", (0.13, 0.23, 0.17), roughness=0.88, sheen_weight=0.55)
    mats["cord"] = create_pbr_material("M_Cord", (0.86, 0.84, 0.81), roughness=0.65)
    
    # Cargo Pants (Dark Charcoal Slate)
    mats["pants"] = create_pbr_material("M_Pants", (0.07, 0.08, 0.10), roughness=0.82, sheen_weight=0.35)
    mats["pants_detail"] = create_pbr_material("M_PantsDetail", (0.10, 0.11, 0.14), roughness=0.8)
    
    # Sneakers
    mats["sneaker_white"] = create_pbr_material("M_SneakerWhite", (0.92, 0.92, 0.93), roughness=0.42)
    mats["sneaker_black"] = create_pbr_material("M_SneakerBlack", (0.03, 0.03, 0.04), roughness=0.5)
    mats["sneaker_accent"] = create_pbr_material("M_SneakerAccent", (0.16, 0.28, 0.21), roughness=0.48)
    mats["sneaker_sole"] = create_pbr_material("M_SneakerSole", (0.95, 0.94, 0.93), roughness=0.55)
    mats["sneaker_gum"] = create_pbr_material("M_SneakerGum", (0.48, 0.33, 0.18), roughness=0.6)
    
    # Studio Backdrop (Neutral Slate Grey)
    mats["backdrop"] = create_pbr_material("M_Backdrop", (0.22, 0.24, 0.28), roughness=0.92)
    
    return mats

def build_head_and_face(mats):
    # Head Base: Young adult male skull
    bm = bmesh.new()
    bmesh.ops.create_uvsphere(bm, u_segments=28, v_segments=18, radius=0.102)
    for v in bm.verts:
        x, y, z = v.co.x, v.co.y, v.co.z
        if z < 0:
            factor = (-z) / 0.102
            v.co.x *= (1.0 - 0.25 * factor)
            if y < 0:
                v.co.y -= 0.018 * factor # Defined chin projecting forward
            else:
                v.co.y *= (1.0 - 0.12 * factor)
        if z > 0.02:
            v.co.x *= 0.96
            v.co.y *= 1.02
        v.co.z *= 1.14
        v.co.y *= 1.06
        v.co.z += 1.60
    head = make_obj("Head", bm, mats["skin"], subd_levels=1)
    
    # Neck
    bm_neck = bmesh.new()
    bmesh.ops.create_cone(bm_neck, cap_ends=True, cap_tris=False, segments=22,
                          radius1=0.062, radius2=0.055, depth=0.14)
    for v in bm_neck.verts:
        v.co.z += 1.48
        v.co.y += 0.005
    make_obj("Neck", bm_neck, mats["skin"])
    
    # Nose (Sculpted defined bridge and tip)
    bm_nose = bmesh.new()
    bmesh.ops.create_cone(bm_nose, cap_ends=True, cap_tris=False, segments=12,
                          radius1=0.015, radius2=0.005, depth=0.040)
    for v in bm_nose.verts:
        v.co = Euler((math.radians(-75), 0, 0)).to_matrix() @ v.co
        v.co.y -= 0.114
        v.co.z += 1.585
    make_obj("Nose", bm_nose, mats["skin"], subd_levels=1)
    
    # Lips (Stylized defined youthful mouth with philtrum)
    bm_lips = bmesh.new()
    bmesh.ops.create_uvsphere(bm_lips, u_segments=18, v_segments=10, radius=0.018)
    for v in bm_lips.verts:
        v.co.x *= 1.7
        v.co.y *= 0.45
        v.co.z *= 0.42
        v.co.y -= 0.103
        v.co.z += 1.528
    make_obj("Lips", bm_lips, mats["lips"], subd_levels=1)
    
    # Ears
    for side in (-1, 1):
        bm_ear = bmesh.new()
        bmesh.ops.create_uvsphere(bm_ear, u_segments=14, v_segments=10, radius=0.026)
        for v in bm_ear.verts:
            v.co.x *= 0.35
            v.co.y *= 0.8
            v.co.z *= 1.4
            v.co = Euler((0, math.radians(10 * side), math.radians(-15 * side))).to_matrix() @ v.co
            v.co.x += side * 0.098
            v.co.y += 0.005
            v.co.z += 1.60
        make_obj(f"Ear_{'L' if side > 0 else 'R'}", bm_ear, mats["skin"], subd_levels=1)

    # Eyes & Eyebrows
    for side in (-1, 1):
        # Sclera
        bm_eye = bmesh.new()
        bmesh.ops.create_uvsphere(bm_eye, u_segments=18, v_segments=12, radius=0.017)
        for v in bm_eye.verts:
            v.co.x += side * 0.038
            v.co.y -= 0.090
            v.co.z += 1.615
        make_obj(f"EyeBall_{'L' if side > 0 else 'R'}", bm_eye, mats["eye_sclera"])
        
        # Iris (Large anime/stylized iris)
        bm_iris = bmesh.new()
        bmesh.ops.create_uvsphere(bm_iris, u_segments=14, v_segments=10, radius=0.0105)
        for v in bm_iris.verts:
            v.co.y *= 0.25
            v.co.x += side * 0.038
            v.co.y -= 0.104
            v.co.z += 1.615
        make_obj(f"Iris_{'L' if side > 0 else 'R'}", bm_iris, mats["eye_iris"])
        
        # Pupil
        bm_pupil = bmesh.new()
        bmesh.ops.create_uvsphere(bm_pupil, u_segments=10, v_segments=8, radius=0.005)
        for v in bm_pupil.verts:
            v.co.y *= 0.2
            v.co.x += side * 0.038
            v.co.y -= 0.107
            v.co.z += 1.615
        make_obj(f"Pupil_{'L' if side > 0 else 'R'}", bm_pupil, mats["eye_pupil"])
        
        # Specular Glint
        bm_glint = bmesh.new()
        bmesh.ops.create_uvsphere(bm_glint, u_segments=8, v_segments=6, radius=0.0032)
        for v in bm_glint.verts:
            v.co.x += side * 0.035 - 0.002
            v.co.y -= 0.108
            v.co.z += 1.619
        make_obj(f"Glint_{'L' if side > 0 else 'R'}", bm_glint, mats["eye_glint"])
        
        # Eyelash / Upper Eyeliner Lid (gives strong anime-stylized contrast!)
        bm_lid = bmesh.new()
        bmesh.ops.create_cube(bm_lid, size=1.0)
        for v in bm_lid.verts:
            v.co.x *= 0.022
            v.co.y *= 0.004
            v.co.z *= 0.0035
            # arch over eyeball
            v.co = Euler((0, 0, math.radians(-5 * side))).to_matrix() @ v.co
            v.co.x += side * 0.038
            v.co.y -= 0.104
            v.co.z += 1.628
        make_obj(f"EyeLid_{'L' if side > 0 else 'R'}", bm_lid, mats["eyeliner"], subd_levels=1)
        
        # Eyebrows (Defined confident male arch)
        bm_brow = bmesh.new()
        bmesh.ops.create_cube(bm_brow, size=1.0)
        for v in bm_brow.verts:
            v.co.x *= 0.030
            v.co.y *= 0.005
            v.co.z *= 0.0055
            v.co = Euler((0, 0, math.radians(14 * side))).to_matrix() @ v.co
            v.co.x += side * 0.040
            v.co.y -= 0.102
            v.co.z += 1.642
        make_obj(f"Eyebrow_{'L' if side > 0 else 'R'}", bm_brow, mats["eyebrow"], subd_levels=1)

def build_hair(mats):
    # Smooth stylized fringe locks peeking out from under cap front (-Y)
    strands = [
        # (center_x, center_y, center_z, scale_x, scale_y, scale_z, rot_x, rot_y, rot_z)
        (-0.026, -0.096, 1.652, 0.024, 0.015, 0.042, 22, 12, 24),
        (0.012, -0.098, 1.648, 0.026, 0.015, 0.046, 24, -10, -16),
        (-0.054, -0.090, 1.642, 0.022, 0.014, 0.044, 16, 22, 34),
        (0.046, -0.091, 1.640, 0.024, 0.014, 0.043, 19, -18, -26),
        # Sideburns
        (-0.088, -0.035, 1.595, 0.018, 0.025, 0.052, -10, 10, 5),
        (0.088, -0.035, 1.595, 0.018, 0.025, 0.052, -10, -10, -5),
        (-0.082, -0.010, 1.565, 0.015, 0.022, 0.048, -15, 5, 8),
        (0.082, -0.010, 1.565, 0.015, 0.022, 0.048, -15, -5, -8),
        # Back locks
        (-0.038, 0.075, 1.545, 0.026, 0.020, 0.050, -25, 10, 10),
        (0.038, 0.075, 1.545, 0.026, 0.020, 0.050, -25, -10, -10),
    ]
    
    bm_combined = bmesh.new()
    for sx, sy, sz, scx, scy, scz, rx, ry, rz in strands:
        bm_piece = bmesh.new()
        bmesh.ops.create_cone(bm_piece, cap_ends=True, cap_tris=False, segments=12,
                              radius1=scx, radius2=scx * 0.20, depth=scz * 2)
        for v in bm_piece.verts:
            v.co.y *= (scy / scx)
        rot_m = Euler((math.radians(rx), math.radians(ry), math.radians(rz))).to_matrix()
        for v in bm_piece.verts:
            v.co = rot_m @ v.co
            v.co += Vector((sx, sy, sz))
        
        for v in bm_piece.verts:
            bm_combined.verts.new(v.co)
        bm_combined.verts.ensure_lookup_table()
        vert_offset = len(bm_combined.verts) - len(bm_piece.verts)
        for f in bm_piece.faces:
            bm_combined.faces.new([bm_combined.verts[vert_offset + v.index] for v in f.verts])
        bm_piece.free()
        
    make_obj("Hair", bm_combined, mats["hair"], subd_levels=1)

def build_hat(mats):
    # Cap Crown: Fitted snugly over the skull
    bm_crown = bmesh.new()
    bmesh.ops.create_uvsphere(bm_crown, u_segments=30, v_segments=20, radius=0.114)
    
    verts_to_remove = [v for v in bm_crown.verts if v.co.z < -0.025]
    bmesh.ops.delete(bm_crown, geom=verts_to_remove, context='VERTS')
    
    tilt_m = Euler((math.radians(4), math.radians(-3), math.radians(2))).to_matrix()
    for v in bm_crown.verts:
        v.co.x *= 0.98
        v.co.y *= 1.05
        v.co.z *= 0.95
        v.co = tilt_m @ v.co
        v.co.x += 0.002
        v.co.y -= 0.006
        v.co.z += 1.670
        
    cap_crown = make_obj("Cap_Crown", bm_crown, mats["cap_crown"])
    mod_solid = cap_crown.modifiers.new("Solidify", 'SOLIDIFY')
    mod_solid.thickness = 0.006
    mod_solid.offset = 1.0
    
    # Cap Button on top
    bm_button = bmesh.new()
    bmesh.ops.create_uvsphere(bm_button, u_segments=14, v_segments=10, radius=0.010)
    for v in bm_button.verts:
        v.co.z *= 0.45
        v.co.x += 0.002
        v.co.y -= 0.006
        v.co.z += 1.775
    make_obj("Cap_Button", bm_button, mats["cap_button"], subd_levels=1)
    
    # Cap Visor / Brim: Extending forward towards -Y
    bm_visor = bmesh.new()
    bmesh.ops.create_grid(bm_visor, x_segments=16, y_segments=12, size=0.070)
    for v in bm_visor.verts:
        arch = (1.0 - (v.co.x / 0.070)**2) * 0.016
        v.co.z += arch
        dist_forward = (0.070 - v.co.y)
        v.co.z -= dist_forward * 0.26
        y_norm = dist_forward / 0.14
        v.co.x *= (1.0 - 0.22 * (y_norm**2))
        v.co.y -= 0.135
        v.co.z += 1.650
        
    visor = make_obj("Cap_Visor", bm_visor, mats["cap_visor"])
    mod_v_sol = visor.modifiers.new("Solidify", 'SOLIDIFY')
    mod_v_sol.thickness = 0.005
    
    # Front Embroidered Patch / Emblem
    bm_patch = bmesh.new()
    bmesh.ops.create_cube(bm_patch, size=1.0)
    for v in bm_patch.verts:
        v.co.x *= 0.026
        v.co.y *= 0.003
        v.co.z *= 0.016
        v.co.y += (v.co.x / 0.026)**2 * 0.003
        v.co = Euler((math.radians(18), 0, 0)).to_matrix() @ v.co
        v.co.y -= 0.106
        v.co.z += 1.705
    make_obj("Cap_Patch", bm_patch, mats["cap_patch"], subd_levels=1)
    
    # Back Strap & Metal Buckle
    bm_strap = bmesh.new()
    bmesh.ops.create_cube(bm_strap, size=1.0)
    for v in bm_strap.verts:
        v.co.x *= 0.035
        v.co.y *= 0.003
        v.co.z *= 0.008
        v.co.y += 0.098
        v.co.z += 1.655
    make_obj("Cap_Strap", bm_strap, mats["cap_strap"])
    
    bm_buckle = bmesh.new()
    bmesh.ops.create_cube(bm_buckle, size=1.0)
    for v in bm_buckle.verts:
        v.co.x *= 0.008
        v.co.y *= 0.004
        v.co.z *= 0.010
        v.co.y += 0.101
        v.co.z += 1.655
    make_obj("Cap_Buckle", bm_buckle, mats["metal"])

def build_hoodie(mats):
    # Oversized Streetwear Hoodie Body
    bm_torso = bmesh.new()
    bmesh.ops.create_uvsphere(bm_torso, u_segments=28, v_segments=20, radius=0.20)
    for v in bm_torso.verts:
        v.co.x *= 1.25
        v.co.y *= 0.85
        v.co.z *= 1.35
        z_rel = (v.co.z) / 0.27
        if z_rel < 0:
            v.co.x *= (1.0 + 0.08 * z_rel)
            v.co.y *= (1.0 + 0.12 * z_rel)
        else:
            v.co.x *= (1.0 + 0.15 * z_rel)
        v.co.y -= 0.01
        v.co.z += 1.24
    make_obj("Hoodie_Torso", bm_torso, mats["hoodie"], subd_levels=1)
    
    # Bottom Ribbed Waistband
    bm_rib = bmesh.new()
    bmesh.ops.create_cone(bm_rib, cap_ends=False, segments=28, radius1=0.21, radius2=0.22, depth=0.08)
    for v in bm_rib.verts:
        v.co.y *= 0.82
        v.co.y -= 0.01
        v.co.z += 0.99
    make_obj("Hoodie_HemRib", bm_rib, mats["hoodie_rib"], subd_levels=1)
    
    # Soft Kangaroo Pouch Pocket in front (-Y)
    # Modeled with rounded beveling so it integrates into cloth!
    bm_pock = bmesh.new()
    bmesh.ops.create_cube(bm_pock, size=1.0)
    for v in bm_pock.verts:
        v.co.x *= 0.15
        v.co.y *= 0.025
        v.co.z *= 0.09
        if v.co.z > 0:
            v.co.x *= 0.72 # Tapered top opening
        # curve along belly
        v.co.y += (v.co.x / 0.15)**2 * 0.012
        v.co.y -= 0.170
        v.co.z += 1.13
    make_obj("Hoodie_Pocket", bm_pock, mats["hoodie"], subd_levels=1)
    
    # Draped Hood around collar & upper back (+Y)
    bm_hood = bmesh.new()
    bmesh.ops.create_uvsphere(bm_hood, u_segments=24, v_segments=16, radius=0.15)
    verts_del = [v for v in bm_hood.verts if v.co.y < -0.02 and v.co.z > 0]
    bmesh.ops.delete(bm_hood, geom=verts_del, context='VERTS')
    for v in bm_hood.verts:
        v.co.x *= 1.15
        v.co.y *= 0.95
        v.co.z *= 0.85
        v.co.y += 0.06
        v.co.z += 1.42
    hood = make_obj("Hood_Drape", bm_hood, mats["hoodie"], subd_levels=1)
    mod_h_sol = hood.modifiers.new("Solidify", 'SOLIDIFY')
    mod_h_sol.thickness = 0.008
    
    # Thick Collar Rim
    bm_col = bmesh.new()
    make_torus_bm(bm_col, major_radius=0.10, minor_radius=0.022, major_segments=28, minor_segments=10)
    for v in bm_col.verts:
        v.co.x *= 1.05
        v.co.y *= 0.95
        v.co.y -= 0.01
        v.co.z += 1.43
    make_obj("Hoodie_Collar", bm_col, mats["hoodie_rib"], subd_levels=1)
    
    # Natural Drooping Drawstrings (Smooth Catena Spline Curves)
    for side in (-1, 1):
        pts = [
            Vector((side * 0.038, -0.165, 1.40)),
            Vector((side * 0.036, -0.174, 1.34)),
            Vector((side * 0.034, -0.178, 1.28)),
            Vector((side * 0.032, -0.176, 1.22)),
            Vector((side * 0.030, -0.172, 1.16)),
        ]
        bm_cord = make_tube_along_curve(pts, radius=0.0035, segments=10)
        make_obj(f"Cord_{'L' if side > 0 else 'R'}", bm_cord, mats["cord"], subd_levels=1)
        
        # Metal Aglet tip
        bm_aglet = bmesh.new()
        bmesh.ops.create_cone(bm_aglet, cap_ends=True, segments=10, radius1=0.0045, radius2=0.0035, depth=0.022)
        for v in bm_aglet.verts:
            v.co.x += side * 0.030
            v.co.y -= 0.172
            v.co.z += 1.15
        make_obj(f"Aglet_{'L' if side > 0 else 'R'}", bm_aglet, mats["metal"])
        
        # Grommet ring
        bm_grom = bmesh.new()
        make_torus_bm(bm_grom, major_radius=0.008, minor_radius=0.0025, major_segments=14, minor_segments=8)
        for v in bm_grom.verts:
            v.co = Euler((math.radians(90), 0, 0)).to_matrix() @ v.co
            v.co.x += side * 0.038
            v.co.y -= 0.165
            v.co.z += 1.39
        make_obj(f"Grommet_{'L' if side > 0 else 'R'}", bm_grom, mats["metal"])

def build_arms_and_hands(mats):
    # Natural Streetwear Posture: Hands casually tucked into the kangaroo pocket
    for side in (-1, 1):
        # Upper Arm
        bm_upper = bmesh.new()
        bmesh.ops.create_cone(bm_upper, cap_ends=True, segments=20, radius1=0.080, radius2=0.065, depth=0.28)
        for v in bm_upper.verts:
            v.co = Euler((math.radians(-10), math.radians(-24 * side), 0)).to_matrix() @ v.co
            v.co.x += side * 0.27
            v.co.y -= 0.015
            v.co.z += 1.28
        make_obj(f"Arm_Upper_{'L' if side > 0 else 'R'}", bm_upper, mats["hoodie"], subd_levels=1)
        
        # Forearm angled inwards towards front pocket
        bm_fore = bmesh.new()
        bmesh.ops.create_cone(bm_fore, cap_ends=True, segments=20, radius1=0.065, radius2=0.052, depth=0.26)
        for v in bm_fore.verts:
            v.co = Euler((math.radians(32), math.radians(35 * side), math.radians(15 * side))).to_matrix() @ v.co
            v.co.x += side * 0.25
            v.co.y -= 0.095
            v.co.z += 1.13
        make_obj(f"Arm_Fore_{'L' if side > 0 else 'R'}", bm_fore, mats["hoodie"], subd_levels=1)
        
        # Ribbed Wrist Cuff (resting at pocket opening)
        bm_cuff = bmesh.new()
        make_torus_bm(bm_cuff, major_radius=0.046, minor_radius=0.015, major_segments=20, minor_segments=10)
        for v in bm_cuff.verts:
            v.co = Euler((math.radians(35), math.radians(40 * side), 0)).to_matrix() @ v.co
            v.co.x += side * 0.17
            v.co.y -= 0.155
            v.co.z += 1.06
        make_obj(f"Cuff_{'L' if side > 0 else 'R'}", bm_cuff, mats["hoodie_rib"], subd_levels=1)
        
        # Stylized Hand entering the pocket (clean organic form, thumb hooked over pocket edge)
        bm_hand = bmesh.new()
        bmesh.ops.create_uvsphere(bm_hand, u_segments=16, v_segments=12, radius=0.036)
        for v in bm_hand.verts:
            v.co.x *= 0.80
            v.co.y *= 1.25
            v.co.z *= 0.50
            v.co = Euler((math.radians(25), math.radians(30 * side), 0)).to_matrix() @ v.co
            v.co.x += side * 0.13
            v.co.y -= 0.175
            v.co.z += 1.05
        make_obj(f"Hand_{'L' if side > 0 else 'R'}", bm_hand, mats["skin"], subd_levels=1)

def build_pants(mats):
    # Pelvis
    bm_pelvis = bmesh.new()
    bmesh.ops.create_uvsphere(bm_pelvis, u_segments=26, v_segments=18, radius=0.20)
    for v in bm_pelvis.verts:
        v.co.x *= 1.05
        v.co.y *= 0.85
        v.co.z *= 0.80
        v.co.y -= 0.01
        v.co.z += 0.93
    make_obj("Pants_Pelvis", bm_pelvis, mats["pants"], subd_levels=1)
    
    # Left and Right Legs
    for side in (-1, 1):
        # Thigh
        bm_thigh = bmesh.new()
        bmesh.ops.create_cone(bm_thigh, cap_ends=True, segments=24, radius1=0.108, radius2=0.092, depth=0.45)
        for v in bm_thigh.verts:
            v.co = Euler((math.radians(-2), math.radians(-3 * side), 0)).to_matrix() @ v.co
            v.co.x += side * 0.115
            v.co.y -= 0.005
            v.co.z += 0.70
        make_obj(f"Pants_Thigh_{'L' if side > 0 else 'R'}", bm_thigh, mats["pants"], subd_levels=1)
        
        # Calf with ankle folds stacked over sneakers
        bm_calf = bmesh.new()
        bmesh.ops.create_cone(bm_calf, cap_ends=True, segments=24, radius1=0.092, radius2=0.084, depth=0.42)
        for v in bm_calf.verts:
            z_norm = (v.co.z + 0.21) / 0.42
            if z_norm < 0.25:
                wrinkle = math.sin(z_norm * 40) * 0.008
                v.co.x += wrinkle
                v.co.y += wrinkle
            v.co.x += side * 0.128
            v.co.y += 0.002
            v.co.z += 0.30
        make_obj(f"Pants_Calf_{'L' if side > 0 else 'R'}", bm_calf, mats["pants"], subd_levels=1)
        
        # Cargo Pocket with beveled edges
        bm_cargo = bmesh.new()
        bmesh.ops.create_cube(bm_cargo, size=1.0)
        for v in bm_cargo.verts:
            v.co.x *= 0.022
            v.co.y *= 0.065
            v.co.z *= 0.080
            v.co.x += side * 0.215
            v.co.y -= 0.010
            v.co.z += 0.66
        make_obj(f"Cargo_Pocket_{'L' if side > 0 else 'R'}", bm_cargo, mats["pants_detail"], subd_levels=1)
        
        # Cargo Flap
        bm_flap = bmesh.new()
        bmesh.ops.create_cube(bm_flap, size=1.0)
        for v in bm_flap.verts:
            v.co.x *= 0.025
            v.co.y *= 0.068
            v.co.z *= 0.020
            v.co.x += side * 0.218
            v.co.y -= 0.010
            v.co.z += 0.73
        make_obj(f"Cargo_Flap_{'L' if side > 0 else 'R'}", bm_flap, mats["pants_detail"], subd_levels=1)

def build_sneakers(mats):
    # Chunky Streetwear Skate Sneakers (Fully visible on floor Z=0.0)
    for side in (-1, 1):
        # Midsole / Outsole
        bm_sole = bmesh.new()
        bmesh.ops.create_cube(bm_sole, size=1.0)
        for v in bm_sole.verts:
            v.co.x *= 0.062
            v.co.y *= 0.145
            v.co.z *= 0.025
            y_pos = -v.co.y / 0.145
            if -0.2 < y_pos < 0.3:
                v.co.x *= 0.88
            if y_pos > 0.4:
                v.co.z += ((y_pos - 0.4) / 0.6)**2 * 0.018
            v.co = Euler((0, 0, math.radians(7 * side))).to_matrix() @ v.co
            v.co.x += side * 0.138
            v.co.y -= 0.035
            v.co.z += 0.025
        make_obj(f"Sneaker_Sole_{'L' if side > 0 else 'R'}", bm_sole, mats["sneaker_sole"], subd_levels=1)
        
        # Bottom Gum Tread
        bm_tread = bmesh.new()
        bmesh.ops.create_cube(bm_tread, size=1.0)
        for v in bm_tread.verts:
            v.co.x *= 0.060
            v.co.y *= 0.142
            v.co.z *= 0.005
            v.co = Euler((0, 0, math.radians(7 * side))).to_matrix() @ v.co
            v.co.x += side * 0.138
            v.co.y -= 0.035
            v.co.z += 0.005
        make_obj(f"Sneaker_Tread_{'L' if side > 0 else 'R'}", bm_tread, mats["sneaker_gum"])
        
        # Sneaker Upper (White Leather)
        bm_upper = bmesh.new()
        bmesh.ops.create_uvsphere(bm_upper, u_segments=20, v_segments=14, radius=0.075)
        for v in bm_upper.verts:
            v.co.x *= 0.72
            v.co.y *= 1.70
            v.co.z *= 0.65
            if v.co.z < -0.01:
                v.co.z = -0.01
            v.co = Euler((0, 0, math.radians(7 * side))).to_matrix() @ v.co
            v.co.x += side * 0.138
            v.co.y -= 0.035
            v.co.z += 0.065
        make_obj(f"Sneaker_Upper_{'L' if side > 0 else 'R'}", bm_upper, mats["sneaker_white"], subd_levels=1)
        
        # Side Accent Stripe (Sage Green)
        bm_stripe = bmesh.new()
        bmesh.ops.create_cube(bm_stripe, size=1.0)
        for v in bm_stripe.verts:
            v.co.x *= 0.005
            v.co.y *= 0.075
            v.co.z *= 0.018
            v.co = Euler((math.radians(-12), 0, math.radians(7 * side))).to_matrix() @ v.co
            v.co.x += side * (0.138 + 0.048 * side)
            v.co.y -= 0.030
            v.co.z += 0.065
        make_obj(f"Sneaker_Stripe_{'L' if side > 0 else 'R'}", bm_stripe, mats["sneaker_accent"], subd_levels=1)
        
        # Collar Rim (Black)
        bm_rim = bmesh.new()
        make_torus_bm(bm_rim, major_radius=0.048, minor_radius=0.015, major_segments=20, minor_segments=10)
        for v in bm_rim.verts:
            v.co = Euler((math.radians(-15), 0, math.radians(7 * side))).to_matrix() @ v.co
            v.co.x += side * 0.138
            v.co.y -= 0.005
            v.co.z += 0.115
        make_obj(f"Sneaker_Collar_{'L' if side > 0 else 'R'}", bm_rim, mats["sneaker_black"], subd_levels=1)
        
        # Tongue
        bm_tongue = bmesh.new()
        bmesh.ops.create_cube(bm_tongue, size=1.0)
        for v in bm_tongue.verts:
            v.co.x *= 0.028
            v.co.y *= 0.065
            v.co.z *= 0.008
            v.co = Euler((math.radians(38), 0, math.radians(7 * side))).to_matrix() @ v.co
            v.co.x += side * 0.138
            v.co.y -= 0.065
            v.co.z += 0.095
        make_obj(f"Sneaker_Tongue_{'L' if side > 0 else 'R'}", bm_tongue, mats["sneaker_black"], subd_levels=1)
        
        # Criss-cross laces
        for i in range(3):
            bm_lace = bmesh.new()
            bmesh.ops.create_cube(bm_lace, size=1.0)
            for v in bm_lace.verts:
                v.co.x *= 0.024
                v.co.y *= 0.006
                v.co.z *= 0.004
                v.co = Euler((math.radians(38), 0, math.radians(7 * side))).to_matrix() @ v.co
                v.co.x += side * 0.138
                v.co.y -= 0.045 + i * 0.022
                v.co.z += 0.080 + i * 0.015
            make_obj(f"Sneaker_Lace_{i}_{'L' if side > 0 else 'R'}", bm_lace, mats["sneaker_white"])

def build_backdrop(mats):
    # Studio Cyclorama with generous floor depth so shoes have beautiful grounding shadows
    bm = bmesh.new()
    xs = [-3.5 + i * 0.7 for i in range(11)]
    profile = []
    for y in [-3.2, -2.0, -1.0, 0.5, 1.2]:
        profile.append((y, 0.0))
    for angle_deg in [15, 30, 45, 60, 75, 90]:
        rad = math.radians(angle_deg)
        y = 1.2 + 0.9 * math.sin(rad)
        z = 0.9 * (1.0 - math.cos(rad))
        profile.append((y, z))
    for z in [1.2, 1.8, 2.5, 3.4]:
        profile.append((2.1, z))
        
    grid_verts = []
    for y, z in profile:
        row = []
        for x in xs:
            v = bm.verts.new((x, y, z))
            row.append(v)
        grid_verts.append(row)
    bm.verts.ensure_lookup_table()
    
    for r in range(len(grid_verts) - 1):
        for c in range(len(xs) - 1):
            v1 = grid_verts[r][c]
            v2 = grid_verts[r][c+1]
            v3 = grid_verts[r+1][c+1]
            v4 = grid_verts[r+1][c]
            bm.faces.new([v1, v2, v3, v4])
            
    cyc = make_obj("Studio_Cyclorama", bm, mats["backdrop"], subd_levels=1)
    return cyc

def setup_lighting():
    # 1. Warm Key Light (Front-Right 45 degrees, balanced soft lighting)
    key_data = bpy.data.lights.new(name="Key_Light", type='AREA')
    key_data.energy = 280.0 # Balanced power to avoid blowing out facial tones
    key_data.size = 1.4
    key_data.color = (1.0, 0.95, 0.90)
    key_obj = bpy.data.objects.new(name="Key_Light", object_data=key_data)
    key_obj.location = (1.6, -2.2, 2.0)
    dir_k = Vector((0, 0, 1.1)) - key_obj.location
    key_obj.rotation_euler = dir_k.to_track_quat('-Z', 'Y').to_euler()
    bpy.context.scene.collection.objects.link(key_obj)
    
    # 2. Cool Fill Light (Front-Left)
    fill_data = bpy.data.lights.new(name="Fill_Light", type='AREA')
    fill_data.energy = 130.0
    fill_data.size = 2.2
    fill_data.color = (0.86, 0.92, 1.0)
    fill_obj = bpy.data.objects.new(name="Fill_Light", object_data=fill_data)
    fill_obj.location = (-1.8, -2.0, 1.4)
    dir_f = Vector((0, 0, 1.0)) - fill_obj.location
    fill_obj.rotation_euler = dir_f.to_track_quat('-Z', 'Y').to_euler()
    bpy.context.scene.collection.objects.link(fill_obj)
    
    # 3. Rim / Kicker Light (Back-Right, outlines cap silhouette & shoulders)
    rim_data = bpy.data.lights.new(name="Rim_Light", type='AREA')
    rim_data.energy = 440.0
    rim_data.size = 1.2
    rim_data.color = (1.0, 0.98, 0.95)
    rim_obj = bpy.data.objects.new(name="Rim_Light", object_data=rim_data)
    rim_obj.location = (-1.2, 1.5, 2.2)
    dir_r = Vector((0, 0, 1.3)) - rim_obj.location
    rim_obj.rotation_euler = dir_r.to_track_quat('-Z', 'Y').to_euler()
    bpy.context.scene.collection.objects.link(rim_obj)
    
    # 4. Top Soft Overhead Light
    top_data = bpy.data.lights.new(name="Top_Light", type='AREA')
    top_data.energy = 80.0
    top_data.size = 2.8
    top_data.color = (0.95, 0.95, 0.98)
    top_obj = bpy.data.objects.new(name="Top_Light", object_data=top_data)
    top_obj.location = (0.0, -0.4, 3.2)
    top_obj.rotation_euler = Euler((0, 0, 0))
    bpy.context.scene.collection.objects.link(top_obj)

def setup_camera():
    cam_data = bpy.data.cameras.new("Main_Camera")
    # 48mm lens with adjusted framing: comfortably captures the full body from cap top to sneakers
    cam_data.lens = 48.0
    cam_data.sensor_width = 36.0
    
    cam_obj = bpy.data.objects.new("Main_Camera", cam_data)
    # Position: Front 3/4 hero view, camera pulled back slightly to Y=-3.15
    cam_obj.location = (0.40, -3.15, 0.98)
    # Aim at character waist/torso (Z=0.88) so head and shoes have equal breathing room
    target = Vector((0.0, 0.0, 0.88))
    direction = target - cam_obj.location
    cam_obj.rotation_euler = direction.to_track_quat('-Z', 'Y').to_euler()
    
    bpy.context.scene.collection.objects.link(cam_obj)
    bpy.context.scene.camera = cam_obj
    return cam_obj

def setup_render(output_path, samples=48):
    scene = bpy.context.scene
    scene.render.engine = 'CYCLES'
    scene.cycles.device = 'CPU'
    scene.cycles.samples = samples
    scene.cycles.use_denoising = True
    
    # 1200x1600 (3:4 portrait)
    scene.render.resolution_x = 1200
    scene.render.resolution_y = 1600
    scene.render.resolution_percentage = 100
    
    scene.view_settings.view_transform = 'AgX'
    scene.view_settings.look = 'AgX - High Contrast'
    
    scene.render.filepath = output_path
    scene.render.image_settings.file_format = 'PNG'
    scene.render.image_settings.color_mode = 'RGBA'

def main():
    print("[1/6] Initializing scene...")
    clear_scene()
    
    print("[2/6] Building PBR materials...")
    mats = build_materials()
    
    print("[3/6] Generating character geometry...")
    build_head_and_face(mats)
    build_hair(mats)
    build_hat(mats)
    build_hoodie(mats)
    build_arms_and_hands(mats)
    build_pants(mats)
    build_sneakers(mats)
    build_backdrop(mats)
    
    print("[4/6] Setting up studio lighting & camera...")
    setup_lighting()
    setup_camera()
    
    out_blend = "/home/rois/jarvis/blender-character/karakter_pria_topi.blend"
    out_png = "/home/rois/jarvis/blender-character/render_preview.png"
    
    print(f"[5/6] Saving .blend file to {out_blend}...")
    bpy.ops.wm.save_as_mainfile(filepath=out_blend)
    
    print(f"[6/6] Rendering preview with Cycles to {out_png}...")
    setup_render(out_png, samples=48)
    bpy.ops.render.render(write_still=True)
    
    total_tris = sum(len(o.data.polygons) * 2 for o in bpy.data.objects if o.type == 'MESH')
    total_objs = len(bpy.data.objects)
    print(f"DONE! Objects: {total_objs}, Approx Tris: {total_tris}")
    print(f"Blend file: {out_blend}")
    print(f"Render image: {out_png}")

if __name__ == "__main__":
    main()
